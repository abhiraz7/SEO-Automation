<?php
/**
 * Registers every MCP REST endpoint under /wp-json/cwpm/v1/
 */
class CWPM_Router {

    const NS = 'cwpm/v1';

    public static function init() {}

    public static function register_routes() {
        $perm = [ 'CWPM_Auth', 'permission_callback' ];

        /* ── Meta / handshake ─────────────────────────────── */
        register_rest_route( self::NS, '/ping', [
            'methods'             => 'GET',
            'callback'            => [ __CLASS__, 'ping' ],
            'permission_callback' => $perm,
        ] );

        register_rest_route( self::NS, '/capabilities', [
            'methods'             => 'GET',
            'callback'            => [ __CLASS__, 'capabilities' ],
            'permission_callback' => $perm,
        ] );

        /* ── MCP tool dispatcher ──────────────────────────── */
        register_rest_route( self::NS, '/tool', [
            'methods'             => 'POST',
            'callback'            => [ __CLASS__, 'dispatch_tool' ],
            'permission_callback' => $perm,
        ] );

        /* ── Logs ─────────────────────────────────────────── */
        register_rest_route( self::NS, '/logs', [
            'methods'             => 'GET',
            'callback'            => [ __CLASS__, 'get_logs' ],
            'permission_callback' => $perm,
        ] );

        /* ── MCP Streamable HTTP (JSON-RPC 2.0) ───────────── */
        register_rest_route( self::NS, '/mcp', [
            [
                'methods'             => 'POST',
                'callback'            => [ 'CWPM_MCP', 'handle' ],
                'permission_callback' => $perm,
            ],
            [
                'methods'             => 'GET',
                'callback'            => [ 'CWPM_MCP', 'handle_get' ],
                'permission_callback' => $perm,
            ],
        ] );
    }

    public static function ping(): WP_REST_Response {
        return new WP_REST_Response( [
            'status'  => 'ok',
            'plugin'  => 'Claude WP Developer',
            'version' => CWPM_VERSION,
            'site'    => get_bloginfo( 'url' ),
            'time'    => current_time( 'c' ),
        ] );
    }

    public static function capabilities(): WP_REST_Response {
        return new WP_REST_Response( [
            'tools' => self::tool_manifest(),
        ] );
    }

    public static function get_logs(): WP_REST_Response {
        return new WP_REST_Response( CWPM_Logger::get_recent() );
    }

    /** Central dispatcher — receives { tool, params } */
    public static function dispatch_tool( WP_REST_Request $request ): WP_REST_Response {
        $body    = $request->get_json_params();
        $tool    = sanitize_key( $body['tool'] ?? '' );
        $params  = $body['params'] ?? [];
        $allowed = json_decode( get_option( 'cwpm_allowed_actions', '[]' ), true );

        CWPM_Logger::log( 'info', "Tool called: {$tool}" );

        try {
            $result = self::call_tool( $tool, $params, $allowed );
            return new WP_REST_Response( [ 'success' => true, 'result' => $result ] );
        } catch ( InvalidArgumentException $e ) {
            CWPM_Logger::log( 'error', "Tool {$tool} error: " . $e->getMessage() );
            return new WP_REST_Response( [ 'success' => false, 'error' => $e->getMessage() ], 400 );
        } catch ( Exception $e ) {
            CWPM_Logger::log( 'error', "Tool {$tool} error: " . $e->getMessage() );
            // Return a generic message to avoid leaking internal paths/table names.
            return new WP_REST_Response( [ 'success' => false, 'error' => 'Tool execution failed. Check activity log for details.' ], 500 );
        }
    }

    /**
     * Shared tool executor — used by both the legacy /tool endpoint and the MCP handler.
     * Throws on unknown tool, disabled group, or handler error.
     */
    public static function call_tool( string $tool, array $params, array $allowed ) {
        $handlers = self::get_handlers();

        if ( ! isset( $handlers[ $tool ] ) ) {
            throw new InvalidArgumentException( "Unknown tool: {$tool}" );
        }

        [ $class, $method, $group ] = $handlers[ $tool ];

        if ( ! in_array( $group, $allowed, true ) ) {
            CWPM_Logger::log( 'warn', "Blocked tool '{$tool}' — group '{$group}' not in allowed_actions." );
            throw new RuntimeException( "Tool group '{$group}' is disabled. Enable it in Claude WP Developer settings." );
        }

        return call_user_func( [ $class, $method ], $params );
    }

    private static function get_handlers(): array {
        return [
            /* Content */
            'create_post'            => [ 'CWPM_Content',      'create_post',              'content'     ],
            'update_post'            => [ 'CWPM_Content',      'update_post',              'content'     ],
            'get_post'               => [ 'CWPM_Content',      'get_post',                 'content'     ],
            'list_posts'             => [ 'CWPM_Content',      'list_posts',               'content'     ],
            'delete_post'            => [ 'CWPM_Content',      'delete_post',              'content'     ],
            'schedule_post'          => [ 'CWPM_Content',      'schedule_post',            'content'     ],
            'set_featured_image'     => [ 'CWPM_Content',      'set_featured_image',       'content'     ],
            'get_taxonomies'         => [ 'CWPM_Content',      'get_taxonomies',           'content'     ],
            'assign_terms'           => [ 'CWPM_Content',      'assign_terms',             'content'     ],
            /* Elementor */
            'elementor_get_data'     => [ 'CWPM_Elementor',    'get_data',                 'elementor'   ],
            'elementor_set_data'     => [ 'CWPM_Elementor',    'set_data',                 'elementor'   ],
            'elementor_build_page'   => [ 'CWPM_Elementor',    'build_page_from_template', 'elementor'   ],
            'elementor_list_widgets' => [ 'CWPM_Elementor',    'list_widgets',             'elementor'   ],
            'elementor_get_globals'  => [ 'CWPM_Elementor',    'get_globals',              'elementor'   ],
            'elementor_set_globals'  => [ 'CWPM_Elementor',    'set_globals',              'elementor'   ],
            /* SEO */
            'yoast_get_meta'         => [ 'CWPM_SEO',          'get_meta',                 'seo'         ],
            'yoast_set_meta'         => [ 'CWPM_SEO',          'set_meta',                 'seo'         ],
            'yoast_audit'            => [ 'CWPM_SEO',          'audit_post',               'seo'         ],
            'yoast_sitemap_ping'     => [ 'CWPM_SEO',          'ping_sitemap',             'seo'         ],
            /* Media */
            'upload_media'           => [ 'CWPM_Media',        'upload',                   'media'       ],
            'list_media'             => [ 'CWPM_Media',        'list_media',               'media'       ],
            'get_media'              => [ 'CWPM_Media',        'get_media',                'media'       ],
            'delete_media'           => [ 'CWPM_Media',        'delete_media',             'media'       ],
            'update_media_meta'      => [ 'CWPM_Media',        'update_meta',              'media'       ],
            /* Plugins */
            'list_plugins'           => [ 'CWPM_Plugins',      'list_plugins',             'plugins'     ],
            'activate_plugin'        => [ 'CWPM_Plugins',      'activate_plugin',          'plugins'     ],
            'deactivate_plugin'      => [ 'CWPM_Plugins',      'deactivate_plugin',        'plugins'     ],
            'install_plugin'         => [ 'CWPM_Plugins',      'install_plugin',           'plugins'     ],
            'get_plugin_settings'    => [ 'CWPM_Plugins',      'get_settings',             'plugins'     ],
            'set_plugin_settings'    => [ 'CWPM_Plugins',      'set_settings',             'plugins'     ],
            /* Theme */
            'get_theme_mods'         => [ 'CWPM_Theme',        'get_mods',                 'theme'       ],
            'set_theme_mods'         => [ 'CWPM_Theme',        'set_mods',                 'theme'       ],
            'get_menus'              => [ 'CWPM_Theme',        'get_menus',                'theme'       ],
            'set_menu_items'         => [ 'CWPM_Theme',        'set_menu_items',           'theme'       ],
            'get_widgets'            => [ 'CWPM_Theme',        'get_widgets',              'theme'       ],
            'get_options'            => [ 'CWPM_Theme',        'get_options',              'theme'       ],
            'set_option'             => [ 'CWPM_Theme',        'set_option',               'theme'       ],
            'php_exec'               => [ 'CWPM_Theme',        'php_exec',                 'php_exec'    ],
            /* WordPress utilities */
            'get_site_info'          => [ 'CWPM_WordPress',    'get_site_info',            'wordpress'   ],
            'list_users'             => [ 'CWPM_WordPress',    'list_users',               'wordpress'   ],
            'get_user'               => [ 'CWPM_WordPress',    'get_user',                 'wordpress'   ],
            'create_term'            => [ 'CWPM_WordPress',    'create_term',              'wordpress'   ],
            'delete_term'            => [ 'CWPM_WordPress',    'delete_term',              'wordpress'   ],
            'flush_cache'            => [ 'CWPM_WordPress',    'flush_cache',              'wordpress'   ],
            'search_replace'         => [ 'CWPM_WordPress',    'search_replace',           'wordpress'   ],
            'get_active_theme'       => [ 'CWPM_WordPress',    'get_active_theme',         'wordpress'   ],
            'activate_theme'         => [ 'CWPM_WordPress',    'activate_theme',           'wordpress'   ],
            'run_cron'               => [ 'CWPM_WordPress',    'run_cron',                 'wordpress'   ],
            /* WooCommerce */
            'woo_list_products'      => [ 'CWPM_WooCommerce',  'list_products',            'woocommerce' ],
            'woo_get_product'        => [ 'CWPM_WooCommerce',  'get_product',              'woocommerce' ],
            'woo_create_product'     => [ 'CWPM_WooCommerce',  'create_product',           'woocommerce' ],
            'woo_update_product'     => [ 'CWPM_WooCommerce',  'update_product',           'woocommerce' ],
            'woo_list_orders'        => [ 'CWPM_WooCommerce',  'list_orders',              'woocommerce' ],
            'woo_get_order'          => [ 'CWPM_WooCommerce',  'get_order',                'woocommerce' ],
            /* Elementor templates */
            'elementor_list_templates'  => [ 'CWPM_Elementor', 'list_templates',           'elementor'   ],
            'elementor_import_template' => [ 'CWPM_Elementor', 'import_template',          'elementor'   ],
            /* Forms */
            'list_forms'             => [ 'CWPM_Forms',        'list_forms',               'forms'       ],
            'list_form_entries'      => [ 'CWPM_Forms',        'list_form_entries',        'forms'       ],
            'get_form_entry'         => [ 'CWPM_Forms',        'get_form_entry',           'forms'       ],
            /* Email */
            'list_email_logs'        => [ 'CWPM_Email',        'list_email_logs',          'email'       ],
            /* Divi */
            'divi_get_data'          => [ 'CWPM_Divi',         'get_data',                 'divi'        ],
            'divi_set_data'          => [ 'CWPM_Divi',         'set_data',                 'divi'        ],
            'divi_build_page'        => [ 'CWPM_Divi',         'build_page',               'divi'        ],
            'divi_list_modules'      => [ 'CWPM_Divi',         'list_modules',             'divi'        ],
            'divi_get_globals'       => [ 'CWPM_Divi',         'get_globals',              'divi'        ],
            'divi_set_globals'       => [ 'CWPM_Divi',         'set_globals',              'divi'        ],
            'divi_list_layouts'      => [ 'CWPM_Divi',         'list_layouts',             'divi'        ],
            'divi_import_layout'     => [ 'CWPM_Divi',         'import_layout',            'divi'        ],
            'divi_flush_cache'       => [ 'CWPM_Divi',         'flush_cache',              'divi'        ],
            'divi_get_theme_builder' => [ 'CWPM_Divi',         'get_theme_builder',        'divi'        ],
        ];
    }

    private static function tool_manifest(): array {
        return [
            /* ── Content ── */
            [ 'name' => 'create_post',            'group' => 'content',   'description' => 'Create any post type (post, page, custom). Supports scheduling, excerpt, password, custom fields.' ],
            [ 'name' => 'update_post',            'group' => 'content',   'description' => 'Update any field of an existing post.' ],
            [ 'name' => 'get_post',               'group' => 'content',   'description' => 'Get full post data including meta, terms, Elementor data.' ],
            [ 'name' => 'list_posts',             'group' => 'content',   'description' => 'List posts with filters (type, status, author, date, meta).' ],
            [ 'name' => 'delete_post',            'group' => 'content',   'description' => 'Trash or permanently delete a post.' ],
            [ 'name' => 'schedule_post',          'group' => 'content',   'description' => 'Schedule a post to publish at a specific datetime.' ],
            [ 'name' => 'set_featured_image',     'group' => 'content',   'description' => 'Set or remove the featured image on a post.' ],
            [ 'name' => 'get_taxonomies',         'group' => 'content',   'description' => 'List all taxonomies and their terms.' ],
            [ 'name' => 'assign_terms',           'group' => 'content',   'description' => 'Add/set/remove taxonomy terms on a post.' ],

            /* ── Elementor ── */
            [ 'name' => 'elementor_get_data',     'group' => 'elementor', 'description' => 'Get full Elementor JSON for a post/page.' ],
            [ 'name' => 'elementor_set_data',     'group' => 'elementor', 'description' => 'Replace Elementor JSON on a post/page.' ],
            [ 'name' => 'elementor_build_page',   'group' => 'elementor', 'description' => 'Build a complete Elementor page from an HTML template description using native widgets (icon-box, heading, image, button, columns, etc).' ],
            [ 'name' => 'elementor_list_widgets', 'group' => 'elementor', 'description' => 'List every registered Elementor widget with its controls.' ],
            [ 'name' => 'elementor_get_globals',  'group' => 'elementor', 'description' => 'Get Elementor global colors and fonts.' ],
            [ 'name' => 'elementor_set_globals',  'group' => 'elementor', 'description' => 'Update Elementor global colors or fonts.' ],

            /* ── SEO ── */
            [ 'name' => 'yoast_get_meta',         'group' => 'seo',       'description' => 'Get all Yoast SEO meta for a post.' ],
            [ 'name' => 'yoast_set_meta',         'group' => 'seo',       'description' => 'Set Yoast SEO meta (title, description, robots, og, canonical, schema).' ],
            [ 'name' => 'yoast_audit',            'group' => 'seo',       'description' => 'Run a readability/keyword audit and return recommendations.' ],
            [ 'name' => 'yoast_sitemap_ping',     'group' => 'seo',       'description' => 'Ping search engines with updated sitemap.' ],

            /* ── Media ── */
            [ 'name' => 'upload_media',           'group' => 'media',     'description' => 'Upload an image/file from URL or base64 to the media library.' ],
            [ 'name' => 'list_media',             'group' => 'media',     'description' => 'Search and list media library items.' ],
            [ 'name' => 'get_media',              'group' => 'media',     'description' => 'Get a single media item with all sizes and meta.' ],
            [ 'name' => 'delete_media',           'group' => 'media',     'description' => 'Delete a media item.' ],
            [ 'name' => 'update_media_meta',      'group' => 'media',     'description' => 'Update alt text, caption, title, description.' ],

            /* ── Plugins ── */
            [ 'name' => 'list_plugins',           'group' => 'plugins',   'description' => 'List all installed plugins with status.' ],
            [ 'name' => 'activate_plugin',        'group' => 'plugins',   'description' => 'Activate a plugin by slug.' ],
            [ 'name' => 'deactivate_plugin',      'group' => 'plugins',   'description' => 'Deactivate a plugin.' ],
            [ 'name' => 'install_plugin',         'group' => 'plugins',   'description' => 'Install a plugin from wordpress.org by slug.' ],
            [ 'name' => 'get_plugin_settings',    'group' => 'plugins',   'description' => 'Read plugin options from wp_options.' ],
            [ 'name' => 'set_plugin_settings',    'group' => 'plugins',   'description' => 'Write plugin options to wp_options.' ],

            /* ── Theme ── */
            [ 'name' => 'get_theme_mods',         'group' => 'theme',       'description' => 'Get all theme customizer settings.' ],
            [ 'name' => 'set_theme_mods',         'group' => 'theme',       'description' => 'Update theme customizer settings.' ],
            [ 'name' => 'get_menus',              'group' => 'theme',       'description' => 'Get navigation menus and their items.' ],
            [ 'name' => 'set_menu_items',         'group' => 'theme',       'description' => 'Add/update/delete menu items.' ],
            [ 'name' => 'get_widgets',            'group' => 'theme',       'description' => 'Get sidebar widget configuration.' ],
            [ 'name' => 'get_options',            'group' => 'theme',       'description' => 'Read wp_options by key(s).' ],
            [ 'name' => 'set_option',             'group' => 'theme',       'description' => 'Write a wp_option value.' ],
            [ 'name' => 'php_exec',               'group' => 'php_exec',    'description' => '⚠️ Execute arbitrary PHP in WP context. Dev/staging only.' ],

            /* ── WordPress core utilities ── */
            [ 'name' => 'get_site_info',          'group' => 'wordpress',   'description' => 'Get WordPress site info: name, URL, version, active theme, post/user counts.' ],
            [ 'name' => 'list_users',             'group' => 'wordpress',   'description' => 'List users with optional role filter and pagination.' ],
            [ 'name' => 'get_user',               'group' => 'wordpress',   'description' => 'Get a single user by ID or email, including meta.' ],
            [ 'name' => 'create_term',            'group' => 'wordpress',   'description' => 'Create a new taxonomy term (category, tag, or custom).' ],
            [ 'name' => 'delete_term',            'group' => 'wordpress',   'description' => 'Delete a taxonomy term by ID.' ],
            [ 'name' => 'flush_cache',            'group' => 'wordpress',   'description' => 'Flush WordPress object cache. Optionally also flush rewrite rules and Elementor CSS cache.' ],
            [ 'name' => 'search_replace',         'group' => 'wordpress',   'description' => 'Find and replace text in post titles and content. Supports dry_run preview.' ],
            [ 'name' => 'get_active_theme',       'group' => 'wordpress',   'description' => 'Get active theme details and list all installed themes.' ],
            [ 'name' => 'activate_theme',         'group' => 'wordpress',   'description' => 'Switch the active WordPress theme by slug.' ],
            [ 'name' => 'run_cron',               'group' => 'wordpress',   'description' => 'Manually trigger WP-Cron and return the next 20 scheduled events.' ],

            /* ── WooCommerce ── */
            [ 'name' => 'woo_list_products',      'group' => 'woocommerce', 'description' => 'List WooCommerce products with filters (status, category, search).' ],
            [ 'name' => 'woo_get_product',        'group' => 'woocommerce', 'description' => 'Get full WooCommerce product details including price, stock, images, meta.' ],
            [ 'name' => 'woo_create_product',     'group' => 'woocommerce', 'description' => 'Create a new WooCommerce simple product.' ],
            [ 'name' => 'woo_update_product',     'group' => 'woocommerce', 'description' => 'Update an existing WooCommerce product.' ],
            [ 'name' => 'woo_list_orders',        'group' => 'woocommerce', 'description' => 'List WooCommerce orders with status filter and pagination.' ],
            [ 'name' => 'woo_get_order',          'group' => 'woocommerce', 'description' => 'Get full WooCommerce order details including line items and billing/shipping.' ],

            /* ── Divi ── */
            [ 'name' => 'divi_get_data',          'group' => 'divi', 'description' => 'Read Divi shortcodes and builder meta from a post/page.' ],
            [ 'name' => 'divi_set_data',          'group' => 'divi', 'description' => 'Write raw Divi shortcodes to a post, enabling the Divi builder.' ],
            [ 'name' => 'divi_build_page',        'group' => 'divi', 'description' => 'Build a Divi page from a structured sections spec (sections → rows → columns → modules). Generates proper shortcodes.' ],
            [ 'name' => 'divi_list_modules',      'group' => 'divi', 'description' => 'Return the full catalog of supported Divi modules with group and content flag.' ],
            [ 'name' => 'divi_get_globals',       'group' => 'divi', 'description' => 'Get Divi global colors, accent color, and theme mod settings.' ],
            [ 'name' => 'divi_set_globals',       'group' => 'divi', 'description' => 'Update Divi global colors, accent color, or theme mods.' ],
            [ 'name' => 'divi_list_layouts',      'group' => 'divi', 'description' => 'List saved layouts from the Divi library (et_pb_layout post type).' ],
            [ 'name' => 'divi_import_layout',     'group' => 'divi', 'description' => 'Apply or append a saved Divi layout to a post/page.' ],
            [ 'name' => 'divi_flush_cache',       'group' => 'divi', 'description' => 'Clear Divi static CSS cache site-wide or for a specific post.' ],
            [ 'name' => 'divi_get_theme_builder', 'group' => 'divi', 'description' => 'List Divi Theme Builder templates (headers, footers, body layouts).' ],
        ];
    }
}
