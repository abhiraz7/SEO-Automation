<?php
class CWPM_Logger {

    const OPTION_KEY = 'cwpm_activity_log';
    const MAX_ENTRIES = 200;

    public static function log( string $level, string $message ): void {
        $log   = self::read_log();
        $log[] = [
            'time'    => current_time( 'c' ),
            'level'   => $level,
            'message' => $message,
        ];
        // Keep only latest N entries
        if ( count( $log ) > self::MAX_ENTRIES ) {
            $log = array_slice( $log, -self::MAX_ENTRIES );
        }
        update_option( self::OPTION_KEY, $log, false );
    }

    public static function get_recent( int $n = 50 ): array {
        return array_slice( array_reverse( self::read_log() ), 0, $n );
    }

    /**
     * Always return the log as an array, regardless of how the option was stored.
     * Some imports/migrations save the option as a JSON string (e.g. "[]"),
     * which would make array_reverse()/count() fatal on PHP 8+. Normalise it here.
     */
    private static function read_log(): array {
        $log = get_option( self::OPTION_KEY, [] );
        if ( is_string( $log ) ) {
            $decoded = json_decode( $log, true );
            $log     = is_array( $decoded ) ? $decoded : [];
        }
        return is_array( $log ) ? $log : [];
    }

    public static function clear(): void {
        update_option( self::OPTION_KEY, [], false );
    }
}
