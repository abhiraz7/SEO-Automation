<?php
/**
 * MCP Streamable HTTP transport — JSON-RPC 2.0
 *
 * POST /wp-json/cwpm/v1/mcp  — JSON-RPC request (single or batch)
 *      If request has Accept: text/event-stream → each response
 *      object is streamed as an SSE "message" event before exit.
 *
 * GET  /wp-json/cwpm/v1/mcp  — SSE keep-alive channel
 *      Requires Accept: text/event-stream; streams ": ping"
 *      comments every 15 s for up to 5 minutes.
 *
 * Spec: MCP protocol version 2024-11-05, Streamable HTTP transport.
 *
 * Supported JSON-RPC methods:
 *   initialize        resources/list     prompts/list
 *   ping              resources/read     prompts/get
 *   tools/list        notifications/*    (acknowledged silently)
 *   tools/call
 */
class CWPM_MCP {

    const PROTOCOL_VERSION = '2024-11-05';

    /* ════════════════════════════════════════════════════════
     *  WP REST entry points
     * ════════════════════════════════════════════════════════ */

    /**
     * POST /mcp — JSON-RPC 2.0 handler.
     * If the request has Accept: text/event-stream the responses are
     * streamed as SSE events and PHP exits; otherwise a normal
     * WP_REST_Response is returned.
     *
     * @return WP_REST_Response|void
     */
    public static function handle( WP_REST_Request $request ) {
        $accept = $request->get_header( 'accept' ) ?? '';
        $stream = strpos( $accept, 'text/event-stream' ) !== false;

        $body = $request->get_json_params();

        if ( ! is_array( $body ) ) {
            $err = self::make_error( null, -32700, 'Parse error: body must be a JSON object or array.' );
            if ( $stream ) { self::sse_emit_and_exit( [ $err ] ); }
            return new WP_REST_Response( $err, 400 );
        }

        /* Batch request */
        if ( isset( $body[0] ) && array_keys( $body ) === range( 0, count( $body ) - 1 ) ) {
            $responses = [];
            foreach ( $body as $msg ) {
                if ( is_array( $msg ) ) {
                    $r = self::dispatch( $msg );
                    if ( $r !== null ) $responses[] = $r;
                }
            }
            if ( $stream ) { self::sse_emit_and_exit( $responses ); }
            if ( empty( $responses ) ) {
                return new WP_REST_Response( null, 202 );
            }
            return new WP_REST_Response( $responses );
        }

        /* Single message */
        $resp = self::dispatch( $body );
        if ( $stream ) { self::sse_emit_and_exit( $resp !== null ? [ $resp ] : [] ); }
        return $resp !== null
            ? new WP_REST_Response( $resp )
            : new WP_REST_Response( null, 202 );
    }

    /**
     * GET /mcp — SSE keep-alive / server-push channel.
     * Requires Accept: text/event-stream.
     * Streams ": ping" comments every 15 s; never returns normally.
     *
     * @return WP_REST_Response|void
     */
    public static function handle_get( WP_REST_Request $request ) {
        $accept = $request->get_header( 'accept' ) ?? '';
        if ( strpos( $accept, 'text/event-stream' ) === false ) {
            return new WP_REST_Response(
                [ 'error' => 'GET /mcp requires Accept: text/event-stream' ],
                400
            );
        }
        self::open_sse_stream(); // never returns
    }

    /* ════════════════════════════════════════════════════════
     *  SSE helpers
     * ════════════════════════════════════════════════════════ */

    /**
     * Emit JSON-RPC responses as SSE message events, then exit.
     * Used for streaming POST responses when client sent Accept: text/event-stream.
     */
    private static function sse_emit_and_exit( array $responses ): void {
        while ( ob_get_level() > 0 ) { ob_end_clean(); }
        ob_implicit_flush( true );

        header( 'Content-Type: text/event-stream; charset=UTF-8' );
        header( 'Cache-Control: no-cache, no-store' );
        header( 'X-Accel-Buffering: no' ); // disable nginx proxy buffering

        if ( empty( $responses ) ) {
            echo ": done\n\n"; // SSE comment — acknowledges notification batch
        } else {
            foreach ( $responses as $msg ) {
                echo "event: message\n";
                echo 'data: ' . wp_json_encode( $msg, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "\n\n";
                @ob_flush(); flush();
            }
        }
        exit;
    }

    /**
     * Open a persistent SSE connection for GET /mcp.
     * Sends ": ping" keep-alive comments every 15 s.
     * Exits after client disconnects or 5-minute timeout.
     */
    private static function open_sse_stream(): void {
        while ( ob_get_level() > 0 ) { ob_end_clean(); }
        ob_implicit_flush( true );

        header( 'Content-Type: text/event-stream; charset=UTF-8' );
        header( 'Cache-Control: no-cache, no-store, must-revalidate' );
        header( 'Pragma: no-cache' );
        header( 'X-Accel-Buffering: no' );
        header( 'Connection: keep-alive' );

        set_time_limit( 0 );
        ignore_user_abort( false );

        CWPM_Logger::log( 'info', 'MCP SSE channel opened' );

        $start = time();
        while ( ! connection_aborted() && ( time() - $start ) < 300 ) {
            echo ": ping\n\n";
            @ob_flush(); flush();
            sleep( 15 );
        }

        CWPM_Logger::log( 'info', 'MCP SSE channel closed' );
        exit;
    }

    /* ════════════════════════════════════════════════════════
     *  JSON-RPC 2.0 dispatcher
     * ════════════════════════════════════════════════════════ */

    private static function dispatch( array $msg ): ?array {
        if ( ( $msg['jsonrpc'] ?? '' ) !== '2.0' ) {
            return self::make_error( $msg['id'] ?? null, -32600, 'Invalid Request: jsonrpc must be "2.0".' );
        }

        $method          = $msg['method'] ?? '';
        $id              = $msg['id']     ?? null;
        $params          = is_array( $msg['params'] ?? null ) ? $msg['params'] : [];
        $is_notification = ! array_key_exists( 'id', $msg );

        switch ( $method ) {
            case 'initialize':
                return self::handle_initialize( $id, $params );
            case 'ping':
                return self::make_result( $id, new stdClass() );
            case 'tools/list':
                return self::handle_tools_list( $id );
            case 'tools/call':
                return self::handle_tools_call( $id, $params );
            case 'resources/list':
                return self::handle_resources_list( $id, $params );
            case 'resources/read':
                return self::handle_resource_read( $id, $params );
            case 'prompts/list':
                return self::handle_prompts_list( $id );
            case 'prompts/get':
                return self::handle_prompt_get( $id, $params );
            default:
                if ( $is_notification ) return null; // silently acknowledge
                return self::make_error( $id, -32601, "Method not found: {$method}" );
        }
    }

    /* ════════════════════════════════════════════════════════
     *  initialize
     * ════════════════════════════════════════════════════════ */

    private static function handle_initialize( $id, array $params ): array {
        $client = $params['clientInfo']['name'] ?? 'unknown';
        CWPM_Logger::log( 'info', "MCP session initialized by: {$client}" );

        return self::make_result( $id, [
            'protocolVersion' => self::PROTOCOL_VERSION,
            'capabilities'    => [
                'tools'     => (object) [],
                'resources' => [ 'subscribe' => false, 'listChanged' => false ],
                'prompts'   => [ 'listChanged' => false ],
            ],
            'serverInfo'  => [
                'name'    => 'claude-wp-developer',
                'version' => CWPM_VERSION,
            ],
            'instructions' => self::build_instructions(),
        ] );
    }

    /* ════════════════════════════════════════════════════════
     *  tools/list
     * ════════════════════════════════════════════════════════ */

    private static function handle_tools_list( $id ): array {
        $allowed = json_decode( get_option( 'cwpm_allowed_actions', '[]' ), true );

        $group_map = [
            'create_post'               => 'content',
            'update_post'               => 'content',
            'get_post'                  => 'content',
            'list_posts'                => 'content',
            'delete_post'               => 'content',
            'schedule_post'             => 'content',
            'set_featured_image'        => 'content',
            'get_taxonomies'            => 'content',
            'assign_terms'              => 'content',
            'elementor_get_data'        => 'elementor',
            'elementor_set_data'        => 'elementor',
            'elementor_build_page'      => 'elementor',
            'elementor_list_widgets'    => 'elementor',
            'elementor_get_globals'     => 'elementor',
            'elementor_set_globals'     => 'elementor',
            'elementor_list_templates'  => 'elementor',
            'elementor_import_template' => 'elementor',
            'yoast_get_meta'            => 'seo',
            'yoast_set_meta'            => 'seo',
            'yoast_audit'               => 'seo',
            'yoast_sitemap_ping'        => 'seo',
            'upload_media'              => 'media',
            'list_media'                => 'media',
            'get_media'                 => 'media',
            'delete_media'              => 'media',
            'update_media_meta'         => 'media',
            'list_plugins'              => 'plugins',
            'activate_plugin'           => 'plugins',
            'deactivate_plugin'         => 'plugins',
            'install_plugin'            => 'plugins',
            'get_plugin_settings'       => 'plugins',
            'set_plugin_settings'       => 'plugins',
            'get_theme_mods'            => 'theme',
            'set_theme_mods'            => 'theme',
            'get_menus'                 => 'theme',
            'set_menu_items'            => 'theme',
            'get_widgets'               => 'theme',
            'get_options'               => 'theme',
            'set_option'                => 'theme',
            'php_exec'                  => 'php_exec',
            'get_site_info'             => 'wordpress',
            'list_users'                => 'wordpress',
            'get_user'                  => 'wordpress',
            'create_term'               => 'wordpress',
            'delete_term'               => 'wordpress',
            'flush_cache'               => 'wordpress',
            'search_replace'            => 'wordpress',
            'get_active_theme'          => 'wordpress',
            'activate_theme'            => 'wordpress',
            'run_cron'                  => 'wordpress',
            'woo_list_products'         => 'woocommerce',
            'woo_get_product'           => 'woocommerce',
            'woo_create_product'        => 'woocommerce',
            'woo_update_product'        => 'woocommerce',
            'woo_list_orders'           => 'woocommerce',
            'woo_get_order'             => 'woocommerce',
            'list_forms'                => 'forms',
            'list_form_entries'         => 'forms',
            'get_form_entry'            => 'forms',
            'list_email_logs'           => 'email',
            'divi_get_data'             => 'divi',
            'divi_set_data'             => 'divi',
            'divi_build_page'           => 'divi',
            'divi_list_modules'         => 'divi',
            'divi_get_globals'          => 'divi',
            'divi_set_globals'          => 'divi',
            'divi_list_layouts'         => 'divi',
            'divi_import_layout'        => 'divi',
            'divi_flush_cache'          => 'divi',
            'divi_get_theme_builder'    => 'divi',
        ];

        $tools = array_values( array_filter(
            self::tool_definitions(),
            fn( $t ) => in_array( $group_map[ $t['name'] ] ?? '', $allowed, true )
        ) );

        return self::make_result( $id, [ 'tools' => $tools ] );
    }

    /* ════════════════════════════════════════════════════════
     *  tools/call
     * ════════════════════════════════════════════════════════ */

    private static function handle_tools_call( $id, array $params ): array {
        $name      = sanitize_key( $params['name'] ?? '' );
        $arguments = is_array( $params['arguments'] ?? null ) ? $params['arguments'] : [];
        $allowed   = json_decode( get_option( 'cwpm_allowed_actions', '[]' ), true );

        CWPM_Logger::log( 'info', "MCP tools/call: {$name}" );

        try {
            $result = CWPM_Router::call_tool( $name, $arguments, $allowed );
            return self::make_result( $id, [
                'content' => [ [
                    'type' => 'text',
                    'text' => wp_json_encode( $result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
                ] ],
                'isError' => false,
            ] );
        } catch ( Throwable $e ) {
            CWPM_Logger::log( 'error', "MCP tools/call '{$name}': " . $e->getMessage() );
            return self::make_result( $id, [
                'content' => [ [ 'type' => 'text', 'text' => $e->getMessage() ] ],
                'isError' => true,
            ] );
        }
    }

    /* ════════════════════════════════════════════════════════
     *  resources/list
     * ════════════════════════════════════════════════════════ */

    private static function handle_resources_list( $id, array $params ): array {
        $cursor   = $params['cursor'] ?? null;
        $paged    = $cursor ? max( 1, intval( base64_decode( $cursor ) ) ) : 1;
        $per_page = 15;

        $resources = [];

        // Posts + pages (most recently modified first)
        $posts = get_posts( [
            'post_type'      => [ 'post', 'page' ],
            'post_status'    => 'publish',
            'posts_per_page' => $per_page,
            'paged'          => $paged,
            'orderby'        => 'modified',
            'order'          => 'DESC',
            'no_found_rows'  => false,
        ] );

        foreach ( $posts as $post ) {
            $snippet = wp_strip_all_tags( $post->post_excerpt ?: $post->post_content );
            $resources[] = [
                'uri'         => "wp://{$post->post_type}/{$post->ID}",
                'name'        => $post->post_title ?: "(#{$post->ID})",
                'description' => wp_trim_words( $snippet, 20 ),
                'mimeType'    => 'application/json',
            ];
        }

        // Recent media items
        $media = get_posts( [
            'post_type'      => 'attachment',
            'post_status'    => 'inherit',
            'posts_per_page' => 8,
            'paged'          => $paged,
            'orderby'        => 'modified',
            'order'          => 'DESC',
        ] );

        foreach ( $media as $item ) {
            $mime = get_post_mime_type( $item->ID ) ?: 'application/octet-stream';
            $file = get_attached_file( $item->ID );
            $resources[] = [
                'uri'      => "wp://media/{$item->ID}",
                'name'     => $item->post_title ?: ( $file ? basename( $file ) : "media-{$item->ID}" ),
                'mimeType' => $mime,
            ];
        }

        $result = [ 'resources' => $resources ];
        if ( count( $posts ) === $per_page ) {
            $result['nextCursor'] = base64_encode( (string) ( $paged + 1 ) );
        }

        return self::make_result( $id, $result );
    }

    /* ════════════════════════════════════════════════════════
     *  resources/read
     * ════════════════════════════════════════════════════════ */

    private static function handle_resource_read( $id, array $params ): array {
        $uri = $params['uri'] ?? '';

        if ( ! preg_match( '#^wp://([^/]+)/(\d+)$#', $uri, $m ) ) {
            return self::make_error( $id, -32602, "Invalid resource URI: {$uri}. Expected wp://type/id" );
        }

        $type    = $m[1];
        $post_id = intval( $m[2] );

        /* ── Media ── */
        if ( $type === 'media' ) {
            $post = get_post( $post_id );
            if ( ! $post ) {
                return self::make_error( $id, -32602, "Media not found: {$post_id}" );
            }
            $data = wp_json_encode( [
                'id'       => $post_id,
                'title'    => $post->post_title,
                'url'      => wp_get_attachment_url( $post_id ),
                'alt'      => get_post_meta( $post_id, '_wp_attachment_image_alt', true ),
                'caption'  => $post->post_excerpt,
                'mime'     => get_post_mime_type( $post_id ),
                'metadata' => wp_get_attachment_metadata( $post_id ),
            ], JSON_UNESCAPED_SLASHES );
            return self::make_result( $id, [ 'contents' => [ [
                'uri'      => $uri,
                'mimeType' => 'application/json',
                'text'     => $data,
            ] ] ] );
        }

        /* ── Post / Page ── */
        $post = get_post( $post_id );
        if ( ! $post ) {
            return self::make_error( $id, -32602, "Post not found: {$post_id}" );
        }

        $raw_meta  = get_post_meta( $post_id );
        $flat_meta = array_map( fn( $v ) => count( $v ) === 1 ? $v[0] : $v, $raw_meta );
        $terms_out = [];
        foreach ( get_post_taxonomies( $post ) as $tax ) {
            $t = wp_get_post_terms( $post_id, $tax );
            if ( ! is_wp_error( $t ) ) {
                $terms_out[ $tax ] = wp_list_pluck( $t, 'name' );
            }
        }

        $data = wp_json_encode( [
            'id'       => $post_id,
            'title'    => $post->post_title,
            'content'  => $post->post_content,
            'excerpt'  => $post->post_excerpt,
            'status'   => $post->post_status,
            'type'     => $post->post_type,
            'author'   => get_the_author_meta( 'display_name', $post->post_author ),
            'date'     => $post->post_date,
            'modified' => $post->post_modified,
            'url'      => get_permalink( $post_id ),
            'slug'     => $post->post_name,
            'terms'    => $terms_out,
            'meta'     => $flat_meta,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );

        return self::make_result( $id, [ 'contents' => [ [
            'uri'      => $uri,
            'mimeType' => 'application/json',
            'text'     => $data,
        ] ] ] );
    }

    /* ════════════════════════════════════════════════════════
     *  prompts/list
     * ════════════════════════════════════════════════════════ */

    private static function handle_prompts_list( $id ): array {
        return self::make_result( $id, [ 'prompts' => [
            [
                'name'        => 'seo_blog_post',
                'description' => 'Create a fully SEO-optimised blog post with Yoast meta, featured image, and publish',
                'arguments'   => [
                    [ 'name' => 'topic',      'description' => 'Blog post topic',       'required' => true  ],
                    [ 'name' => 'keyword',    'description' => 'Primary focus keyword', 'required' => true  ],
                    [ 'name' => 'word_count', 'description' => 'Target word count',     'required' => false ],
                ],
            ],
            [
                'name'        => 'elementor_landing_page',
                'description' => 'Build a complete Elementor landing page (hero + features + social proof + CTA)',
                'arguments'   => [
                    [ 'name' => 'product', 'description' => 'Product or service name', 'required' => true  ],
                    [ 'name' => 'tagline', 'description' => 'Hero tagline',            'required' => false ],
                    [ 'name' => 'cta',     'description' => 'Call-to-action text',     'required' => false ],
                ],
            ],
            [
                'name'        => 'seo_audit',
                'description' => 'Audit SEO health — single post or site-wide top 10',
                'arguments'   => [
                    [ 'name' => 'post_id', 'description' => 'Post ID (omit for site-wide)', 'required' => false ],
                ],
            ],
            [
                'name'        => 'woo_product_setup',
                'description' => 'Create a WooCommerce product with description, image, SEO meta, and publish',
                'arguments'   => [
                    [ 'name' => 'product_name', 'description' => 'Product name',              'required' => true  ],
                    [ 'name' => 'price',         'description' => 'Regular price (e.g. 29.99)', 'required' => true  ],
                    [ 'name' => 'description',   'description' => 'Short product description', 'required' => false ],
                ],
            ],
            [
                'name'        => 'content_migration',
                'description' => 'Scrape a URL and create a WordPress post with Elementor layout',
                'arguments'   => [
                    [ 'name' => 'url',       'description' => 'Source URL to migrate',  'required' => true  ],
                    [ 'name' => 'post_type', 'description' => 'Target post type',       'required' => false ],
                ],
            ],
            [
                'name'        => 'elementor_section_builder',
                'description' => 'Append a new Elementor section to an existing page',
                'arguments'   => [
                    [ 'name' => 'post_id',         'description' => 'Existing page ID',           'required' => true  ],
                    [ 'name' => 'section_purpose', 'description' => 'What this section should do', 'required' => true  ],
                    [ 'name' => 'style',           'description' => 'dark / light / gradient',     'required' => false ],
                ],
            ],
            [
                'name'        => 'divi_landing_page',
                'description' => 'Build a complete Divi landing page (hero + features + social proof + CTA)',
                'arguments'   => [
                    [ 'name' => 'product',  'description' => 'Product or service name',            'required' => true  ],
                    [ 'name' => 'tagline',  'description' => 'Hero tagline',                       'required' => false ],
                    [ 'name' => 'cta',      'description' => 'Call-to-action button text',         'required' => false ],
                    [ 'name' => 'style',    'description' => 'Color style: dark / light / branded', 'required' => false ],
                ],
            ],
            [
                'name'        => 'divi_section_builder',
                'description' => 'Append a new Divi section to an existing page',
                'arguments'   => [
                    [ 'name' => 'post_id',         'description' => 'Existing Divi page ID',        'required' => true  ],
                    [ 'name' => 'section_purpose', 'description' => 'What this section should do',  'required' => true  ],
                    [ 'name' => 'style',           'description' => 'dark / light / gradient',      'required' => false ],
                ],
            ],
        ] ] );
    }

    /* ════════════════════════════════════════════════════════
     *  prompts/get
     * ════════════════════════════════════════════════════════ */

    private static function handle_prompt_get( $id, array $params ): array {
        $name = $params['name'] ?? '';
        $args = $params['arguments'] ?? [];

        $site = get_bloginfo( 'name' );
        $url  = get_bloginfo( 'url' );

        switch ( $name ) {

            case 'seo_blog_post':
                $topic   = $args['topic']      ?? 'your topic';
                $kw      = $args['keyword']    ?? 'focus keyword';
                $wc      = $args['word_count'] ?? '1200–1500';
                return self::make_result( $id, [
                    'description' => "Write an SEO blog post about \"{$topic}\" for {$site}",
                    'messages'    => [ [ 'role' => 'user', 'content' => [ 'type' => 'text', 'text' =>
"Create a fully SEO-optimised blog post for **{$site}** ({$url}) on the topic: **{$topic}**
Target keyword: `{$kw}` | Target length: {$wc} words

Steps:
1. `create_post` — status=draft, title optimised for `{$kw}` (≤60 chars), body {$wc} words using the keyword naturally
2. `yoast_set_meta` — seo_title ≤60 chars (keyword near start), meta_description ≤155 chars with a CTA, focus_keyword=\"{$kw}\"
3. Find a relevant image URL, `upload_media`, then `set_featured_image`
4. `yoast_audit` — fix any red/orange issues until score ≥ 70
5. `update_post` status=publish" ] ] ],
                ] );

            case 'elementor_landing_page':
                $product = $args['product'] ?? 'the product';
                $tagline = $args['tagline'] ?? "Transform your results with {$product}";
                $cta     = $args['cta']     ?? 'Get Started Free';
                return self::make_result( $id, [
                    'description' => "Build Elementor landing page for \"{$product}\"",
                    'messages'    => [ [ 'role' => 'user', 'content' => [ 'type' => 'text', 'text' =>
"Build a complete Elementor landing page for **{$product}** on {$site} ({$url}).

Steps:
1. `create_post` type=page, title=\"{$product}\", status=draft
2. `elementor_build_page` with four sections:
   - **Hero** — full-width dark gradient, heading \"{$product}\", subheading \"{$tagline}\", button \"{$cta}\"
   - **Features** — 3-column icon-boxes with 3 key benefits
   - **Social Proof** — counter widgets or testimonials
   - **CTA** — centered section, button \"{$cta}\"
3. `yoast_set_meta` — product-focused title and description
4. `flush_cache`
5. `update_post` status=publish — return URL" ] ] ],
                ] );

            case 'seo_audit':
                $pid = isset( $args['post_id'] ) ? intval( $args['post_id'] ) : null;
                return self::make_result( $id, [
                    'description' => $pid ? "SEO audit for post #{$pid}" : "Site-wide SEO audit for {$site}",
                    'messages'    => [ [ 'role' => 'user', 'content' => [ 'type' => 'text', 'text' => $pid
                        ? "Audit SEO on post #{$pid} at {$site}:\n1. `get_post` — read content\n2. `yoast_get_meta` — read current meta\n3. `yoast_audit` — get score and issues\nReport: current score, missing meta, keyword gaps, content issues, and the exact fixes to apply."
                        : "Site-wide SEO audit for {$site} ({$url}):\n1. `get_site_info` — overall stats\n2. `list_posts` type=post status=publish per_page=10 — recent posts\n3. `yoast_audit` for each post\nReport: overall health score, the 3 posts needing most work, and specific action items per post."
                    ] ] ],
                ] );

            case 'woo_product_setup':
                $pname = $args['product_name'] ?? 'New Product';
                $price = $args['price']        ?? '0.00';
                $desc  = $args['description']  ?? 'A great product';
                return self::make_result( $id, [
                    'description' => "Set up WooCommerce product: {$pname}",
                    'messages'    => [ [ 'role' => 'user', 'content' => [ 'type' => 'text', 'text' =>
"Create a complete WooCommerce product on {$site}:
- Name: **{$pname}** | Price: {$price}
- Description hint: {$desc}

Steps:
1. `woo_create_product` — name, regular_price, expanded description and short_description, status=draft
2. Find a relevant product image, `upload_media` it
3. `woo_update_product` — set image_id from step 2
4. `yoast_set_meta` — product-focused seo_title and meta_description
5. `woo_update_product` status=publish — return product URL" ] ] ],
                ] );

            case 'content_migration':
                $src  = $args['url']       ?? 'https://example.com/page';
                $type = $args['post_type'] ?? 'post';
                return self::make_result( $id, [
                    'description' => "Migrate content from {$src}",
                    'messages'    => [ [ 'role' => 'user', 'content' => [ 'type' => 'text', 'text' =>
"Migrate content from {$src} to {$site} as a WordPress {$type}.

Steps:
1. Fetch and read {$src}
2. `create_post` type={$type}, status=draft — title and content adapted from the source
3. If the source has a main image, `upload_media` it and `set_featured_image`
4. `yoast_set_meta` — title, description, and keyword from the content
5. Report new post ID and URL; note any content that could not be migrated" ] ] ],
                ] );

            case 'elementor_section_builder':
                $pid     = intval( $args['post_id']         ?? 0 );
                $purpose = $args['section_purpose'] ?? 'highlight a feature';
                $style   = $args['style']           ?? 'light';
                return self::make_result( $id, [
                    'description' => "Append Elementor section to page #{$pid}",
                    'messages'    => [ [ 'role' => 'user', 'content' => [ 'type' => 'text', 'text' =>
"Add a new Elementor section to page #{$pid} on {$site}.
Purpose: {$purpose} | Style: {$style}

Steps:
1. `elementor_get_data` — read existing page structure
2. Design a new section to {$purpose} using appropriate widgets for a {$style} style
3. `elementor_set_data` — existing sections PLUS new section appended at the end
4. `flush_cache` — regenerate CSS
5. Return the page URL for review" ] ] ],
                ] );

            case 'divi_landing_page':
                $product = $args['product'] ?? 'the product';
                $tagline = $args['tagline'] ?? "Transform your results with {$product}";
                $cta     = $args['cta']     ?? 'Get Started';
                $style   = $args['style']   ?? 'dark';
                $hero_bg = $style === 'light' ? '#f9f9f9' : '#1a1a2e';
                $hero_tc = $style === 'light' ? '#333333' : '#ffffff';
                return self::make_result( $id, [
                    'description' => "Build Divi landing page for \"{$product}\"",
                    'messages'    => [ [ 'role' => 'user', 'content' => [ 'type' => 'text', 'text' =>
"Build a complete Divi landing page for **{$product}** on {$site} ({$url}).

Steps:
1. `create_post` type=page, title=\"{$product}\", status=draft — note the returned post_id
2. `divi_build_page` with four sections:
   - **Hero** — section background gradient or color {$hero_bg}, full padding, single column:
       et_pb_text (H1 \"{$product}\", H2 \"{$tagline}\", text_color {$hero_tc})
       et_pb_button (text \"{$cta}\", url=\"#contact\", align=center)
   - **Features** — light background, 3-column row (layout \"1_3 1_3 1_3\"), each column one et_pb_blurb (icon, title, 1-sentence benefit)
   - **Social Proof** — dark background, 3-column row, each column one et_pb_number_counter (key stat + title)
   - **CTA** — branded background, single column: et_pb_cta (title, description, button_text \"{$cta}\")
3. `yoast_set_meta` — product-focused seo_title and meta_description
4. `divi_flush_cache`
5. `update_post` status=publish — return URL" ] ] ],
                ] );

            case 'divi_section_builder':
                $pid     = intval( $args['post_id']         ?? 0 );
                $purpose = $args['section_purpose'] ?? 'highlight a feature';
                $style   = $args['style']           ?? 'light';
                return self::make_result( $id, [
                    'description' => "Append Divi section to page #{$pid}",
                    'messages'    => [ [ 'role' => 'user', 'content' => [ 'type' => 'text', 'text' =>
"Add a new Divi section to page #{$pid} on {$site}.
Purpose: {$purpose} | Style: {$style}

Steps:
1. `divi_get_data` post_id={$pid} — read existing shortcodes
2. Design a section that {$purpose} using appropriate Divi modules for a {$style} style
3. `divi_import_layout` with append=true, OR build new shortcodes and `divi_set_data` with existing+new shortcodes
4. `divi_flush_cache` post_id={$pid}
5. Return the page URL for review" ] ] ],
                ] );

            default:
                return self::make_error( $id, -32602, "Unknown prompt: {$name}" );
        }
    }

    /* ════════════════════════════════════════════════════════
     *  Helpers
     * ════════════════════════════════════════════════════════ */

    private static function make_result( $id, $result ): array {
        return [ 'jsonrpc' => '2.0', 'id' => $id, 'result' => $result ];
    }

    private static function make_error( $id, int $code, string $message ): array {
        return [ 'jsonrpc' => '2.0', 'id' => $id, 'error' => [ 'code' => $code, 'message' => $message ] ];
    }

    private static function build_instructions(): string {
        $name  = get_bloginfo( 'name' );
        $url   = get_bloginfo( 'url' );
        $ver   = get_bloginfo( 'version' );
        $theme = wp_get_theme()->get( 'Name' );
        $parts = [ "Connected to WordPress \"{$name}\" at {$url} (WP {$ver}, theme: {$theme})." ];

        if ( class_exists( '\Elementor\Plugin' ) )        $parts[] = 'Elementor active.';
        if ( defined( 'ET_BUILDER_PRODUCT_VERSION' ) ) {
            $dv = ET_BUILDER_PRODUCT_VERSION;
            $parts[] = "Divi Builder active (v{$dv}).";
        } elseif ( function_exists( 'et_setup_theme' ) || defined( 'ET_CORE_VERSION' ) ) {
            $parts[] = 'Divi Builder active.';
        }
        if ( defined( 'WPSEO_VERSION' ) )                 $parts[] = 'Yoast SEO active.';
        if ( class_exists( 'WooCommerce' ) )              $parts[] = 'WooCommerce active.';
        if ( post_type_exists( 'metform-entry' ) )        $parts[] = 'MetForm active.';
        if ( class_exists( 'WPForms' ) )                  $parts[] = 'WPForms active.';
        if ( class_exists( 'FluentSmtp\App' ) || defined( 'FLUENTMAIL' ) ) $parts[] = 'FluentSMTP active.';

        $allowed = json_decode( get_option( 'cwpm_allowed_actions', '[]' ), true );
        $parts[] = 'Enabled groups: ' . implode( ', ', $allowed ) . '.';
        $parts[] = 'Use resources/list to browse posts/pages/media. Use prompts/list for workflow templates.';
        $parts[] = 'Call flush_cache after bulk changes. Use dry_run:true on search_replace to preview.';

        return implode( ' ', $parts );
    }

    /* ════════════════════════════════════════════════════════
     *  Schema shorthand helpers
     * ════════════════════════════════════════════════════════ */

    private static function tool( string $name, string $desc, array $props = [], array $req = [] ): array {
        return [
            'name'        => $name,
            'description' => $desc,
            'inputSchema' => [
                'type'       => 'object',
                'properties' => empty( $props ) ? new stdClass() : $props,
                'required'   => $req,
            ],
        ];
    }

    private static function s( string $d, array $enum = [] ): array {
        $p = [ 'type' => 'string', 'description' => $d ];
        if ( $enum ) $p['enum'] = $enum;
        return $p;
    }
    private static function i( string $d ): array { return [ 'type' => 'integer', 'description' => $d ]; }
    private static function b( string $d ): array { return [ 'type' => 'boolean', 'description' => $d ]; }
    private static function o( string $d ): array { return [ 'type' => 'object',  'description' => $d ]; }
    private static function a( string $d, ?array $items = null ): array {
        $p = [ 'type' => 'array', 'description' => $d ];
        if ( $items ) $p['items'] = $items;
        return $p;
    }

    /* ════════════════════════════════════════════════════════
     *  Tool definitions (JSON Schema inputSchema)
     * ════════════════════════════════════════════════════════ */

    private static function tool_definitions(): array {
        $status_enum = [ 'draft', 'publish', 'private', 'pending', 'future', 'trash' ];
        $int_item    = [ 'type' => 'integer' ];
        $str_item    = [ 'type' => 'string' ];

        return [

            /* ── Content ─────────────────────────────────────── */
            self::tool( 'create_post',
                'Create any post type (post, page, custom CPT). Supports scheduling, excerpt, custom fields, and term assignment.',
                [
                    'title'          => self::s( 'Post title.' ),
                    'content'        => self::s( 'Post body — HTML or Gutenberg blocks.' ),
                    'status'         => self::s( 'Post status.', [ 'draft', 'publish', 'private', 'pending', 'future' ] ),
                    'type'           => self::s( 'Post type slug (post, page, or custom CPT). Default: post.' ),
                    'excerpt'        => self::s( 'Short excerpt.' ),
                    'slug'           => self::s( 'URL slug. Auto-generated from title if omitted.' ),
                    'date'           => self::s( 'Publish/schedule datetime "Y-m-d H:i:s". Auto-sets status to future if in future.' ),
                    'author_id'      => self::i( 'Author user ID. Defaults to current user.' ),
                    'comment_status' => self::s( 'Comment status.', [ 'open', 'closed' ] ),
                    'password'       => self::s( 'Post password (for protected posts).' ),
                    'meta'           => self::o( 'Custom fields as {key: value} pairs.' ),
                    'terms'          => self::o( 'Taxonomy term IDs as {"taxonomy": [id,...]}.' ),
                ]
            ),

            self::tool( 'update_post',
                'Update any field of an existing post.',
                [
                    'post_id' => self::i( 'Post ID to update.' ),
                    'title'   => self::s( 'New post title.' ),
                    'content' => self::s( 'New post body.' ),
                    'status'  => self::s( 'New post status.', $status_enum ),
                    'excerpt' => self::s( 'New excerpt.' ),
                    'slug'    => self::s( 'New URL slug.' ),
                    'date'    => self::s( 'New publish date "Y-m-d H:i:s".' ),
                    'meta'    => self::o( 'Custom fields to update as {key: value}.' ),
                ],
                [ 'post_id' ]
            ),

            self::tool( 'get_post',
                'Get full post data including meta, terms, thumbnail, and raw Elementor JSON.',
                [ 'post_id' => self::i( 'Post ID.' ) ],
                [ 'post_id' ]
            ),

            self::tool( 'list_posts',
                'List posts with filters. Returns id, title, status, type, date, url.',
                [
                    'type'      => self::s( 'Post type filter. Default: any.' ),
                    'status'    => self::s( 'Post status filter. Default: any.' ),
                    'per_page'  => self::i( 'Results per page. Default: 20.' ),
                    'page'      => self::i( 'Page number. Default: 1.' ),
                    'search'    => self::s( 'Keyword search.' ),
                    'author_id' => self::i( 'Filter by author user ID.' ),
                ]
            ),

            self::tool( 'delete_post',
                'Trash or permanently delete a post.',
                [
                    'post_id' => self::i( 'Post ID.' ),
                    'force'   => self::b( 'true = permanent delete, false = move to trash. Default: false.' ),
                ],
                [ 'post_id' ]
            ),

            self::tool( 'schedule_post',
                'Schedule a post to publish at a specific datetime.',
                [
                    'post_id' => self::i( 'Post ID.' ),
                    'date'    => self::s( 'Publish datetime "Y-m-d H:i:s" in site timezone.' ),
                ],
                [ 'post_id', 'date' ]
            ),

            self::tool( 'set_featured_image',
                'Set or remove the featured image on a post.',
                [
                    'post_id'  => self::i( 'Post ID.' ),
                    'media_id' => self::i( 'Attachment ID. Omit or 0 to remove.' ),
                ],
                [ 'post_id' ]
            ),

            self::tool( 'get_taxonomies',
                'List all registered taxonomies with their terms (up to 200 terms per taxonomy).'
            ),

            self::tool( 'assign_terms',
                'Add, replace, or append taxonomy terms to a post.',
                [
                    'post_id'  => self::i( 'Post ID.' ),
                    'taxonomy' => self::s( 'Taxonomy slug (category, post_tag, or custom). Default: category.' ),
                    'term_ids' => self::a( 'Array of term IDs.', $int_item ),
                    'append'   => self::b( 'true = add to existing. false = replace all (default).' ),
                ],
                [ 'post_id', 'term_ids' ]
            ),

            /* ── Elementor ────────────────────────────────────── */
            self::tool( 'elementor_get_data',
                'Get the raw Elementor JSON for a post or page.',
                [ 'post_id' => self::i( 'Post ID.' ) ],
                [ 'post_id' ]
            ),

            self::tool( 'elementor_set_data',
                'Replace the entire Elementor JSON on a post or page. Clears CSS cache automatically.',
                [
                    'post_id' => self::i( 'Post ID.' ),
                    'data'    => self::a( 'Elementor sections array (raw Elementor JSON structure).' ),
                ],
                [ 'post_id', 'data' ]
            ),

            self::tool( 'elementor_build_page',
                'Build a complete Elementor page from a high-level layout spec. Structure: sections → columns → widgets.',
                [
                    'post_id'  => self::i( 'Post ID to build on.' ),
                    'sections' => self::a( 'Array of section objects with columns and widgets.' ),
                ],
                [ 'post_id', 'sections' ]
            ),

            self::tool( 'elementor_list_widgets',
                'List all registered Elementor widgets with their controls.'
            ),

            self::tool( 'elementor_get_globals',
                'Get Elementor global colors and global typography settings.'
            ),

            self::tool( 'elementor_set_globals',
                'Update Elementor global colors or global typography.',
                [ 'globals' => self::o( 'Object with colors and/or typography arrays.' ) ],
                [ 'globals' ]
            ),

            self::tool( 'elementor_list_templates',
                'List all saved Elementor templates in the template library.',
                [
                    'type' => self::s( 'Filter by template type: page, section, container, popup. Default: all.' ),
                ]
            ),

            self::tool( 'elementor_import_template',
                'Apply a saved Elementor template to a post/page (replaces existing Elementor data).',
                [
                    'post_id'     => self::i( 'Target post/page ID.' ),
                    'template_id' => self::i( 'Elementor template post ID (from elementor_list_templates).' ),
                ],
                [ 'post_id', 'template_id' ]
            ),

            /* ── SEO ──────────────────────────────────────────── */
            self::tool( 'yoast_get_meta',
                'Get all Yoast SEO meta fields for a post.',
                [ 'post_id' => self::i( 'Post ID.' ) ],
                [ 'post_id' ]
            ),

            self::tool( 'yoast_set_meta',
                'Set Yoast SEO meta on a post (title, description, focus keyword, OG, canonical, schema, robots).',
                [
                    'post_id'             => self::i( 'Post ID.' ),
                    'seo_title'           => self::s( 'SEO title (recommended ≤60 chars).' ),
                    'meta_description'    => self::s( 'Meta description (recommended ≤155 chars).' ),
                    'focus_keyword'       => self::s( 'Primary focus keyword.' ),
                    'canonical_url'       => self::s( 'Canonical URL override.' ),
                    'og_title'            => self::s( 'Open Graph title.' ),
                    'og_description'      => self::s( 'Open Graph description.' ),
                    'og_image'            => self::s( 'Open Graph image URL.' ),
                    'twitter_title'       => self::s( 'Twitter card title.' ),
                    'twitter_description' => self::s( 'Twitter card description.' ),
                    'noindex'             => self::s( 'Set to "1" to noindex.' ),
                    'nofollow'            => self::s( 'Set to "1" to nofollow.' ),
                    'is_cornerstone'      => self::s( 'Set to "1" to mark as cornerstone content.' ),
                    'schema_article_type' => self::s( 'Yoast schema article type.' ),
                    'schema_page_type'    => self::s( 'Yoast schema page type.' ),
                    'primary_category'    => self::i( 'Primary category term ID.' ),
                ],
                [ 'post_id' ]
            ),

            self::tool( 'yoast_audit',
                'Run a Yoast SEO quality audit on a post. Returns issues, passes, and a score.',
                [ 'post_id' => self::i( 'Post ID.' ) ],
                [ 'post_id' ]
            ),

            self::tool( 'yoast_sitemap_ping',
                'Notify Google and Bing that the sitemap has been updated.'
            ),

            /* ── Media ────────────────────────────────────────── */
            self::tool( 'upload_media',
                'Upload a file to the media library from a public URL or a base64-encoded string.',
                [
                    'url'      => self::s( 'Public URL of the file to download. Use this OR base64.' ),
                    'base64'   => self::s( 'Base64-encoded file content. Use this OR url.' ),
                    'filename' => self::s( 'Filename for base64 uploads, e.g. "photo.jpg".' ),
                    'title'    => self::s( 'Attachment title.' ),
                    'alt'      => self::s( 'Alt text (for images).' ),
                    'caption'  => self::s( 'Caption text.' ),
                    'post_id'  => self::i( 'Attach to this post ID (optional).' ),
                ]
            ),

            self::tool( 'list_media',
                'Search and list media library items.',
                [
                    'per_page'  => self::i( 'Results per page. Default: 20.' ),
                    'page'      => self::i( 'Page number. Default: 1.' ),
                    'search'    => self::s( 'Keyword search.' ),
                    'mime_type' => self::s( 'MIME type filter, e.g. "image/jpeg" or "image".' ),
                ]
            ),

            self::tool( 'get_media',
                'Get a single media item with all image sizes and metadata.',
                [ 'media_id' => self::i( 'Attachment ID.' ) ],
                [ 'media_id' ]
            ),

            self::tool( 'delete_media',
                'Delete a media attachment from the library.',
                [
                    'media_id' => self::i( 'Attachment ID.' ),
                    'force'    => self::b( 'true = permanent delete. false = trash (default).' ),
                ],
                [ 'media_id' ]
            ),

            self::tool( 'update_media_meta',
                'Update the alt text, caption, title, or description of a media item.',
                [
                    'media_id'    => self::i( 'Attachment ID.' ),
                    'title'       => self::s( 'New title.' ),
                    'alt'         => self::s( 'New alt text.' ),
                    'caption'     => self::s( 'New caption.' ),
                    'description' => self::s( 'New description.' ),
                ],
                [ 'media_id' ]
            ),

            /* ── Plugins ──────────────────────────────────────── */
            self::tool( 'list_plugins',
                'List all installed plugins with name, version, and active status.',
                [ 'active_only' => self::b( 'If true, return only active plugins.' ) ]
            ),

            self::tool( 'activate_plugin',
                'Activate a plugin by file path or slug.',
                [
                    'plugin_file' => self::s( 'Plugin file path relative to wp-content/plugins/ e.g. "woocommerce/woocommerce.php".' ),
                    'slug'        => self::s( 'Plugin slug — constructs path as slug/slug.php.' ),
                ]
            ),

            self::tool( 'deactivate_plugin',
                'Deactivate a plugin.',
                [
                    'plugin_file' => self::s( 'Plugin file path.' ),
                    'slug'        => self::s( 'Plugin slug.' ),
                ]
            ),

            self::tool( 'install_plugin',
                'Install a free plugin from WordPress.org by slug.',
                [ 'slug' => self::s( 'WordPress.org plugin slug, e.g. "woocommerce".' ) ],
                [ 'slug' ]
            ),

            self::tool( 'get_plugin_settings',
                'Read plugin option values from wp_options.',
                [ 'option_keys' => self::a( 'Array of option key strings to read.', $str_item ) ],
                [ 'option_keys' ]
            ),

            self::tool( 'set_plugin_settings',
                'Write option values to wp_options.',
                [ 'settings' => self::o( '{option_key: value} pairs to write.' ) ],
                [ 'settings' ]
            ),

            /* ── Theme ────────────────────────────────────────── */
            self::tool( 'get_theme_mods',
                'Get all active theme customizer modifications.'
            ),

            self::tool( 'set_theme_mods',
                'Update theme customizer settings.',
                [ 'mods' => self::o( '{mod_name: value} pairs.' ) ],
                [ 'mods' ]
            ),

            self::tool( 'get_menus',
                'Get all registered navigation menus with their full item hierarchy.'
            ),

            self::tool( 'set_menu_items',
                'Add, update, or remove navigation menu items.',
                [
                    'menu_id' => self::i( 'Menu term ID (from get_menus).' ),
                    'items'   => self::a( 'Array of item objects: {id, title, url, type, object, object_id, parent}.' ),
                ],
                [ 'menu_id', 'items' ]
            ),

            self::tool( 'get_widgets',
                'Get all registered sidebars and their assigned widget instances.'
            ),

            self::tool( 'get_options',
                'Read wp_options values by key.',
                [ 'keys' => self::a( 'Array of option key strings.', $str_item ) ],
                [ 'keys' ]
            ),

            self::tool( 'set_option',
                'Write a single wp_option value.',
                [
                    'key'   => self::s( 'Option key.' ),
                    'value' => [ 'description' => 'Option value (any JSON type).' ],
                ],
                [ 'key', 'value' ]
            ),

            /* ── PHP Exec ─────────────────────────────────────── */
            self::tool( 'php_exec',
                '⚠️ Execute arbitrary PHP in the WordPress context. Dev/staging ONLY. Requires explicit confirmation string.',
                [
                    'code'    => self::s( 'PHP code to execute (no opening <?php tag).' ),
                    'confirm' => self::s( 'Site-specific confirmation token (shown in the Claude WP Developer settings screen). Generic strings are rejected.' ),
                ],
                [ 'code', 'confirm' ]
            ),

            /* ── WordPress Utilities ──────────────────────────── */
            self::tool( 'get_site_info',
                'Get WordPress site info: name, URL, version, active theme, and content counts.'
            ),

            self::tool( 'list_users',
                'List WordPress users with optional role/search filters.',
                [
                    'per_page' => self::i( 'Results per page. Default: 20.' ),
                    'page'     => self::i( 'Page number. Default: 1.' ),
                    'role'     => self::s( 'Filter by role slug.' ),
                    'search'   => self::s( 'Search in login, email, or display name.' ),
                    'orderby'  => self::s( 'Sort field.', [ 'registered', 'login', 'email', 'display_name' ] ),
                    'order'    => self::s( 'Sort direction.', [ 'ASC', 'DESC' ] ),
                ]
            ),

            self::tool( 'get_user',
                'Get a single user by ID or email, including meta.',
                [
                    'user_id' => self::i( 'User ID.' ),
                    'email'   => self::s( 'Email address. Used if user_id omitted.' ),
                ]
            ),

            self::tool( 'create_term',
                'Create a new taxonomy term (category, tag, or custom).',
                [
                    'name'        => self::s( 'Term name.' ),
                    'taxonomy'    => self::s( 'Taxonomy slug. Default: category.' ),
                    'slug'        => self::s( 'URL slug. Auto-generated from name if omitted.' ),
                    'parent'      => self::i( 'Parent term ID for hierarchical taxonomies (0 = root).' ),
                    'description' => self::s( 'Term description.' ),
                ],
                [ 'name' ]
            ),

            self::tool( 'delete_term',
                'Delete a taxonomy term by ID.',
                [
                    'term_id'  => self::i( 'Term ID.' ),
                    'taxonomy' => self::s( 'Taxonomy slug. Default: category.' ),
                ],
                [ 'term_id' ]
            ),

            self::tool( 'flush_cache',
                'Flush the WordPress object cache. Optionally also flush rewrite rules and Elementor CSS cache.',
                [ 'rewrite_rules' => self::b( 'Also flush rewrite rules.' ) ]
            ),

            self::tool( 'search_replace',
                'Find and replace text in post titles and content. Run with dry_run:true first to preview.',
                [
                    'find'      => self::s( 'Text to search for.' ),
                    'replace'   => self::s( 'Replacement text. Default: empty string.' ),
                    'post_type' => self::s( 'Post type to search. Default: post.' ),
                    'status'    => self::s( 'Post status to search. Default: publish.' ),
                    'dry_run'   => self::b( 'Preview matches without making changes. Default: false.' ),
                ],
                [ 'find' ]
            ),

            self::tool( 'get_active_theme',
                'Get the active theme details and a list of all installed themes.'
            ),

            self::tool( 'activate_theme',
                'Switch the active WordPress theme by slug.',
                [ 'slug' => self::s( 'Theme directory name (slug).' ) ],
                [ 'slug' ]
            ),

            self::tool( 'run_cron',
                'Manually trigger WP-Cron and return the next 20 scheduled events.'
            ),

            /* ── WooCommerce ──────────────────────────────────── */
            self::tool( 'woo_list_products',
                'List WooCommerce products with optional filters.',
                [
                    'per_page' => self::i( 'Results per page. Default: 20.' ),
                    'page'     => self::i( 'Page number. Default: 1.' ),
                    'search'   => self::s( 'Keyword search.' ),
                    'status'   => self::s( 'Product status.', [ 'publish', 'draft', 'pending', 'private', 'any' ] ),
                    'category' => self::s( 'Product category slug filter.' ),
                ]
            ),

            self::tool( 'woo_get_product',
                'Get full WooCommerce product details including price, stock, images, categories, and meta.',
                [ 'product_id' => self::i( 'Product (post) ID.' ) ],
                [ 'product_id' ]
            ),

            self::tool( 'woo_create_product',
                'Create a new WooCommerce simple product.',
                [
                    'name'              => self::s( 'Product name.' ),
                    'status'            => self::s( 'Product status.', [ 'draft', 'publish', 'private' ] ),
                    'description'       => self::s( 'Full product description.' ),
                    'short_description' => self::s( 'Short description.' ),
                    'regular_price'     => self::s( 'Regular price as string, e.g. "29.99".' ),
                    'sale_price'        => self::s( 'Sale price as string.' ),
                    'sku'               => self::s( 'Stock keeping unit.' ),
                    'stock_quantity'    => self::i( 'Stock quantity.' ),
                    'manage_stock'      => self::b( 'Enable per-product stock tracking.' ),
                    'stock_status'      => self::s( 'Stock status.', [ 'instock', 'outofstock', 'onbackorder' ] ),
                    'weight'            => self::s( 'Product weight.' ),
                    'image_id'          => self::i( 'Featured image attachment ID.' ),
                    'categories'        => self::a( 'Array of product_cat term IDs.', $int_item ),
                    'tags'              => self::a( 'Array of product_tag term IDs.', $int_item ),
                ],
                [ 'name' ]
            ),

            self::tool( 'woo_update_product',
                'Update an existing WooCommerce product.',
                [
                    'product_id'        => self::i( 'Product ID to update.' ),
                    'name'              => self::s( 'New name.' ),
                    'status'            => self::s( 'New status.', [ 'draft', 'publish', 'private', 'trash' ] ),
                    'description'       => self::s( 'New full description.' ),
                    'short_description' => self::s( 'New short description.' ),
                    'regular_price'     => self::s( 'New regular price.' ),
                    'sale_price'        => self::s( 'New sale price (empty string to remove).' ),
                    'sku'               => self::s( 'New SKU.' ),
                    'stock_quantity'    => self::i( 'New stock quantity.' ),
                    'manage_stock'      => self::b( 'Enable/disable stock management.' ),
                    'stock_status'      => self::s( 'New stock status.', [ 'instock', 'outofstock', 'onbackorder' ] ),
                    'image_id'          => self::i( 'New featured image attachment ID.' ),
                    'categories'        => self::a( 'New product_cat term IDs (replaces existing).', $int_item ),
                    'tags'              => self::a( 'New product_tag term IDs.', $int_item ),
                ],
                [ 'product_id' ]
            ),

            self::tool( 'woo_list_orders',
                'List WooCommerce orders with optional filters.',
                [
                    'per_page'    => self::i( 'Results per page. Default: 20.' ),
                    'page'        => self::i( 'Page number. Default: 1.' ),
                    'status'      => self::s( 'Order status (processing, completed, on-hold, cancelled, refunded, any).' ),
                    'customer_id' => self::i( 'Filter by customer user ID.' ),
                ]
            ),

            self::tool( 'woo_get_order',
                'Get full WooCommerce order details including line items, billing, shipping, and payment.',
                [ 'order_id' => self::i( 'Order ID.' ) ],
                [ 'order_id' ]
            ),

            /* ── Forms ────────────────────────────────────────── */
            self::tool( 'list_forms',
                'List all contact/lead-capture forms on the site (MetForm and WPForms).'
            ),

            self::tool( 'list_form_entries',
                'List form submission entries. Supports MetForm and WPForms.',
                [
                    'form_id'  => self::s( 'Form ID or slug. Leave blank to list entries from all forms.' ),
                    'per_page' => self::i( 'Results per page. Default: 20.' ),
                    'page'     => self::i( 'Page number. Default: 1.' ),
                    'status'   => self::s( 'Entry status filter (active, spam, trash). Default: active.' ),
                ]
            ),

            self::tool( 'get_form_entry',
                'Get a single form submission entry with all field values.',
                [
                    'entry_id' => self::s( 'Entry ID.' ),
                    'plugin'   => self::s( 'Which plugin this entry belongs to.', [ 'metform', 'wpforms' ] ),
                ],
                [ 'entry_id' ]
            ),

            /* ── Email ────────────────────────────────────────── */
            self::tool( 'list_email_logs',
                'List sent-email logs from FluentSMTP.',
                [
                    'per_page' => self::i( 'Results per page. Default: 20.' ),
                    'page'     => self::i( 'Page number. Default: 1.' ),
                    'status'   => self::s( 'Filter by delivery status.', [ 'sent', 'failed', 'pending' ] ),
                    'search'   => self::s( 'Search subject, to, or from fields.' ),
                ]
            ),

            /* ── Divi Builder ─────────────────────────────────── */
            self::tool( 'divi_get_data',
                'Read the Divi shortcodes and builder meta (version, active flag) from a post or page.',
                [ 'post_id' => self::i( 'Post ID.' ) ],
                [ 'post_id' ]
            ),

            self::tool( 'divi_set_data',
                'Write raw Divi shortcodes to a post, enabling the Divi builder. Use divi_build_page for structured builds.',
                [
                    'post_id' => self::i( 'Post ID.' ),
                    'content' => self::s( 'Raw Divi shortcode string.' ),
                ],
                [ 'post_id', 'content' ]
            ),

            self::tool( 'divi_build_page',
                'Build a Divi page from a structured spec. Structure: sections → rows → columns → modules. Generates and saves Divi shortcodes automatically.

Spec shape:
{
  "post_id": 42,
  "sections": [
    {
      "background": {"color":"#1a1a2e", "gradient":{"from":"#667eea","to":"#764ba2","angle":135}, "image":"https://...", "parallax":true},
      "padding": "120px|0|120px|0",
      "min_height": "100vh",
      "text_align": "center",
      "css_class": "hero-section",
      "rows": [
        {
          "layout": "4_4",
          "max_width": "800px",
          "columns": [
            {
              "modules": [
                {"type":"et_pb_text",   "settings":{"content":"<h1>Title</h1>","text_color":"#fff"}},
                {"type":"et_pb_button", "settings":{"text":"Get Started","url":"/contact","align":"center"}}
              ]
            }
          ]
        }
      ]
    }
  ]
}

Column layout values (rows.layout): "4_4" | "1_2 1_2" | "1_3 1_3 1_3" | "1_4 1_4 1_4 1_4" | "2_3 1_3" | "3_4 1_4" (space-separated column width fractions). Omit to auto-detect from column count.',
                [
                    'post_id'  => self::i( 'Post ID to build on.' ),
                    'sections' => self::a( 'Array of section objects (see description for full spec).' ),
                ],
                [ 'post_id', 'sections' ]
            ),

            self::tool( 'divi_list_modules',
                'Return the full catalog of Divi modules supported by divi_build_page, grouped by category (basic, content, media, social, wordpress, structure).'
            ),

            self::tool( 'divi_get_globals',
                'Get Divi global colors (D5 et_global_colors), accent color, and key theme mod settings.'
            ),

            self::tool( 'divi_set_globals',
                'Update Divi global colors, accent color, or theme customizer settings. Flushes cache automatically.',
                [
                    'global_colors' => self::a( 'Array of color objects: [{id, name, color}]. Existing ids are updated; new ids are appended.' ),
                    'accent_color'  => self::s( 'Divi accent color as hex, e.g. "#e02b20".' ),
                    'theme_mods'    => self::o( 'Key→value pairs written via set_theme_mod().' ),
                ]
            ),

            self::tool( 'divi_list_layouts',
                'List saved layouts from the Divi library (et_pb_layout post type).',
                [
                    'type' => self::s( 'Filter by layout type slug (section, fullwidth-section, row, module). Omit for all.' ),
                ]
            ),

            self::tool( 'divi_import_layout',
                'Apply a saved Divi layout to a post, replacing or appending its content.',
                [
                    'post_id'   => self::i( 'Target post/page ID.' ),
                    'layout_id' => self::i( 'Divi library layout post ID (from divi_list_layouts).' ),
                    'append'    => self::b( 'true = append layout after existing content. false = replace (default).' ),
                ],
                [ 'post_id', 'layout_id' ]
            ),

            self::tool( 'divi_flush_cache',
                'Clear Divi static CSS cache. Use after bulk edits or after divi_set_globals.',
                [
                    'post_id' => self::i( 'Limit cache clear to a specific post. Omit for site-wide flush.' ),
                ]
            ),

            self::tool( 'divi_get_theme_builder',
                'List Divi Theme Builder templates (headers, footers, body layouts) from the et_template post type.'
            ),

        ]; /* end tool_definitions */
    }
}
