# Claude WP Developer — MCP Plugin

Full MCP server for Claude Code that gives Claude complete WordPress developer access:
Elementor (native widgets), Yoast SEO, media library, plugin management, scheduling, and more.

---

## Installation

1. Upload the `claude-wp-mcp` folder to `/wp-content/plugins/`
2. Activate the plugin in **WordPress Admin → Plugins**
3. Go to **Claude WP Dev** in the sidebar
4. Copy your API token and the connection config
5. Paste the config into `~/.claude/settings.json`

---

## Claude Code Setup

Add to `~/.claude/settings.json`:

```json
{
  "mcpServers": {
    "wordpress": {
      "type": "http",
      "url": "https://YOUR-SITE.com/wp-json/cwpm/v1",
      "headers": {
        "Authorization": "Bearer YOUR_TOKEN_HERE"
      }
    }
  }
}
```

---

## How Claude Code uses the tools

All tools go through one endpoint: `POST /wp-json/cwpm/v1/tool`

```json
{ "tool": "TOOL_NAME", "params": { ... } }
```

---

## Tool Reference

### CONTENT TOOLS

#### create_post
```json
{
  "tool": "create_post",
  "params": {
    "title": "My Blog Post",
    "content": "<p>Hello world</p>",
    "status": "publish",
    "type": "post",
    "excerpt": "Short summary",
    "date": "2026-06-01 09:00:00",
    "meta": { "custom_key": "value" },
    "terms": { "category": [1, 2], "post_tag": [5] }
  }
}
```

#### schedule_post
```json
{
  "tool": "schedule_post",
  "params": {
    "post_id": 42,
    "date": "2026-06-15 08:00:00"
  }
}
```

#### set_featured_image
```json
{
  "tool": "set_featured_image",
  "params": { "post_id": 42, "media_id": 99 }
}
```

---

### ELEMENTOR TOOLS

#### elementor_build_page — Build a complete page with native widgets
```json
{
  "tool": "elementor_build_page",
  "params": {
    "post_id": 10,
    "sections": [
      {
        "layout": "full_width",
        "background": { "gradient": { "from": "#1a1a2e", "to": "#16213e", "angle": 135 } },
        "padding": { "top": 100, "bottom": 100 },
        "columns": [
          {
            "width": 100,
            "widgets": [
              {
                "type": "heading",
                "settings": {
                  "title": "Welcome to Our Agency",
                  "header_size": "h1",
                  "align": "center",
                  "color": "#ffffff",
                  "font_size": 72,
                  "font_weight": "800"
                }
              },
              {
                "type": "button",
                "settings": {
                  "text": "Get Started",
                  "url": "/contact",
                  "align": "center",
                  "background_color": "#6c63ff",
                  "size": "lg"
                }
              }
            ]
          }
        ]
      },
      {
        "background": { "color": "#f8f8ff" },
        "padding": 60,
        "columns": [
          {
            "width": 33,
            "widgets": [
              {
                "type": "icon-box",
                "settings": {
                  "icon": "fa fa-rocket",
                  "title": "Fast Performance",
                  "description": "Lightning fast load times for all devices.",
                  "icon_color": "#6c63ff",
                  "shadow": { "h": 0, "v": 8, "blur": 24, "color": "rgba(108,99,255,0.2)" }
                }
              }
            ]
          },
          {
            "width": 33,
            "widgets": [
              {
                "type": "icon-box",
                "settings": {
                  "icon": "fa fa-shield-alt",
                  "title": "Secure",
                  "description": "Enterprise-grade security built in.",
                  "icon_color": "#10b981",
                  "shadow": { "v": 8, "blur": 24, "color": "rgba(16,185,129,0.2)" }
                }
              }
            ]
          },
          {
            "width": 33,
            "widgets": [
              {
                "type": "icon-box",
                "settings": {
                  "icon": "fa fa-headset",
                  "title": "24/7 Support",
                  "description": "Our team is always here to help.",
                  "icon_color": "#f59e0b",
                  "shadow": { "v": 8, "blur": 24, "color": "rgba(245,158,11,0.2)" }
                }
              }
            ]
          }
        ]
      },
      {
        "background": { "color": "#1a1a2e" },
        "padding": 80,
        "columns": [
          {
            "width": 50,
            "widgets": [
              { "type": "heading", "settings": { "title": "Our Numbers", "color": "#ffffff" } },
              { "type": "counter", "settings": { "from": 0, "to": 500, "suffix": "+", "title": "Happy Clients", "duration": 2000 } }
            ]
          },
          {
            "width": 50,
            "widgets": [
              { "type": "price-table", "settings": {
                "title": "Pro Plan",
                "price": "$49",
                "period": "/ month",
                "features": [
                  { "text": "Unlimited pages", "icon": "fa fa-check" },
                  { "text": "Priority support", "icon": "fa fa-check" },
                  { "text": "Custom domain", "icon": "fa fa-check" }
                ],
                "button": "Start Free Trial",
                "url": "/signup",
                "featured": "yes"
              }}
            ]
          }
        ]
      }
    ]
  }
}
```

#### elementor_list_widgets — See all available widgets
```json
{ "tool": "elementor_list_widgets", "params": {} }
```

#### elementor_set_globals — Update global colors/fonts
```json
{
  "tool": "elementor_set_globals",
  "params": {
    "system_colors": [
      { "id": "accent", "title": "Accent", "color": "#6c63ff" },
      { "id": "secondary", "title": "Secondary", "color": "#10b981" }
    ]
  }
}
```

---

### SEO TOOLS

#### yoast_set_meta — Full Yoast SEO control
```json
{
  "tool": "yoast_set_meta",
  "params": {
    "post_id": 42,
    "seo_title": "Best WordPress Agency | YourSite",
    "meta_description": "We build blazing-fast WordPress sites. Get a free quote today.",
    "focus_keyword": "wordpress agency",
    "og_title": "Best WordPress Agency",
    "og_description": "Custom WordPress development for growing businesses.",
    "is_cornerstone": "1",
    "schema_page_type": "WebPage",
    "canonical_url": "https://yoursite.com/services/"
  }
}
```

#### yoast_audit — Get SEO issues for a post
```json
{ "tool": "yoast_audit", "params": { "post_id": 42 } }
```

---

### MEDIA TOOLS

#### upload_media — Upload from URL
```json
{
  "tool": "upload_media",
  "params": {
    "url": "https://example.com/photo.jpg",
    "title": "Hero Image",
    "alt": "Team working together",
    "caption": "Our team in action",
    "post_id": 42
  }
}
```

---

### PLUGIN TOOLS

#### install_plugin
```json
{
  "tool": "install_plugin",
  "params": { "slug": "contact-form-7" }
}
```

#### get_plugin_settings / set_plugin_settings
```json
{
  "tool": "get_plugin_settings",
  "params": { "option_keys": ["wpseo_titles", "elementor_cpt_support"] }
}
```

---

## EXAMPLE: Replicate an HTML template as an Elementor page

When you share an HTML template with Claude Code, it will:
1. Analyse the sections, colors, layout
2. Map each section to Elementor native widgets
3. Call `elementor_build_page` with the full JSON
4. Upload any images via `upload_media`
5. Set SEO meta via `yoast_set_meta`
6. Set featured image via `set_featured_image`

**Sample Claude Code prompt:**
```
Here's an HTML template [paste template]. Create a new WordPress page called "Services" 
and build it in Elementor using only native widgets — no HTML widget. 
Use icon-boxes with shadows for the feature cards, a countdown for the launch date, 
and a price-table for the pricing section. Set the Yoast SEO title and meta description too.
```

---

## Security Notes

- Keep this plugin on **development/staging** only — not production
- The `php_exec` tool requires `"confirm": "I_UNDERSTAND_THIS_IS_DANGEROUS"` in params
- Regenerate the token from the dashboard if compromised
- The API is behind WordPress REST API auth — only accessible with the Bearer token

---

## Supported Elementor Widget Types

| Widget | Type key |
|--------|----------|
| Heading | `heading` |
| Text Editor | `text-editor` |
| Image | `image` |
| Button | `button` |
| Icon Box | `icon-box` |
| Image Box | `image-box` |
| Icon | `icon` |
| Icon List | `icon-list` |
| Counter | `counter` |
| Progress Bar | `progress` |
| Testimonial | `testimonial` |
| Divider | `divider` |
| Spacer | `spacer` |
| Video | `video` |
| Google Maps | `google_maps` |
| Social Icons | `social-icons` |
| Tabs | `tabs` |
| Accordion | `accordion` |
| Alert | `alert` |
| Call To Action | `call-to-action` |
| Price Table | `price-table` |
| Countdown | `countdown` |
| Form (Pro) | `form` |
| Posts | `posts` |
| Nav Menu | `nav-menu` |
| Search Form | `search-form` |
| Shortcode | `shortcode` |
