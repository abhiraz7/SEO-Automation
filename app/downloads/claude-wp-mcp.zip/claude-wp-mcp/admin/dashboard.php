<?php defined('ABSPATH') || exit; ?>

<style>
/* ═══════════════════════════════════════════
   Claude WP Developer — Admin Dashboard
   Inspired by Novamira / Nexter aesthetic
═══════════════════════════════════════════ */
:root {
  --cwpm-bg:       #0f0f17;
  --cwpm-card:     #16161f;
  --cwpm-border:   #2a2a3a;
  --cwpm-accent:   #6c63ff;
  --cwpm-accent2:  #a78bfa;
  --cwpm-green:    #10b981;
  --cwpm-red:      #ef4444;
  --cwpm-yellow:   #f59e0b;
  --cwpm-text:     #e2e2f0;
  --cwpm-muted:    #888899;
  --cwpm-radius:   12px;
  --cwpm-shadow:   0 4px 32px rgba(108,99,255,.18);
}

.cwpm-wrap *{box-sizing:border-box;font-family:'Segoe UI',system-ui,sans-serif}
.cwpm-wrap{background:var(--cwpm-bg);min-height:100vh;margin:-20px -20px 0;padding:0;color:var(--cwpm-text)}

/* ─ Header */
.cwpm-header{
  background:linear-gradient(135deg,#1a1a2e 0%,#16213e 50%,#0f3460 100%);
  padding:32px 40px 28px;
  border-bottom:1px solid var(--cwpm-border);
  display:flex;align-items:center;gap:20px;
  position:relative;overflow:hidden;
}
.cwpm-header::before{
  content:'';position:absolute;inset:0;
  background:radial-gradient(ellipse 600px 300px at 80% 50%,rgba(108,99,255,.15) 0%,transparent 70%);
  pointer-events:none;
}
.cwpm-header-icon{
  width:56px;height:56px;background:var(--cwpm-accent);border-radius:14px;
  display:flex;align-items:center;justify-content:center;flex-shrink:0;
  box-shadow:0 0 32px rgba(108,99,255,.5);
}
.cwpm-header-icon svg{width:32px;height:32px;stroke:#fff;fill:none}
.cwpm-header-title{font-size:22px;font-weight:700;letter-spacing:-.3px;margin:0}
.cwpm-header-sub{color:var(--cwpm-muted);font-size:13px;margin:2px 0 0}
.cwpm-status-pill{
  margin-left:auto;padding:6px 16px;border-radius:999px;font-size:12px;font-weight:600;
  letter-spacing:.5px;text-transform:uppercase;
}
.cwpm-status-pill.on {background:rgba(16,185,129,.15);color:var(--cwpm-green);border:1px solid rgba(16,185,129,.3)}
.cwpm-status-pill.off{background:rgba(239,68,68,.12);color:var(--cwpm-red);border:1px solid rgba(239,68,68,.3)}

/* ─ Body layout */
.cwpm-body{padding:32px 40px;display:grid;gap:24px}
.cwpm-row{display:grid;grid-template-columns:1fr 1fr;gap:24px}
.cwpm-row.triple{grid-template-columns:repeat(3,1fr)}
@media(max-width:900px){.cwpm-row,.cwpm-row.triple{grid-template-columns:1fr}}

/* ─ Stats cards */
.cwpm-stat{
  background:var(--cwpm-card);border:1px solid var(--cwpm-border);border-radius:var(--cwpm-radius);
  padding:20px 24px;display:flex;align-items:center;gap:16px;
  transition:border-color .2s;
}
.cwpm-stat:hover{border-color:var(--cwpm-accent)}
.cwpm-stat-icon{
  width:44px;height:44px;border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:20px;
}
.cwpm-stat-icon.purple{background:rgba(108,99,255,.15);color:var(--cwpm-accent)}
.cwpm-stat-icon.green {background:rgba(16,185,129,.12);color:var(--cwpm-green)}
.cwpm-stat-icon.yellow{background:rgba(245,158,11,.12);color:var(--cwpm-yellow)}
.cwpm-stat-label{font-size:11px;color:var(--cwpm-muted);text-transform:uppercase;letter-spacing:.8px;margin:0 0 4px}
.cwpm-stat-value{font-size:18px;font-weight:700;margin:0;color:var(--cwpm-text)}

/* ─ Section cards */
.cwpm-card{
  background:var(--cwpm-card);border:1px solid var(--cwpm-border);
  border-radius:var(--cwpm-radius);overflow:hidden;
}
.cwpm-card-head{
  padding:18px 24px;border-bottom:1px solid var(--cwpm-border);
  display:flex;align-items:center;justify-content:space-between;
}
.cwpm-card-head-left{display:flex;align-items:center;gap:10px}
.cwpm-card-step{
  width:26px;height:26px;background:var(--cwpm-accent);color:#fff;border-radius:50%;
  display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;flex-shrink:0;
}
.cwpm-card-title{font-size:15px;font-weight:600;margin:0}
.cwpm-card-body{padding:24px}

/* ─ Toggle switch */
.cwpm-toggle{display:flex;align-items:center;gap:12px;cursor:pointer}
.cwpm-toggle-track{
  width:46px;height:26px;background:#2a2a3a;border-radius:999px;
  position:relative;transition:background .2s;flex-shrink:0;cursor:pointer;
}
.cwpm-toggle-track.on{background:var(--cwpm-accent)}
.cwpm-toggle-thumb{
  width:20px;height:20px;background:#fff;border-radius:50%;
  position:absolute;top:3px;left:3px;
  transition:transform .2s;box-shadow:0 2px 6px rgba(0,0,0,.3);
}
.cwpm-toggle-track.on .cwpm-toggle-thumb{transform:translateX(20px)}
.cwpm-toggle input{display:none}
.cwpm-toggle-label{font-size:14px;font-weight:500}

.cwpm-note{
  background:rgba(245,158,11,.07);border:1px solid rgba(245,158,11,.25);
  border-radius:8px;padding:10px 14px;font-size:12.5px;color:var(--cwpm-yellow);margin-top:12px;
}
.cwpm-note strong{color:#fbbf24}

/* ─ Token box */
.cwpm-token-row{display:flex;gap:10px;align-items:center}
.cwpm-token-box{
  flex:1;background:#0a0a12;border:1px solid var(--cwpm-border);border-radius:8px;
  padding:12px 16px;font-family:'Courier New',monospace;font-size:13px;
  color:var(--cwpm-accent2);word-break:break-all;letter-spacing:.5px;
  user-select:all;
}
.cwpm-btn{
  display:inline-flex;align-items:center;gap:6px;
  padding:10px 18px;border-radius:8px;font-size:13px;font-weight:600;
  border:none;cursor:pointer;transition:all .15s;text-decoration:none;
}
.cwpm-btn-primary{background:var(--cwpm-accent);color:#fff}
.cwpm-btn-primary:hover{background:#5a52e0;box-shadow:var(--cwpm-shadow)}
.cwpm-btn-outline{background:transparent;color:var(--cwpm-text);border:1px solid var(--cwpm-border)}
.cwpm-btn-outline:hover{border-color:var(--cwpm-accent);color:var(--cwpm-accent)}
.cwpm-btn-danger{background:rgba(239,68,68,.12);color:var(--cwpm-red);border:1px solid rgba(239,68,68,.3)}
.cwpm-btn-danger:hover{background:var(--cwpm-red);color:#fff}
.cwpm-btn-sm{padding:7px 12px;font-size:12px}

/* ─ Connection snippet */
.cwpm-snippet{
  background:#060610;border:1px solid var(--cwpm-border);border-radius:8px;
  padding:16px 20px;font-family:'Courier New',monospace;font-size:12px;
  color:#c9d1d9;line-height:1.8;white-space:pre;overflow-x:auto;
  position:relative;
}
.cwpm-snippet .kw {color:#ff7b72}
.cwpm-snippet .str{color:#a5d6ff}
.cwpm-snippet .prop{color:#79c0ff}
.cwpm-copy-btn{position:absolute;top:10px;right:10px}

/* ─ Capabilities grid */
.cwpm-caps{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px}
.cwpm-cap{
  background:#0a0a15;border:1px solid var(--cwpm-border);border-radius:8px;
  padding:12px 14px;display:flex;align-items:center;gap:10px;
  transition:border-color .2s;
}
.cwpm-cap.active{border-color:rgba(108,99,255,.4)}
.cwpm-cap-dot{
  width:8px;height:8px;border-radius:50%;flex-shrink:0;
  background:var(--cwpm-muted);
}
.cwpm-cap.active .cwpm-cap-dot{background:var(--cwpm-green);box-shadow:0 0 6px var(--cwpm-green)}
.cwpm-cap-name{font-size:13px;font-weight:500}
.cwpm-cap-count{font-size:11px;color:var(--cwpm-muted)}

/* ─ Action checkboxes */
.cwpm-actions-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:8px}
.cwpm-action-check{
  display:flex;align-items:center;gap:8px;padding:8px 12px;
  background:#0a0a15;border:1px solid var(--cwpm-border);border-radius:7px;cursor:pointer;
  transition:border-color .2s;
}
.cwpm-action-check:hover{border-color:var(--cwpm-accent)}
.cwpm-action-check input[type=checkbox]{accent-color:var(--cwpm-accent)}
.cwpm-action-check span{font-size:12.5px}

/* ─ Log */
.cwpm-log{max-height:280px;overflow-y:auto;display:flex;flex-direction:column;gap:4px}
.cwpm-log-entry{
  display:flex;align-items:flex-start;gap:10px;padding:6px 10px;border-radius:6px;
  font-size:12px;border:1px solid transparent;
}
.cwpm-log-entry.info {background:rgba(108,99,255,.05);border-color:rgba(108,99,255,.15)}
.cwpm-log-entry.warn {background:rgba(245,158,11,.05);border-color:rgba(245,158,11,.15)}
.cwpm-log-entry.error{background:rgba(239,68,68,.05); border-color:rgba(239,68,68,.15)}
.cwpm-log-time{color:var(--cwpm-muted);flex-shrink:0;font-family:monospace}
.cwpm-log-level{
  font-weight:700;text-transform:uppercase;font-size:10px;flex-shrink:0;
  padding:1px 6px;border-radius:4px;
}
.cwpm-log-entry.info  .cwpm-log-level{background:rgba(108,99,255,.2);color:var(--cwpm-accent2)}
.cwpm-log-entry.warn  .cwpm-log-level{background:rgba(245,158,11,.2);color:var(--cwpm-yellow)}
.cwpm-log-entry.error .cwpm-log-level{background:rgba(239,68,68,.2); color:var(--cwpm-red)}

/* ─ Plugin compat badges */
.cwpm-badge{display:inline-flex;align-items:center;gap:5px;padding:4px 10px;border-radius:999px;font-size:11.5px;font-weight:600}
.cwpm-badge.ok {background:rgba(16,185,129,.12);color:var(--cwpm-green);border:1px solid rgba(16,185,129,.3)}
.cwpm-badge.no {background:rgba(100,100,120,.1);color:var(--cwpm-muted);border:1px solid var(--cwpm-border)}
.cwpm-compat-list{display:flex;flex-wrap:wrap;gap:8px;margin-top:6px}

/* ─ Select */
.cwpm-select{
  background:#0a0a15;border:1px solid var(--cwpm-border);border-radius:7px;
  padding:8px 12px;color:var(--cwpm-text);font-size:13px;cursor:pointer;
}
.cwpm-select:focus{outline:none;border-color:var(--cwpm-accent)}

/* ─ Toast */
#cwpm-toast{
  position:fixed;bottom:24px;right:24px;z-index:9999;
  background:#1e1e2e;border:1px solid var(--cwpm-border);border-radius:10px;
  padding:12px 20px;font-size:13px;font-weight:500;
  display:none;align-items:center;gap:10px;
  box-shadow:0 8px 32px rgba(0,0,0,.4);
}
#cwpm-toast.show{display:flex;animation:cwpmSlideUp .3s ease}
@keyframes cwpmSlideUp{from{transform:translateY(10px);opacity:0}to{transform:translateY(0);opacity:1}}

/* ─ Save bar */
.cwpm-save-bar{
  position:sticky;bottom:0;background:rgba(15,15,23,.95);border-top:1px solid var(--cwpm-border);
  padding:14px 40px;display:flex;align-items:center;justify-content:space-between;
  backdrop-filter:blur(12px);z-index:100;margin:0 -40px;
}

/* ─ Tab buttons */
.cwpm-tab-btn{
  background:transparent;border:none;padding:9px 18px;color:var(--cwpm-muted);
  font-size:13px;font-weight:500;cursor:pointer;transition:all .15s;
}
.cwpm-tab-btn:hover{color:var(--cwpm-text);background:rgba(108,99,255,.08)}
.cwpm-tab-btn.active{color:var(--cwpm-accent2);background:rgba(108,99,255,.12);font-weight:600}
</style>

<?php
$post_count = wp_count_posts()->publish ?? 0;
$page_count = wp_count_posts('page')->publish ?? 0;
$media_count = wp_count_posts('attachment')->inherit ?? 0;
$log_count = count( CWPM_Logger::get_recent(200) );
?>

<?php if ( strpos( home_url(), 'https://' ) !== 0 ) : ?>
<div style="background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.4);border-radius:8px;padding:12px 18px;margin:16px 20px 0;font-size:13px;color:#ef4444">
  <strong>⚠ HTTPS not detected.</strong> Your site URL does not start with <code>https://</code>. The API token and Application Password will be transmitted in plaintext. Enable SSL before using this plugin on a production site.
</div>
<?php endif; ?>

<!-- HEADER -->
<div class="cwpm-header">
  <div class="cwpm-header-icon">
    <svg viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
    </svg>
  </div>
  <div>
    <h1 class="cwpm-header-title">Claude WP Developer</h1>
    <p class="cwpm-header-sub">Full MCP integration — give Claude Code complete WordPress developer access</p>
  </div>
  <div class="cwpm-status-pill <?php echo $enabled ? 'on' : 'off'; ?>">
    <?php echo $enabled ? '● Active' : '○ Disabled'; ?>
  </div>
</div>

<div class="cwpm-body">

  <!-- STAT STRIP -->
  <div class="cwpm-row triple">
    <div class="cwpm-stat">
      <div class="cwpm-stat-icon purple">📄</div>
      <div><p class="cwpm-stat-label">Posts Published</p><p class="cwpm-stat-value"><?php echo intval($post_count); ?></p></div>
    </div>
    <div class="cwpm-stat">
      <div class="cwpm-stat-icon green">🖼</div>
      <div><p class="cwpm-stat-label">Media Items</p><p class="cwpm-stat-value"><?php echo intval($media_count); ?></p></div>
    </div>
    <div class="cwpm-stat">
      <div class="cwpm-stat-icon yellow">📋</div>
      <div><p class="cwpm-stat-label">Activity Logs</p><p class="cwpm-stat-value"><?php echo $log_count; ?></p></div>
    </div>
  </div>

  <!-- ROW 1: Enable + Compatible Plugins -->
  <div class="cwpm-row">

    <!-- 1. Enable AI Abilities -->
    <div class="cwpm-card">
      <div class="cwpm-card-head">
        <div class="cwpm-card-head-left">
          <div class="cwpm-card-step">1</div>
          <h2 class="cwpm-card-title">Enable Claude WP Developer</h2>
        </div>
      </div>
      <div class="cwpm-card-body">
        <label class="cwpm-toggle" id="enabled-toggle">
          <input type="checkbox" id="cwpm-enabled" <?php checked($enabled,'1'); ?>>
          <div class="cwpm-toggle-track <?php echo $enabled ? 'on' : ''; ?>">
            <div class="cwpm-toggle-thumb"></div>
          </div>
          <span class="cwpm-toggle-label">Turn on Claude WP Developer for this site</span>
        </label>
        <div class="cwpm-note">
          <strong>Security note:</strong> When enabled, Claude Code can read and write all WordPress data including posts, media, plugins, and settings. For development and staging environments only. <strong>Always keep backups.</strong>
        </div>
      </div>
    </div>

    <!-- Plugin Compatibility -->
    <div class="cwpm-card">
      <div class="cwpm-card-head">
        <div class="cwpm-card-head-left">
          <div class="cwpm-card-step" style="background:#10b981">✓</div>
          <h2 class="cwpm-card-title">Plugin Compatibility</h2>
        </div>
      </div>
      <div class="cwpm-card-body">
        <p style="font-size:13px;color:var(--cwpm-muted);margin:0 0 12px">Detected integrations on this site:</p>
        <div class="cwpm-compat-list">
          <span class="cwpm-badge <?php echo $has_elementor ? 'ok' : 'no'; ?>">
            <?php echo $has_elementor ? '✓' : '○'; ?> Elementor
          </span>
          <span class="cwpm-badge <?php echo $has_yoast ? 'ok' : 'no'; ?>">
            <?php echo $has_yoast ? '✓' : '○'; ?> Yoast SEO
          </span>
          <span class="cwpm-badge <?php echo $has_acf ? 'ok' : 'no'; ?>">
            <?php echo $has_acf ? '✓' : '○'; ?> ACF
          </span>
          <span class="cwpm-badge <?php echo $has_woo ? 'ok' : 'no'; ?>">
            <?php echo $has_woo ? '✓' : '○'; ?> WooCommerce
          </span>
          <span class="cwpm-badge ok">✓ REST API</span>
          <span class="cwpm-badge ok">✓ Media Library</span>
          <span class="cwpm-badge ok">✓ Post Scheduler</span>
        </div>
      </div>
    </div>

  </div>

  <!-- 2. Application Password (Primary Auth) -->
  <div class="cwpm-card">
    <div class="cwpm-card-head">
      <div class="cwpm-card-head-left">
        <div class="cwpm-card-step">2</div>
        <h2 class="cwpm-card-title">Application Password <span style="font-size:11px;background:rgba(16,185,129,.15);color:#10b981;border:1px solid rgba(16,185,129,.3);border-radius:4px;padding:2px 7px;margin-left:6px;font-weight:600;letter-spacing:.4px">RECOMMENDED</span></h2>
      </div>
    </div>
    <div class="cwpm-card-body">
      <p style="font-size:13px;color:var(--cwpm-muted);margin:0 0 16px">Create a WordPress Application Password for this admin account. This is the most secure way to connect — it uses WordPress's built-in credential system and can be revoked any time from <strong>Users → Profile</strong>.</p>

      <?php if ( ! $app_username ) : ?>
      <div id="cwpm-no-app-pw" style="background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.2);border-radius:8px;padding:14px;margin-bottom:16px;font-size:13px;color:#f59e0b">
        No Application Password created yet. Click the button below to create one for your account.
      </div>
      <?php endif; ?>

      <div id="cwpm-app-pw-block" style="background:#0a0a15;border:1px solid var(--cwpm-border);border-radius:8px;padding:16px;margin-bottom:16px;<?php echo $app_username ? '' : 'display:none'; ?>">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
          <span style="font-size:11px;background:rgba(16,185,129,.12);color:#10b981;border:1px solid rgba(16,185,129,.25);border-radius:4px;padding:2px 8px;font-weight:600">✓ CREATED</span>
          <span id="cwpm-app-username-label" style="font-size:12px;color:var(--cwpm-muted)">WordPress user: <strong style="color:var(--cwpm-text)"><?php echo esc_html($app_username); ?></strong></span>
        </div>
        <div style="margin-bottom:8px">
          <div style="font-size:11px;color:var(--cwpm-muted);text-transform:uppercase;letter-spacing:.8px;margin-bottom:4px">Application Password</div>
          <div class="cwpm-token-row">
            <div class="cwpm-token-box" id="cwpm-app-pw-display" style="font-family:monospace;letter-spacing:1px;color:var(--cwpm-muted);font-style:italic">Click Regenerate to reveal a new password</div>
            <button class="cwpm-btn cwpm-btn-outline cwpm-btn-sm" id="cwpm-copy-app-pw" style="display:none">Copy</button>
          </div>
        </div>
        <div>
          <div style="font-size:11px;color:var(--cwpm-muted);text-transform:uppercase;letter-spacing:.8px;margin-bottom:4px">Base64 Encoded (for config)</div>
          <div class="cwpm-token-row">
            <div class="cwpm-token-box" id="cwpm-app-encoded-display" style="font-size:11px;word-break:break-all;color:var(--cwpm-muted);font-style:italic">—</div>
            <button class="cwpm-btn cwpm-btn-outline cwpm-btn-sm" id="cwpm-copy-encoded" style="display:none">Copy</button>
          </div>
        </div>
      </div>

      <div style="display:flex;gap:10px;align-items:center">
        <button class="cwpm-btn" id="cwpm-create-app-pw" style="background:var(--cwpm-accent)">
          <?php echo $app_username ? '🔄 Regenerate Application Password' : '🔑 Create Application Password'; ?>
        </button>
        <?php if ( $app_username ) : ?>
        <span style="font-size:12px;color:var(--cwpm-muted)">Regenerating invalidates the old password — update your Claude Code config.</span>
        <?php endif; ?>
      </div>

      <div class="cwpm-note" style="margin-top:14px">
        <strong>Note:</strong> The Application Password is shown <em>once</em> — it is never stored by this plugin. Copy it now. If you lose it, click Regenerate to create a new one.
      </div>
    </div>
  </div>

  <!-- 3. Claude Code Connection Config -->
  <div class="cwpm-card">
    <div class="cwpm-card-head">
      <div class="cwpm-card-head-left">
        <div class="cwpm-card-step">3</div>
        <h2 class="cwpm-card-title">Connect Claude Code</h2>
      </div>
    </div>
    <div class="cwpm-card-body">

      <!-- Tab switcher -->
      <div style="display:flex;gap:0;border:1px solid var(--cwpm-border);border-radius:8px;overflow:hidden;margin-bottom:18px;width:fit-content">
        <button class="cwpm-tab-btn active" id="tab-apppassword" onclick="cwpmShowTab('apppassword')">Application Password</button>
        <button class="cwpm-tab-btn" id="tab-bearer" onclick="cwpmShowTab('bearer')">API Token (Bearer)</button>
      </div>

      <!-- Application Password config -->
      <div id="cwpm-tab-apppassword">
        <p style="font-size:13px;color:var(--cwpm-muted);margin:0 0 12px">
          Add this to <code style="color:var(--cwpm-accent2)">~/.claude/settings.json</code> (global) or your project's <code style="color:var(--cwpm-accent2)">.mcp.json</code>:
        </p>
        <?php
        $app_auth_value = $app_encoded ? 'Basic ' . $app_encoded : 'Basic BASE64(username:app_password)';
        ?>
        <div class="cwpm-snippet" id="cwpm-config-app">{
  <span class="prop">"mcpServers"</span>: {
    <span class="prop">"<?php echo esc_html(sanitize_title(get_bloginfo('name')) ?: 'wordpress'); ?>"</span>: {
      <span class="prop">"type"</span>: <span class="str">"http"</span>,
      <span class="prop">"url"</span>:  <span class="str">"<?php echo esc_html($api_base . '/mcp'); ?>"</span>,
      <span class="prop">"headers"</span>: {
        <span class="prop">"Authorization"</span>: <span class="str">"<?php echo esc_html($app_auth_value); ?>"</span>
      }
    }
  }
}</div>
        <div style="margin-top:12px;display:flex;gap:10px;flex-wrap:wrap">
          <button class="cwpm-btn cwpm-btn-outline cwpm-btn-sm" id="cwpm-copy-config-app">Copy Config</button>
          <?php if ( ! $app_encoded ) : ?>
          <span style="font-size:12px;color:var(--cwpm-yellow);align-self:center">⚠ Create an Application Password first (Step 2)</span>
          <?php endif; ?>
          <a href="<?php echo esc_url($api_base . '/ping'); ?>" target="_blank" class="cwpm-btn cwpm-btn-outline cwpm-btn-sm">Test ↗</a>
        </div>
      </div>

      <!-- Bearer token config -->
      <div id="cwpm-tab-bearer" style="display:none">
        <p style="font-size:13px;color:var(--cwpm-muted);margin:0 0 12px">
          Alternative: use the custom API token below. Useful if Application Passwords are disabled on your host.
        </p>
        <div class="cwpm-token-row" style="margin-bottom:14px">
          <?php
          $token_masked = strlen($token) > 16
              ? substr($token,0,8) . '…' . substr($token,-8)
              : str_repeat('•', strlen($token));
          ?>
          <div class="cwpm-token-box" id="cwpm-token-display"
               data-token="<?php echo esc_attr($token); ?>"
               title="Click Copy to get the full token"><?php echo esc_html($token_masked); ?></div>
          <button class="cwpm-btn cwpm-btn-outline cwpm-btn-sm" id="cwpm-copy-token">Copy</button>
          <button class="cwpm-btn cwpm-btn-danger cwpm-btn-sm" id="cwpm-regen-token">Regenerate</button>
        </div>
        <div class="cwpm-snippet" id="cwpm-config-bearer">{
  <span class="prop">"mcpServers"</span>: {
    <span class="prop">"<?php echo esc_html(sanitize_title(get_bloginfo('name')) ?: 'wordpress'); ?>"</span>: {
      <span class="prop">"type"</span>: <span class="str">"http"</span>,
      <span class="prop">"url"</span>:  <span class="str">"<?php echo esc_html($api_base . '/mcp'); ?>"</span>,
      <span class="prop">"headers"</span>: {
        <span class="prop">"Authorization"</span>: <span class="str">"Bearer <?php echo esc_html($token); ?>"</span>
      }
    }
  }
}</div>
        <div style="margin-top:12px;display:flex;gap:10px">
          <button class="cwpm-btn cwpm-btn-outline cwpm-btn-sm" id="cwpm-copy-config-bearer">Copy Config</button>
          <a href="<?php echo esc_url($api_base . '/ping'); ?>" target="_blank" class="cwpm-btn cwpm-btn-outline cwpm-btn-sm">Test ↗</a>
        </div>
      </div>

    </div>
  </div>

  <!-- 3b. System Prompt -->
  <div class="cwpm-card">
    <div class="cwpm-card-head">
      <div class="cwpm-card-head-left">
        <div class="cwpm-card-step" style="background:#06b6d4">AI</div>
        <h2 class="cwpm-card-title">System Prompt for Claude</h2>
      </div>
      <span style="font-size:12px;color:var(--cwpm-muted)">Copy this into Claude's system prompt or project instructions</span>
    </div>
    <div class="cwpm-card-body">
      <p style="font-size:13px;color:var(--cwpm-muted);margin:0 0 14px">
        Paste this prompt into <strong>Claude.ai Project Instructions</strong> or your project's <code style="color:var(--cwpm-accent2)">CLAUDE.md</code> so Claude understands your site and tools automatically.
      </p>
      <?php
      $site_name     = get_bloginfo('name');
      $site_url_val  = get_bloginfo('url');
      $wp_ver        = get_bloginfo('version');
      $theme_obj     = wp_get_theme();
      $theme_name    = $theme_obj->get('Name');
      $plugin_list   = [];
      if ($has_elementor) $plugin_list[] = 'Elementor (page builder)';
      if ($has_yoast)     $plugin_list[] = 'Yoast SEO';
      if ($has_woo)       $plugin_list[] = 'WooCommerce (e-commerce)';
      if ($has_acf)       $plugin_list[] = 'Advanced Custom Fields';
      $plugins_str = $plugin_list ? implode(', ', $plugin_list) : 'Standard WordPress';
      $allowed_groups = implode(', ', $actions);
      $php_exec_token = 'CONFIRM_' . strtoupper( substr( md5( get_option('cwpm_api_token','') . home_url() ), 0, 12 ) );
      $system_prompt = <<<PROMPT
You are connected to the WordPress website "{$site_name}" at {$site_url_val}.

## Site Overview
- WordPress {$wp_ver} | Active theme: {$theme_name}
- Active integrations: {$plugins_str}
- MCP endpoint: {$api_base}/mcp
- Enabled tool groups: {$allowed_groups}

## How to call tools
This site uses MCP Streamable HTTP (JSON-RPC 2.0):
POST {$api_base}/mcp
Authorization: Bearer <token>  (or Basic <base64_credentials>)
Content-Type: application/json

Claude Code connects automatically via mcpServers config — no manual JSON-RPC needed.

## Available Tool Groups & Tools

**content** – create_post, update_post, get_post, list_posts, delete_post, schedule_post, set_featured_image, get_taxonomies, assign_terms
**elementor** – elementor_build_page, elementor_get_data, elementor_set_data, elementor_list_widgets, elementor_get_globals, elementor_set_globals
**seo** – yoast_get_meta, yoast_set_meta, yoast_audit, yoast_sitemap_ping
**media** – upload_media, list_media, get_media, update_media_meta, delete_media
**plugins** – list_plugins, activate_plugin, deactivate_plugin, install_plugin, get_plugin_settings, set_plugin_settings
**theme** – get_theme_mods, set_theme_mods, get_menus, set_menu_items, get_widgets, get_options, set_option
**wordpress** – get_site_info, list_users, get_user, create_term, delete_term, flush_cache, search_replace, get_active_theme, activate_theme, run_cron
**woocommerce** – woo_list_products, woo_get_product, woo_create_product, woo_update_product, woo_list_orders, woo_get_order
**php_exec** – php_exec (requires params.confirm = "{$php_exec_token}" — site-specific, shown in plugin settings)

## Key Workflows

**Create a blog post with SEO:**
1. create_post → returns post_id
2. upload_media (url or base64) → returns media_id
3. set_featured_image {post_id, media_id}
4. yoast_set_meta {post_id, seo_title, meta_description, focus_keyword}
5. update_post {post_id, status: "publish"}

**Build an Elementor page:**
1. create_post {type: "page", title: "..."} → post_id
2. elementor_build_page {post_id, sections: [{columns:[{widgets:[{type:"heading",settings:{title:"..."}}]}]}]}
3. update_post {post_id, status: "publish"}
4. flush_cache

**Manage WooCommerce products:**
1. woo_list_products to browse
2. woo_create_product {name, regular_price, description, status:"publish"}
3. set_featured_image {post_id: product_id, media_id}

**General rule:** Call flush_cache after bulk changes to clear object cache and Elementor CSS.
PROMPT;
      ?>
      <textarea id="cwpm-system-prompt" readonly style="
        width:100%;height:320px;background:#0a0a15;border:1px solid var(--cwpm-border);
        border-radius:8px;padding:14px;color:var(--cwpm-text);font-size:12px;
        font-family:'Cascadia Code','Fira Code',monospace;line-height:1.6;resize:vertical;
        box-sizing:border-box;
      "><?php echo esc_textarea($system_prompt); ?></textarea>
      <div style="margin-top:12px;display:flex;gap:10px">
        <button class="cwpm-btn cwpm-btn-outline cwpm-btn-sm" id="cwpm-copy-prompt">Copy System Prompt</button>
        <a href="https://claude.ai/projects" target="_blank" class="cwpm-btn cwpm-btn-outline cwpm-btn-sm" style="text-decoration:none">Open Claude Projects ↗</a>
      </div>
    </div>
  </div>

  <!-- 4. Capabilities & Access Control -->
  <div class="cwpm-row">

    <div class="cwpm-card">
      <div class="cwpm-card-head">
        <div class="cwpm-card-head-left">
          <div class="cwpm-card-step">4</div>
          <h2 class="cwpm-card-title">Allowed Actions</h2>
        </div>
      </div>
      <div class="cwpm-card-body">
        <p style="font-size:13px;color:var(--cwpm-muted);margin:0 0 14px">Control which capability groups Claude Code can use:</p>
        <div class="cwpm-actions-grid">
          <?php
          $all_actions = ['content','elementor','seo','media','plugins','theme','wordpress','woocommerce','forms','email','php_exec'];
          $labels = ['content'=>'📄 Content','elementor'=>'🎨 Elementor','seo'=>'🔍 Yoast SEO','media'=>'🖼 Media','plugins'=>'🔌 Plugins','theme'=>'🎭 Theme','wordpress'=>'🛠 WP Utilities','woocommerce'=>'🛒 WooCommerce','forms'=>'📋 Forms','email'=>'✉️ Email Logs','php_exec'=>'⚠️ PHP Execute'];
          foreach($all_actions as $act):
            $checked = in_array($act,$actions);
          ?>
          <label class="cwpm-action-check">
            <input type="checkbox" name="cwpm_actions[]" value="<?php echo $act; ?>" <?php checked($checked); ?>>
            <span><?php echo $labels[$act]; ?></span>
          </label>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

    <!-- Settings -->
    <div class="cwpm-card">
      <div class="cwpm-card-head">
        <div class="cwpm-card-head-left">
          <div class="cwpm-card-step">5</div>
          <h2 class="cwpm-card-title">Settings</h2>
        </div>
      </div>
      <div class="cwpm-card-body" style="display:flex;flex-direction:column;gap:16px">
        <div>
          <label style="font-size:12px;color:var(--cwpm-muted);text-transform:uppercase;letter-spacing:.8px;display:block;margin-bottom:6px">Log Level</label>
          <select class="cwpm-select" id="cwpm-log-level">
            <option value="info"  <?php selected($log_level,'info'); ?>>Info — all actions</option>
            <option value="warn"  <?php selected($log_level,'warn'); ?>>Warn — warnings & errors</option>
            <option value="error" <?php selected($log_level,'error'); ?>>Error — errors only</option>
          </select>
        </div>
        <div>
          <label style="font-size:12px;color:var(--cwpm-muted);text-transform:uppercase;letter-spacing:.8px;display:block;margin-bottom:6px">API Endpoint</label>
          <div style="font-size:12.5px;color:var(--cwpm-accent2);font-family:monospace;background:#0a0a12;padding:8px 12px;border-radius:7px;border:1px solid var(--cwpm-border)">
            <?php echo esc_html($api_base); ?>
          </div>
        </div>
        <div>
          <label style="font-size:12px;color:var(--cwpm-muted);text-transform:uppercase;letter-spacing:.8px;display:block;margin-bottom:6px">Available Tools</label>
          <div style="font-size:20px;font-weight:700;color:var(--cwpm-accent2)">56</div>
          <div style="font-size:12px;color:var(--cwpm-muted)">content, elementor, seo, media, plugins, theme, wordpress, woocommerce, forms, email</div>
        </div>
        <?php if ( in_array( 'php_exec', $actions ) ) : ?>
        <div>
          <label style="font-size:12px;color:var(--cwpm-muted);text-transform:uppercase;letter-spacing:.8px;display:block;margin-bottom:6px">PHP Execute Confirm Token</label>
          <?php $php_exec_confirm = 'CONFIRM_' . strtoupper( substr( md5( get_option('cwpm_api_token','') . home_url() ), 0, 12 ) ); ?>
          <div style="font-size:11.5px;color:#f59e0b;font-family:monospace;background:#0a0a12;padding:8px 12px;border-radius:7px;border:1px solid rgba(245,158,11,.3);word-break:break-all">
            <?php echo esc_html( $php_exec_confirm ); ?>
          </div>
          <div style="font-size:11px;color:var(--cwpm-muted);margin-top:4px">Pass this as <code>params.confirm</code> when calling <code>php_exec</code>.</div>
        </div>
        <?php endif; ?>
      </div>
    </div>

  </div>

  <!-- Capabilities overview -->
  <div class="cwpm-card">
    <div class="cwpm-card-head">
      <div class="cwpm-card-head-left">
        <h2 class="cwpm-card-title">Available MCP Tools</h2>
      </div>
      <span style="font-size:12px;color:var(--cwpm-muted)">Claude Code can call any of these tools via the MCP protocol</span>
    </div>
    <div class="cwpm-card-body">
      <div class="cwpm-caps">
        <?php
        $tools = [
          ['create_post','Content'],['update_post','Content'],['get_post','Content'],['list_posts','Content'],
          ['delete_post','Content'],['schedule_post','Content'],['set_featured_image','Content'],['assign_terms','Content'],['get_taxonomies','Content'],
          ['elementor_build_page','Elementor'],['elementor_get_data','Elementor'],['elementor_set_data','Elementor'],
          ['elementor_list_widgets','Elementor'],['elementor_get_globals','Elementor'],['elementor_set_globals','Elementor'],
          ['yoast_get_meta','SEO'],['yoast_set_meta','SEO'],['yoast_audit','SEO'],['yoast_sitemap_ping','SEO'],
          ['upload_media','Media'],['list_media','Media'],['get_media','Media'],['update_media_meta','Media'],['delete_media','Media'],
          ['list_plugins','Plugins'],['activate_plugin','Plugins'],['deactivate_plugin','Plugins'],['install_plugin','Plugins'],['get_plugin_settings','Plugins'],['set_plugin_settings','Plugins'],
          ['get_theme_mods','Theme'],['set_theme_mods','Theme'],['get_menus','Theme'],['set_menu_items','Theme'],['get_widgets','Theme'],['get_options','Theme'],['set_option','Theme'],
          ['get_site_info','WP Utils'],['list_users','WP Utils'],['get_user','WP Utils'],['create_term','WP Utils'],['delete_term','WP Utils'],
          ['flush_cache','WP Utils'],['search_replace','WP Utils'],['get_active_theme','WP Utils'],['activate_theme','WP Utils'],['run_cron','WP Utils'],
          ['woo_list_products','WooCommerce'],['woo_get_product','WooCommerce'],['woo_create_product','WooCommerce'],['woo_update_product','WooCommerce'],['woo_list_orders','WooCommerce'],['woo_get_order','WooCommerce'],
          ['elementor_list_templates','Elementor'],['elementor_import_template','Elementor'],
          ['list_forms','Forms'],['list_form_entries','Forms'],['get_form_entry','Forms'],
          ['list_email_logs','Email'],
          ['php_exec','Advanced'],
        ];
        $colors = ['Content'=>'#6c63ff','Elementor'=>'#e91e8c','SEO'=>'#10b981','Media'=>'#f59e0b','Plugins'=>'#3b82f6','Theme'=>'#8b5cf6','WP Utils'=>'#06b6d4','WooCommerce'=>'#96588a','Forms'=>'#f97316','Email'=>'#14b8a6','Advanced'=>'#ef4444'];
        $group_keys = ['Content'=>'content','Elementor'=>'elementor','SEO'=>'seo','Media'=>'media','Plugins'=>'plugins','Theme'=>'theme','WP Utils'=>'wordpress','WooCommerce'=>'woocommerce','Forms'=>'forms','Email'=>'email','Advanced'=>'php_exec'];
        foreach($tools as [$name,$group]):
          $active = in_array($group_keys[$group] ?? strtolower($group), $actions);
        ?>
        <div class="cwpm-cap active">
          <div class="cwpm-cap-dot" style="background:<?php echo $colors[$group]??'#6c63ff';?>"></div>
          <div>
            <div class="cwpm-cap-name"><?php echo $name; ?></div>
            <div class="cwpm-cap-count"><?php echo $group; ?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <!-- Activity Log -->
  <div class="cwpm-card">
    <div class="cwpm-card-head">
      <div class="cwpm-card-head-left">
        <h2 class="cwpm-card-title">Activity Log</h2>
      </div>
      <button class="cwpm-btn cwpm-btn-danger cwpm-btn-sm" id="cwpm-clear-logs">Clear Logs</button>
    </div>
    <div class="cwpm-card-body">
      <?php if(empty($logs)): ?>
        <div style="text-align:center;padding:32px;color:var(--cwpm-muted);font-size:13px">
          No activity yet. Claude Code actions will appear here.
        </div>
      <?php else: ?>
      <div class="cwpm-log">
        <?php foreach($logs as $entry): ?>
        <div class="cwpm-log-entry <?php echo esc_attr($entry['level']); ?>">
          <span class="cwpm-log-time"><?php echo esc_html(substr($entry['time'],0,19)); ?></span>
          <span class="cwpm-log-level"><?php echo esc_html($entry['level']); ?></span>
          <span><?php echo esc_html($entry['message']); ?></span>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>

</div>

<!-- Save bar -->
<div class="cwpm-save-bar">
  <div style="font-size:13px;color:var(--cwpm-muted)">Changes are saved immediately to your WordPress database.</div>
  <button class="cwpm-btn cwpm-btn-primary" id="cwpm-save">Save Settings</button>
</div>

<!-- Toast -->
<div id="cwpm-toast"></div>

<script>
(function(){
  const nonce = <?php echo json_encode($nonce); ?>;
  const $ = id => document.getElementById(id);

  /* Toggle */
  const toggleTrack = document.querySelector('.cwpm-toggle-track');
  const enabledCb   = $('cwpm-enabled');
  toggleTrack?.addEventListener('click', ()=>{
    enabledCb.checked = !enabledCb.checked;
    toggleTrack.classList.toggle('on', enabledCb.checked);
  });

  /* Toast */
  function toast(msg, ok=true){
    const el = $('cwpm-toast');
    el.innerHTML = (ok?'<span style="color:#10b981">✓</span> ':'<span style="color:#ef4444">✗</span> ') + msg;
    el.classList.add('show');
    setTimeout(()=>el.classList.remove('show'), 3000);
  }

  /* Copy helpers */
  function copyText(text, label){
    navigator.clipboard.writeText(text).then(()=>toast(label + ' copied!')).catch(()=>{
      const ta=document.createElement('textarea'); ta.value=text;
      document.body.appendChild(ta); ta.select(); document.execCommand('copy');
      document.body.removeChild(ta); toast(label+' copied!');
    });
  }

  /* ── Copy helpers ─────────────────────────────────────── */
  $('cwpm-copy-token')?.addEventListener('click',()=> copyText($('cwpm-token-display').dataset.token,'Token'));
  $('cwpm-copy-app-pw')?.addEventListener('click',()=> copyText($('cwpm-app-pw-display').textContent.trim(),'Application Password'));
  $('cwpm-copy-encoded')?.addEventListener('click',()=> copyText($('cwpm-app-encoded-display').textContent.trim(),'Encoded credentials'));
  $('cwpm-copy-prompt')?.addEventListener('click',()=> copyText($('cwpm-system-prompt').value,'System prompt'));
  $('cwpm-copy-config-app')?.addEventListener('click',()=> copyText($('cwpm-config-app').innerText,'Config'));
  $('cwpm-copy-config-bearer')?.addEventListener('click',()=> copyText($('cwpm-config-bearer').innerText,'Config'));

  /* ── Tab switcher ──────────────────────────────────────── */
  window.cwpmShowTab = function(name){
    ['apppassword','bearer'].forEach(t=>{
      $('cwpm-tab-'+t).style.display = t===name ? '' : 'none';
      document.getElementById('tab-'+t)?.classList.toggle('active', t===name);
    });
  };

  /* ── Create Application Password ─────────────────────── */
  $('cwpm-create-app-pw')?.addEventListener('click',()=>{
    const btn = $('cwpm-create-app-pw');
    btn.textContent = 'Creating…';
    btn.disabled = true;
    fetch(ajaxurl,{method:'POST',body:new URLSearchParams({action:'cwpm_create_app_pw',nonce})})
      .then(r=>r.json()).then(d=>{
        btn.disabled = false;
        if(d.success){
          const {username, password, encoded} = d.data;

          /* Hide "no password" notice */
          const noMsg = $('cwpm-no-app-pw');
          if(noMsg) noMsg.style.display = 'none';

          /* Show the credential block */
          const block = $('cwpm-app-pw-block');
          if(block) block.style.display = '';

          /* Update username label */
          const lbl = $('cwpm-app-username-label');
          if(lbl) lbl.innerHTML = 'WordPress user: <strong style="color:var(--cwpm-text)">'+username+'</strong>';

          /* Fill in the password and encoded values */
          const pwBox  = $('cwpm-app-pw-display');
          const encBox = $('cwpm-app-encoded-display');
          if(pwBox)  { pwBox.textContent  = password; pwBox.style.color=''; pwBox.style.fontStyle=''; }
          if(encBox) { encBox.textContent = encoded;  encBox.style.color=''; encBox.style.fontStyle=''; }

          /* Show copy buttons */
          const cpPw  = $('cwpm-copy-app-pw');
          const cpEnc = $('cwpm-copy-encoded');
          if(cpPw)  cpPw.style.display  = '';
          if(cpEnc) cpEnc.style.display = '';

          btn.textContent = '🔄 Regenerate Application Password';

          /* Update Basic Auth config snippet */
          const cfgSpan = document.querySelector('#cwpm-config-app .str:last-child');
          if(cfgSpan) cfgSpan.textContent = '"Basic '+encoded+'"';

          toast('Application Password created! Copy it now — it won\'t be shown again.');
        } else {
          btn.textContent = btn.textContent.includes('Regenerate') ? '🔄 Regenerate Application Password' : '🔑 Create Application Password';
          toast('Error: '+(d.data?.message||'Unknown error'), false);
        }
      }).catch(()=>{
        btn.disabled = false;
        toast('Request failed — check browser console.', false);
      });
  });

  /* ── Regen Bearer token ─────────────────────────────── */
  $('cwpm-regen-token')?.addEventListener('click',()=>{
    if(!confirm('Regenerate token? Claude Code will need the new token.')) return;
    fetch(ajaxurl,{method:'POST',body:new URLSearchParams({action:'cwpm_regen',nonce})})
      .then(r=>r.json()).then(d=>{
        if(d.success){
          const t = d.data.token;
          const masked = t.length > 16 ? t.slice(0,8)+'…'+t.slice(-8) : '•'.repeat(t.length);
          const el = $('cwpm-token-display');
          el.dataset.token = t;
          el.textContent   = masked;
          toast('Token regenerated — update Claude Code config!');
        }
      });
  });

  /* ── Save settings ──────────────────────────────────── */
  $('cwpm-save')?.addEventListener('click',()=>{
    const fd = new FormData();
    fd.append('action','cwpm_save');
    fd.append('nonce',nonce);
    if(enabledCb.checked) fd.append('enabled','1');
    fd.append('log_level',$('cwpm-log-level').value);
    document.querySelectorAll('input[name="cwpm_actions[]"]:checked').forEach(c=>fd.append('allowed_actions[]',c.value));
    fetch(ajaxurl,{method:'POST',body:fd})
      .then(r=>r.json()).then(d=> toast(d.success ? 'Settings saved!' : 'Error saving.', d.success));
  });

  /* ── Clear logs ─────────────────────────────────────── */
  $('cwpm-clear-logs')?.addEventListener('click',()=>{
    fetch(ajaxurl,{method:'POST',body:new URLSearchParams({action:'cwpm_clear_logs',nonce})})
      .then(r=>r.json()).then(d=>{ if(d.success){ document.querySelector('.cwpm-log').innerHTML='<div style="text-align:center;padding:32px;color:var(--cwpm-muted);font-size:13px">Log cleared.</div>'; toast('Logs cleared.'); } });
  });

  /* ── Admin bar bg fix ───────────────────────────────── */
  document.addEventListener('DOMContentLoaded',()=>{
    const wrap = document.querySelector('#wpcontent');
    if(wrap) wrap.style.background='#0f0f17';
    const adminmenu = document.querySelector('#adminmenuback');
    if(adminmenu) adminmenu.style.background='#0f0f17';
  });
})();
</script>
