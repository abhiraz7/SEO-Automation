<?php
/**
 * Plugin Name: Claude WP Developer
 * Plugin URI:  https://github.com/your-repo/claude-wp-mcp
 * Description: Full MCP server for Claude Code — gives Claude complete WordPress developer access including Elementor, Yoast SEO, media library, scheduling, and plugin management.
 * Version:     1.5.2
 * Author:      Your Name
 * License:     GPL-2.0+
 * Text Domain: claude-wp-mcp
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'CWPM_VERSION',    '1.5.2' );
define( 'CWPM_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'CWPM_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'CWPM_SLUG',       'claude-wp-mcp' );

/* ── Autoload modules ─────────────────────────────────────── */
require_once CWPM_PLUGIN_DIR . 'includes/class-auth.php';
require_once CWPM_PLUGIN_DIR . 'includes/class-router.php';
require_once CWPM_PLUGIN_DIR . 'includes/class-mcp.php';
require_once CWPM_PLUGIN_DIR . 'includes/class-logger.php';
require_once CWPM_PLUGIN_DIR . 'mcp-handlers/handler-content.php';
require_once CWPM_PLUGIN_DIR . 'mcp-handlers/handler-elementor.php';
require_once CWPM_PLUGIN_DIR . 'mcp-handlers/handler-seo.php';
require_once CWPM_PLUGIN_DIR . 'mcp-handlers/handler-media.php';
require_once CWPM_PLUGIN_DIR . 'mcp-handlers/handler-plugins.php';
require_once CWPM_PLUGIN_DIR . 'mcp-handlers/handler-theme.php';
require_once CWPM_PLUGIN_DIR . 'mcp-handlers/handler-wordpress.php';
require_once CWPM_PLUGIN_DIR . 'mcp-handlers/handler-woocommerce.php';
require_once CWPM_PLUGIN_DIR . 'mcp-handlers/handler-forms.php';
require_once CWPM_PLUGIN_DIR . 'mcp-handlers/handler-email.php';
require_once CWPM_PLUGIN_DIR . 'mcp-handlers/handler-divi.php';
require_once CWPM_PLUGIN_DIR . 'admin/class-admin.php';

/* ── Boot ─────────────────────────────────────────────────── */
add_action( 'plugins_loaded', function () {
    CWPM_Auth::init();
    CWPM_Router::init();
    CWPM_Admin::init();
} );

/* ── REST namespace registration ──────────────────────────── */
add_action( 'rest_api_init', function () {
    CWPM_Router::register_routes();
} );

/* ── Activation ───────────────────────────────────────────── */
register_activation_hook( __FILE__, function () {
    $token = bin2hex( random_bytes( 32 ) );
    add_option( 'cwpm_api_token', $token );
    add_option( 'cwpm_enabled',   '1' );
    add_option( 'cwpm_log_level', 'info' );
    // php_exec is intentionally excluded from defaults — must be manually enabled.
    add_option( 'cwpm_allowed_actions', json_encode( [
        'content', 'elementor', 'seo', 'media', 'plugins', 'theme', 'wordpress', 'woocommerce', 'forms', 'email', 'divi',
    ] ) );
    flush_rewrite_rules();
} );

register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );
