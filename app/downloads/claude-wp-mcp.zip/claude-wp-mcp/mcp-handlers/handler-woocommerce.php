<?php
/**
 * WooCommerce tools: products and orders.
 * All methods throw if WooCommerce is not active.
 */
class CWPM_WooCommerce {

    private static function check(): void {
        if ( ! class_exists( 'WooCommerce' ) ) {
            throw new Exception( 'WooCommerce is not active on this site.' );
        }
    }

    /* ── List products ───────────────────────────────────── */
    public static function list_products( array $p ): array {
        self::check();

        $args = [
            'post_type'      => 'product',
            'post_status'    => sanitize_key( $p['status'] ?? 'publish' ),
            'posts_per_page' => intval( $p['per_page'] ?? 20 ),
            'paged'          => intval( $p['page'] ?? 1 ),
            's'              => sanitize_text_field( $p['search'] ?? '' ),
        ];

        if ( ! empty( $p['category'] ) ) {
            $args['tax_query'] = [ [
                'taxonomy' => 'product_cat',
                'field'    => 'slug',
                'terms'    => sanitize_text_field( $p['category'] ),
            ] ];
        }

        $query    = new WP_Query( $args );
        $products = [];

        foreach ( $query->posts as $post ) {
            $product = wc_get_product( $post->ID );
            if ( ! $product ) continue;

            $products[] = [
                'id'            => $product->get_id(),
                'name'          => $product->get_name(),
                'slug'          => $product->get_slug(),
                'type'          => $product->get_type(),
                'status'        => $product->get_status(),
                'price'         => $product->get_price(),
                'regular_price' => $product->get_regular_price(),
                'sale_price'    => $product->get_sale_price(),
                'sku'           => $product->get_sku(),
                'stock_status'  => $product->get_stock_status(),
                'url'           => get_permalink( $post->ID ),
                'image_url'     => wp_get_attachment_url( $product->get_image_id() ),
            ];
        }

        return [ 'products' => $products, 'total' => $query->found_posts ];
    }

    /* ── Get single product ──────────────────────────────── */
    public static function get_product( array $p ): array {
        self::check();

        $id      = intval( $p['product_id'] ?? 0 );
        $product = wc_get_product( $id );
        if ( ! $product ) throw new Exception( "Product #{$id} not found." );

        return [
            'id'                => $product->get_id(),
            'name'              => $product->get_name(),
            'slug'              => $product->get_slug(),
            'type'              => $product->get_type(),
            'status'            => $product->get_status(),
            'description'       => $product->get_description(),
            'short_description' => $product->get_short_description(),
            'price'             => $product->get_price(),
            'regular_price'     => $product->get_regular_price(),
            'sale_price'        => $product->get_sale_price(),
            'sku'               => $product->get_sku(),
            'stock_quantity'    => $product->get_stock_quantity(),
            'stock_status'      => $product->get_stock_status(),
            'manage_stock'      => $product->get_manage_stock(),
            'weight'            => $product->get_weight(),
            'categories'        => wp_get_post_terms( $id, 'product_cat', [ 'fields' => 'names' ] ),
            'tags'              => wp_get_post_terms( $id, 'product_tag', [ 'fields' => 'names' ] ),
            'image_url'         => wp_get_attachment_url( $product->get_image_id() ),
            'gallery_urls'      => array_map(
                fn( $img_id ) => wp_get_attachment_url( $img_id ),
                $product->get_gallery_image_ids()
            ),
            'url'               => get_permalink( $id ),
            'meta_data'         => array_map(
                fn( $m ) => [ 'key' => $m->key, 'value' => $m->value ],
                $product->get_meta_data()
            ),
        ];
    }

    /* ── Create product ──────────────────────────────────── */
    public static function create_product( array $p ): array {
        self::check();

        $product = new WC_Product_Simple();
        $product->set_name( sanitize_text_field( $p['name'] ?? 'New Product' ) );
        $product->set_status( sanitize_key( $p['status'] ?? 'draft' ) );
        $product->set_description( $p['description'] ?? '' );
        $product->set_short_description( $p['short_description'] ?? '' );

        if ( isset( $p['regular_price'] ) )  $product->set_regular_price( $p['regular_price'] );
        if ( isset( $p['sale_price'] ) )     $product->set_sale_price( $p['sale_price'] );
        if ( isset( $p['sku'] ) )            $product->set_sku( sanitize_text_field( $p['sku'] ) );
        if ( isset( $p['stock_quantity'] ) ) $product->set_stock_quantity( intval( $p['stock_quantity'] ) );
        if ( isset( $p['manage_stock'] ) )   $product->set_manage_stock( (bool) $p['manage_stock'] );
        if ( isset( $p['stock_status'] ) )   $product->set_stock_status( sanitize_key( $p['stock_status'] ) );
        if ( isset( $p['weight'] ) )         $product->set_weight( $p['weight'] );
        if ( isset( $p['image_id'] ) )       $product->set_image_id( intval( $p['image_id'] ) );

        $product_id = $product->save();

        if ( ! empty( $p['categories'] ) ) {
            wp_set_post_terms( $product_id, array_map( 'intval', $p['categories'] ), 'product_cat' );
        }
        if ( ! empty( $p['tags'] ) ) {
            wp_set_post_terms( $product_id, array_map( 'intval', $p['tags'] ), 'product_tag' );
        }

        CWPM_Logger::log( 'info', "Created WooCommerce product #{$product_id}: " . $product->get_name() );
        return [ 'product_id' => $product_id, 'url' => get_permalink( $product_id ) ];
    }

    /* ── Update product ──────────────────────────────────── */
    public static function update_product( array $p ): array {
        self::check();

        $id      = intval( $p['product_id'] ?? 0 );
        $product = wc_get_product( $id );
        if ( ! $product ) throw new Exception( "Product #{$id} not found." );

        if ( isset( $p['name'] ) )              $product->set_name( sanitize_text_field( $p['name'] ) );
        if ( isset( $p['status'] ) )            $product->set_status( sanitize_key( $p['status'] ) );
        if ( isset( $p['description'] ) )       $product->set_description( $p['description'] );
        if ( isset( $p['short_description'] ) ) $product->set_short_description( $p['short_description'] );
        if ( isset( $p['regular_price'] ) )     $product->set_regular_price( $p['regular_price'] );
        if ( isset( $p['sale_price'] ) )        $product->set_sale_price( $p['sale_price'] );
        if ( isset( $p['sku'] ) )               $product->set_sku( sanitize_text_field( $p['sku'] ) );
        if ( isset( $p['stock_quantity'] ) )    $product->set_stock_quantity( intval( $p['stock_quantity'] ) );
        if ( isset( $p['manage_stock'] ) )      $product->set_manage_stock( (bool) $p['manage_stock'] );
        if ( isset( $p['stock_status'] ) )      $product->set_stock_status( sanitize_key( $p['stock_status'] ) );
        if ( isset( $p['image_id'] ) )          $product->set_image_id( intval( $p['image_id'] ) );

        $product->save();

        if ( ! empty( $p['categories'] ) ) {
            wp_set_post_terms( $id, array_map( 'intval', $p['categories'] ), 'product_cat' );
        }
        if ( ! empty( $p['tags'] ) ) {
            wp_set_post_terms( $id, array_map( 'intval', $p['tags'] ), 'product_tag' );
        }

        CWPM_Logger::log( 'info', "Updated WooCommerce product #{$id}" );
        return [ 'product_id' => $id, 'url' => get_permalink( $id ) ];
    }

    /* ── List orders ─────────────────────────────────────── */
    public static function list_orders( array $p ): array {
        self::check();

        $args = [
            'limit'  => intval( $p['per_page'] ?? 20 ),
            'paged'  => intval( $p['page'] ?? 1 ),
            'status' => sanitize_key( $p['status'] ?? 'any' ),
        ];
        if ( ! empty( $p['customer_id'] ) ) $args['customer_id'] = intval( $p['customer_id'] );

        $orders = wc_get_orders( $args );

        return [
            'orders' => array_map( fn( $o ) => [
                'id'          => $o->get_id(),
                'status'      => $o->get_status(),
                'total'       => $o->get_total(),
                'currency'    => $o->get_currency(),
                'customer'    => trim( $o->get_billing_first_name() . ' ' . $o->get_billing_last_name() ),
                'email'       => $o->get_billing_email(),
                'date'        => $o->get_date_created() ? $o->get_date_created()->format( 'Y-m-d H:i:s' ) : null,
                'items_count' => $o->get_item_count(),
            ], $orders ),
        ];
    }

    /* ── Get single order ────────────────────────────────── */
    public static function get_order( array $p ): array {
        self::check();

        $id    = intval( $p['order_id'] ?? 0 );
        $order = wc_get_order( $id );
        if ( ! $order ) throw new Exception( "Order #{$id} not found." );

        $items = [];
        foreach ( $order->get_items() as $item ) {
            $items[] = [
                'product_id' => $item->get_product_id(),
                'name'       => $item->get_name(),
                'quantity'   => $item->get_quantity(),
                'total'      => $item->get_total(),
            ];
        }

        return [
            'id'             => $order->get_id(),
            'status'         => $order->get_status(),
            'total'          => $order->get_total(),
            'subtotal'       => $order->get_subtotal(),
            'currency'       => $order->get_currency(),
            'payment_method' => $order->get_payment_method_title(),
            'customer_id'    => $order->get_customer_id(),
            'billing'        => [
                'first_name' => $order->get_billing_first_name(),
                'last_name'  => $order->get_billing_last_name(),
                'email'      => $order->get_billing_email(),
                'phone'      => $order->get_billing_phone(),
                'address_1'  => $order->get_billing_address_1(),
                'city'       => $order->get_billing_city(),
                'country'    => $order->get_billing_country(),
            ],
            'shipping'       => [
                'first_name' => $order->get_shipping_first_name(),
                'last_name'  => $order->get_shipping_last_name(),
                'address_1'  => $order->get_shipping_address_1(),
                'city'       => $order->get_shipping_city(),
                'country'    => $order->get_shipping_country(),
            ],
            'items'          => $items,
            'date_created'   => $order->get_date_created() ? $order->get_date_created()->format( 'Y-m-d H:i:s' ) : null,
            'customer_note'  => $order->get_customer_note(),
        ];
    }
}
