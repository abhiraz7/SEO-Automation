<?php
class CWPM_Theme {

    /**
     * wp_options keys that must never be written via the API.
     * Modifying these could redirect the site, hijack auth, or enable RCE.
     */
    const BLOCKED_OPTIONS = [
        'siteurl', 'home', 'blogname', 'admin_email',
        'active_plugins', 'active_sitewide_plugins',
        'stylesheet', 'template',
        'upload_path', 'upload_url_path',
        'auth_key', 'secure_auth_key', 'logged_in_key', 'nonce_key',
        'auth_salt', 'secure_auth_salt', 'logged_in_salt', 'nonce_salt',
        'wp_user_roles',
        'default_role',
        'cwpm_api_token', 'cwpm_app_password', 'cwpm_allowed_actions',
    ];

    /* ── Theme mods ──────────────────────────────────────── */
    public static function get_mods( array $p ): array {
        return get_theme_mods() ?: [];
    }

    public static function set_mods( array $p ): array {
        $mods    = $p['mods'] ?? [];
        $updated = [];
        foreach ( $mods as $key => $value ) {
            set_theme_mod( sanitize_key( $key ), $value );
            $updated[] = $key;
        }
        CWPM_Logger::log( 'info', 'Set theme mods: ' . implode( ', ', $updated ) );
        return [ 'updated' => $updated ];
    }

    /* ── Navigation menus ────────────────────────────────── */
    public static function get_menus( array $p ): array {
        $menus = wp_get_nav_menus();
        $out   = [];
        foreach ( $menus as $menu ) {
            $items = wp_get_nav_menu_items( $menu->term_id );
            $out[] = [
                'id'    => $menu->term_id,
                'name'  => $menu->name,
                'slug'  => $menu->slug,
                'count' => $menu->count,
                'items' => $items ? array_map( fn($i) => [
                    'id'         => $i->ID,
                    'title'      => $i->title,
                    'url'        => $i->url,
                    'type'       => $i->type,
                    'object'     => $i->object,
                    'object_id'  => $i->object_id,
                    'parent'     => $i->menu_item_parent,
                    'order'      => $i->menu_order,
                ], $items ) : [],
            ];
        }
        return [ 'menus' => $out ];
    }

    public static function set_menu_items( array $p ): array {
        $menu_id = intval( $p['menu_id'] ?? 0 );
        $items   = $p['items'] ?? [];
        $results = [];

        foreach ( $items as $item ) {
            $item_id = intval( $item['id'] ?? 0 );
            $args = [
                'menu-item-title'     => sanitize_text_field( $item['title'] ?? '' ),
                'menu-item-url'       => esc_url_raw( $item['url'] ?? '' ),
                'menu-item-status'    => 'publish',
                'menu-item-type'      => sanitize_key( $item['type'] ?? 'custom' ),
                'menu-item-object'    => sanitize_key( $item['object'] ?? 'custom' ),
                'menu-item-object-id' => intval( $item['object_id'] ?? 0 ),
                'menu-item-parent-id' => intval( $item['parent'] ?? 0 ),
            ];

            if ( $item_id ) {
                $result = wp_update_nav_menu_item( $menu_id, $item_id, $args );
            } else {
                $result = wp_update_nav_menu_item( $menu_id, 0, $args );
            }
            $results[] = is_wp_error( $result ) ? 'error: ' . $result->get_error_message() : $result;
        }

        CWPM_Logger::log( 'info', "Updated menu #{$menu_id} items." );
        return [ 'menu_id' => $menu_id, 'results' => $results ];
    }

    /* ── Sidebars / Widgets ──────────────────────────────── */
    public static function get_widgets( array $p ): array {
        global $wp_registered_sidebars, $wp_registered_widgets;
        $sidebars_widgets = get_option( 'sidebars_widgets', [] );

        $out = [];
        foreach ( $wp_registered_sidebars as $id => $sidebar ) {
            $widget_ids = $sidebars_widgets[ $id ] ?? [];
            $widgets    = [];
            foreach ( $widget_ids as $widget_id ) {
                $widgets[] = [
                    'widget_id'   => $widget_id,
                    'name'        => $wp_registered_widgets[ $widget_id ]['name'] ?? $widget_id,
                    'classname'   => $wp_registered_widgets[ $widget_id ]['classname'] ?? '',
                ];
            }
            $out[] = [
                'sidebar_id'   => $id,
                'sidebar_name' => $sidebar['name'],
                'widgets'      => $widgets,
            ];
        }

        return [ 'sidebars' => $out ];
    }

    /* ── wp_options CRUD ─────────────────────────────────── */
    public static function get_options( array $p ): array {
        $keys   = (array) ( $p['keys'] ?? [] );
        $result = [];
        foreach ( $keys as $key ) {
            $clean = sanitize_key( $key );
            // Block sensitive option reads too.
            if ( in_array( $clean, self::BLOCKED_OPTIONS, true ) ) {
                $result[ $clean ] = '[blocked]';
                continue;
            }
            $result[ $clean ] = get_option( $clean );
        }
        return $result;
    }

    public static function set_option( array $p ): array {
        $key   = sanitize_key( $p['key'] ?? '' );
        $value = $p['value'] ?? '';
        if ( ! $key ) throw new Exception( 'key required.' );

        if ( in_array( $key, self::BLOCKED_OPTIONS, true ) ) {
            throw new Exception( "Option '{$key}' is protected and cannot be modified via the API." );
        }

        update_option( $key, $value );
        CWPM_Logger::log( 'info', "Set option: {$key}" );
        return [ 'key' => $key, 'updated' => true ];
    }

    /* ── PHP execution (DANGEROUS — dev/staging only) ─────── */
    public static function php_exec( array $p ): array {
        // Confirmation must match a site-specific token, not a hardcoded public string.
        $expected = 'CONFIRM_' . strtoupper( substr( md5( get_option( 'cwpm_api_token', '' ) . home_url() ), 0, 12 ) );

        if ( empty( $p['confirm'] ) || $p['confirm'] !== $expected ) {
            throw new Exception(
                "php_exec requires params.confirm = \"{$expected}\" (site-specific token shown in Claude WP Developer settings)."
            );
        }

        $code = $p['code'] ?? '';
        if ( empty( $code ) ) throw new Exception( 'code required.' );

        CWPM_Logger::log( 'warn', 'php_exec called. Code: ' . substr( $code, 0, 200 ) );

        ob_start();
        $result = null;
        try {
            // phpcs:ignore Squiz.PHP.Eval.Discouraged
            $result = eval( $code );
        } catch ( Throwable $e ) {
            ob_end_clean();
            throw new Exception( 'PHP error: ' . $e->getMessage() );
        }
        $output = ob_get_clean();

        return [
            'return_value' => $result,
            'output'       => $output,
        ];
    }
}
