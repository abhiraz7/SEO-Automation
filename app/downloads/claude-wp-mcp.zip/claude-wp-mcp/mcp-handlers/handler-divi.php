<?php
/**
 * Divi Builder Handler
 *
 * Supports Divi 4 (shortcode-based) and Divi 5 (React/JSON).
 * On Divi 5 sites, shortcode format is still accepted and rendered;
 * writing well-formed shortcodes to post_content always works.
 *
 * Tools provided:
 *   divi_get_data          — read Divi content + builder meta from a post
 *   divi_set_data          — write raw Divi shortcodes to a post
 *   divi_build_page        — build a page from a structured sections spec
 *   divi_list_modules      — catalog of every supported Divi module
 *   divi_get_globals       — global colors, theme options, accent color
 *   divi_set_globals       — update global colors / theme mods
 *   divi_list_layouts      — saved layouts from the Divi library
 *   divi_import_layout     — apply (or append) a saved layout to a post
 *   divi_flush_cache       — clear Divi static CSS cache site-wide or per-post
 *   divi_get_theme_builder — list Theme Builder header/footer/body templates
 */
class CWPM_Divi {

    /* Shortcode _builder_version written into generated output */
    const SC_VERSION = '4.27.0';

    /* ════════════════════════════════════════════════════════
     *  divi_get_data
     * ════════════════════════════════════════════════════════ */

    public static function get_data( array $p ): array {
        $post_id = intval( $p['post_id'] ?? 0 );
        if ( ! $post_id ) throw new Exception( 'post_id required.' );

        $post = get_post( $post_id );
        if ( ! $post ) throw new Exception( "Post #{$post_id} not found." );

        $use_builder = get_post_meta( $post_id, '_et_pb_use_builder', true );
        $builder_ver = get_post_meta( $post_id, '_et_builder_version', true );
        $is_d5       = defined( 'ET_BUILDER_PRODUCT_VERSION' )
                       && version_compare( ET_BUILDER_PRODUCT_VERSION, '5.0', '>=' );

        $result = [
            'post_id'      => $post_id,
            'title'        => $post->post_title,
            'uses_divi'    => $use_builder === 'on',
            'divi_version' => $builder_ver
                              ?: ( defined( 'ET_BUILDER_PRODUCT_VERSION' ) ? ET_BUILDER_PRODUCT_VERSION : 'unknown' ),
            'is_divi_5'    => $is_d5,
            'shortcodes'   => $post->post_content,
        ];

        if ( $is_d5 ) {
            $result['d5_builder_active'] = get_post_meta( $post_id, '_et_gb_use_builder', true ) === 'on';
        }

        return $result;
    }

    /* ════════════════════════════════════════════════════════
     *  divi_set_data
     * ════════════════════════════════════════════════════════ */

    public static function set_data( array $p ): array {
        $post_id = intval( $p['post_id'] ?? 0 );
        $content = $p['content'] ?? '';
        if ( ! $post_id )           throw new Exception( 'post_id required.' );
        if ( ! is_string( $content ) ) throw new Exception( 'content must be a string of Divi shortcodes.' );

        // Strip executable markup while preserving Divi shortcode brackets.
        $content = wp_kses_post( $content );

        wp_update_post( [ 'ID' => $post_id, 'post_content' => $content ] );
        update_post_meta( $post_id, '_et_pb_use_builder',    'on' );
        update_post_meta( $post_id, '_et_builder_edit_saved', 'on' );

        if ( self::is_divi_5() ) {
            update_post_meta( $post_id, '_et_gb_use_builder', 'on' );
        }

        self::clear_divi_cache( $post_id );

        CWPM_Logger::log( 'info', "Set Divi data on post #{$post_id}" );
        return [ 'post_id' => $post_id, 'saved' => true, 'url' => get_permalink( $post_id ) ];
    }

    /* ════════════════════════════════════════════════════════
     *  divi_build_page
     * ════════════════════════════════════════════════════════ */

    /**
     * Build a Divi page from a high-level sections spec.
     *
     * Spec shape (JSON):
     * {
     *   "post_id": 42,
     *   "sections": [
     *     {
     *       "background": {
     *         "color": "#1a1a2e",
     *         "gradient": {"from": "#667eea", "to": "#764ba2", "angle": 135},
     *         "image": "https://...",
     *         "parallax": true
     *       },
     *       "padding": "120px|0|120px|0",
     *       "min_height": "100vh",
     *       "text_align": "center",
     *       "css_class": "hero-section",
     *       "rows": [
     *         {
     *           "layout": "4_4",
     *           "max_width": "800px",
     *           "columns": [
     *             {
     *               "modules": [
     *                 {"type": "et_pb_text",   "settings": {"content": "<h1>Hello</h1>", "text_color": "#fff"}},
     *                 {"type": "et_pb_button", "settings": {"text": "Get Started", "url": "/contact"}}
     *               ]
     *             }
     *           ]
     *         }
     *       ]
     *     }
     *   ]
     * }
     *
     * Layout values (rows.layout):
     *   "4_4"            — 1 full-width column
     *   "1_2 1_2"        — 2 equal columns (space-separated types)
     *   "1_3 1_3 1_3"    — 3 equal columns
     *   "1_4 1_4 1_4 1_4"— 4 equal columns
     *   "2_3 1_3"        — two-thirds + one-third
     *   "3_4 1_4"        — three-quarters + one-quarter
     *   (omit to auto-detect from column count)
     */
    public static function build_page( array $p ): array {
        $post_id  = intval( $p['post_id'] ?? 0 );
        $sections = $p['sections'] ?? [];
        if ( ! $post_id )       throw new Exception( 'post_id required.' );
        if ( empty( $sections ) ) throw new Exception( 'sections array required.' );

        $shortcodes = self::build_shortcodes( $sections );

        wp_update_post( [ 'ID' => $post_id, 'post_content' => $shortcodes ] );
        update_post_meta( $post_id, '_et_pb_use_builder',    'on' );
        update_post_meta( $post_id, '_et_builder_edit_saved', 'on' );

        if ( self::is_divi_5() ) {
            update_post_meta( $post_id, '_et_gb_use_builder', 'on' );
        }

        self::clear_divi_cache( $post_id );

        CWPM_Logger::log( 'info', "Built Divi page on post #{$post_id} with " . count( $sections ) . ' sections.' );
        return [
            'post_id'  => $post_id,
            'sections' => count( $sections ),
            'url'      => get_permalink( $post_id ),
        ];
    }

    /* ════════════════════════════════════════════════════════
     *  divi_list_modules
     * ════════════════════════════════════════════════════════ */

    public static function list_modules( array $p ): array {
        return [ 'modules' => self::module_catalog() ];
    }

    /* ════════════════════════════════════════════════════════
     *  divi_get_globals
     * ════════════════════════════════════════════════════════ */

    public static function get_globals( array $p ): array {
        $global_colors = get_option( 'et_global_colors', [] );

        $mods_all   = get_theme_mods();
        $divi_mods  = [];
        foreach ( [
            'accent_color', 'primary_nav_bg', 'primary_nav_font_color',
            'body_font_color', 'body_font_size', 'body_font',
            'header_style', 'footer_columns', 'et_color_palette',
        ] as $key ) {
            if ( array_key_exists( $key, $mods_all ) ) {
                $divi_mods[ $key ] = $mods_all[ $key ];
            }
        }

        return [
            'global_colors' => $global_colors,
            'theme_mods'    => $divi_mods,
        ];
    }

    /* ════════════════════════════════════════════════════════
     *  divi_set_globals
     * ════════════════════════════════════════════════════════ */

    public static function set_globals( array $p ): array {
        $updated = [];

        if ( ! empty( $p['global_colors'] ) && is_array( $p['global_colors'] ) ) {
            $existing = get_option( 'et_global_colors', [] );
            foreach ( $p['global_colors'] as $color ) {
                if ( empty( $color['id'] ) ) continue;
                $idx = null;
                foreach ( $existing as $i => $c ) {
                    if ( ( $c['id'] ?? '' ) === $color['id'] ) { $idx = $i; break; }
                }
                if ( $idx !== null ) {
                    $existing[ $idx ] = array_merge( $existing[ $idx ], $color );
                } else {
                    $existing[] = $color;
                }
            }
            update_option( 'et_global_colors', $existing );
            $updated[] = 'global_colors';
        }

        if ( ! empty( $p['accent_color'] ) ) {
            set_theme_mod( 'accent_color', sanitize_hex_color( $p['accent_color'] ) );
            $updated[] = 'accent_color';
        }

        if ( ! empty( $p['theme_mods'] ) && is_array( $p['theme_mods'] ) ) {
            foreach ( $p['theme_mods'] as $key => $value ) {
                set_theme_mod( sanitize_key( $key ), $value );
                $updated[] = "theme_mod:{$key}";
            }
        }

        self::clear_divi_cache();

        CWPM_Logger::log( 'info', 'Updated Divi globals: ' . implode( ', ', $updated ) );
        return [ 'updated' => $updated ];
    }

    /* ════════════════════════════════════════════════════════
     *  divi_list_layouts
     * ════════════════════════════════════════════════════════ */

    public static function list_layouts( array $p ): array {
        $type_filter = sanitize_text_field( $p['type'] ?? '' );

        $args = [
            'post_type'      => 'et_pb_layout',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'orderby'        => 'title',
            'order'          => 'ASC',
        ];

        if ( $type_filter ) {
            $args['tax_query'] = [ [
                'taxonomy' => 'layout_type',
                'field'    => 'slug',
                'terms'    => $type_filter,
            ] ];
        }

        $posts   = get_posts( $args );
        $layouts = [];

        foreach ( $posts as $post ) {
            $type_terms = wp_get_post_terms( $post->ID, 'layout_type' );
            $cat_terms  = wp_get_post_terms( $post->ID, 'layout_category' );
            $type_slug  = ( ! is_wp_error( $type_terms ) && ! empty( $type_terms ) ) ? $type_terms[0]->slug : 'section';
            $category   = ( ! is_wp_error( $cat_terms ) && ! empty( $cat_terms ) )  ? $cat_terms[0]->name  : '';

            $layouts[] = [
                'id'       => $post->ID,
                'title'    => $post->post_title,
                'type'     => $type_slug,
                'category' => $category,
                'modified' => $post->post_modified,
            ];
        }

        return [ 'layouts' => $layouts, 'count' => count( $layouts ) ];
    }

    /* ════════════════════════════════════════════════════════
     *  divi_import_layout
     * ════════════════════════════════════════════════════════ */

    public static function import_layout( array $p ): array {
        $post_id   = intval( $p['post_id']   ?? 0 );
        $layout_id = intval( $p['layout_id'] ?? 0 );
        if ( ! $post_id )   throw new Exception( 'post_id required.' );
        if ( ! $layout_id ) throw new Exception( 'layout_id required.' );

        $layout = get_post( $layout_id );
        if ( ! $layout || $layout->post_type !== 'et_pb_layout' ) {
            throw new Exception( "Layout #{$layout_id} not found in Divi library." );
        }

        $new_content = $layout->post_content;

        if ( ! empty( $p['append'] ) ) {
            $existing    = get_post_field( 'post_content', $post_id );
            $new_content = rtrim( $existing ) . "\n" . $new_content;
        }

        wp_update_post( [ 'ID' => $post_id, 'post_content' => $new_content ] );
        update_post_meta( $post_id, '_et_pb_use_builder',    'on' );
        update_post_meta( $post_id, '_et_builder_edit_saved', 'on' );

        self::clear_divi_cache( $post_id );

        CWPM_Logger::log( 'info', "Imported Divi layout #{$layout_id} to post #{$post_id}" );
        return [
            'post_id'     => $post_id,
            'layout_id'   => $layout_id,
            'layout_name' => $layout->post_title,
            'appended'    => ! empty( $p['append'] ),
            'url'         => get_permalink( $post_id ),
        ];
    }

    /* ════════════════════════════════════════════════════════
     *  divi_flush_cache
     * ════════════════════════════════════════════════════════ */

    public static function flush_cache( array $p ): array {
        $post_id = intval( $p['post_id'] ?? 0 );
        self::clear_divi_cache( $post_id ?: null );
        CWPM_Logger::log( 'info', 'Divi cache flushed' . ( $post_id ? " (post #{$post_id})" : ' (all)' ) );
        return [ 'flushed' => true, 'scope' => $post_id ? "post:{$post_id}" : 'site-wide' ];
    }

    /* ════════════════════════════════════════════════════════
     *  divi_get_theme_builder
     * ════════════════════════════════════════════════════════ */

    public static function get_theme_builder( array $p ): array {
        $templates = get_posts( [
            'post_type'      => 'et_template',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'orderby'        => 'title',
            'order'          => 'ASC',
        ] );

        $result = [];
        foreach ( $templates as $tpl ) {
            $result[] = [
                'id'     => $tpl->ID,
                'title'  => $tpl->post_title,
                'type'   => get_post_meta( $tpl->ID, '_et_template_type',  true ) ?: 'unknown',
                'use_on' => get_post_meta( $tpl->ID, '_et_pb_use_on',      true ),
            ];
        }

        return [
            'theme_builder_version' => get_option( 'et_theme_builder_version', null ),
            'templates'             => $result,
            'count'                 => count( $result ),
        ];
    }

    /* ════════════════════════════════════════════════════════
     *  Shortcode builder — sections → rows → columns → modules
     * ════════════════════════════════════════════════════════ */

    private static function build_shortcodes( array $sections ): string {
        $out = '';
        foreach ( $sections as $sec ) {
            $out .= self::sc_section( $sec );
        }
        return $out;
    }

    private static function sc_section( array $def ): string {
        $a = [
            'fb_built'        => '1',
            '_builder_version'=> self::SC_VERSION,
        ];

        $bg = $def['background'] ?? [];
        if ( ! empty( $bg['color'] ) ) {
            $a['background_color'] = $bg['color'];
        }
        if ( ! empty( $bg['gradient'] ) ) {
            $a['use_background_color_gradient']  = 'on';
            $a['background_color_gradient_start']= $bg['gradient']['from'] ?? '';
            $a['background_color_gradient_end']  = $bg['gradient']['to']   ?? '';
            $a['background_color_gradient_direction'] = ( $bg['gradient']['angle'] ?? 135 ) . 'deg';
        }
        if ( ! empty( $bg['image'] ) ) {
            $a['background_image'] = $bg['image'];
            $a['parallax']         = ! empty( $bg['parallax'] ) ? 'on' : 'off';
        }
        if ( ! empty( $def['padding'] ) )    $a['custom_padding']   = $def['padding'];
        if ( ! empty( $def['min_height'] ) ) $a['custom_height']    = $def['min_height'];
        if ( ! empty( $def['text_align'] ) ) $a['module_alignment'] = $def['text_align'];
        if ( ! empty( $def['css_class'] ) )  $a['module_class']     = $def['css_class'];
        if ( ! empty( $def['css_id'] ) )     $a['module_id']        = $def['css_id'];

        $inner = '';
        foreach ( $def['rows'] ?? [] as $row ) {
            $inner .= self::sc_row( $row );
        }

        return '[et_pb_section' . self::attrs( $a ) . ']' . $inner . '[/et_pb_section]';
    }

    private static function sc_row( array $def ): string {
        $a = [ '_builder_version' => self::SC_VERSION ];

        if ( ! empty( $def['max_width'] ) ) $a['max_width'] = $def['max_width'];
        if ( ! empty( $def['width'] ) )     $a['width']     = $def['width'];
        if ( ! empty( $def['padding'] ) )   $a['custom_padding'] = $def['padding'];

        $columns  = $def['columns'] ?? [];
        $num_cols = count( $columns );
        $layout   = $def['layout'] ?? self::guess_layout( $num_cols );
        $col_types = self::parse_column_types( $layout, $num_cols );

        $inner = '';

        /* If no columns key but modules key given, wrap in single column */
        if ( empty( $columns ) && ! empty( $def['modules'] ) ) {
            $inner = self::sc_column( [ 'modules' => $def['modules'] ], '4_4' );
        } else {
            foreach ( $columns as $i => $col ) {
                $inner .= self::sc_column( $col, $col_types[ $i ] ?? '4_4' );
            }
        }

        return '[et_pb_row' . self::attrs( $a ) . ']' . $inner . '[/et_pb_row]';
    }

    private static function sc_column( array $def, string $type ): string {
        $a = [
            'type'             => $type,
            '_builder_version' => self::SC_VERSION,
        ];

        $bg = $def['background'] ?? [];
        if ( ! empty( $bg['color'] ) ) $a['background_color'] = $bg['color'];
        if ( ! empty( $def['padding'] ) ) $a['custom_padding'] = $def['padding'];

        $inner = '';
        foreach ( $def['modules'] ?? [] as $mod ) {
            $inner .= self::sc_module( $mod );
        }

        return '[et_pb_column' . self::attrs( $a ) . ']' . $inner . '[/et_pb_column]';
    }

    private static function sc_module( array $def ): string {
        $type = sanitize_key( $def['type'] ?? 'et_pb_text' );
        $s    = $def['settings'] ?? [];
        $v    = self::SC_VERSION;

        switch ( $type ) {

            case 'et_pb_text':
                $a = [ '_builder_version' => $v ];
                if ( ! empty( $s['text_color'] ) )       $a['text_text_color']   = $s['text_color'];
                if ( ! empty( $s['font_size'] ) )        $a['text_font_size']    = $s['font_size'];
                if ( ! empty( $s['text_align'] ) )       $a['text_orientation']  = $s['text_align'];
                if ( ! empty( $s['background_color'] ) ) $a['background_color']  = $s['background_color'];
                if ( ! empty( $s['padding'] ) )          $a['custom_padding']    = $s['padding'];
                if ( ! empty( $s['css_class'] ) )        $a['module_class']      = $s['css_class'];
                return '[et_pb_text' . self::attrs( $a ) . ']' . wp_kses_post( $s['content'] ?? '' ) . '[/et_pb_text]';

            case 'et_pb_image':
                $a = [
                    'src'              => $s['url'] ?? '',
                    '_builder_version' => $v,
                    'align'            => $s['align'] ?? 'center',
                ];
                if ( ! empty( $s['alt'] ) )       $a['alt']       = $s['alt'];
                if ( ! empty( $s['title'] ) )      $a['title_text']= $s['title'];
                if ( ! empty( $s['link'] ) )       $a['url']       = $s['link'];
                if ( ! empty( $s['max_width'] ) )  $a['max_width'] = $s['max_width'];
                if ( ! empty( $s['css_class'] ) )  $a['module_class'] = $s['css_class'];
                return '[et_pb_image' . self::attrs( $a ) . ' /]';

            case 'et_pb_button':
                $a = [
                    'button_url'       => $s['url']   ?? '#',
                    'button_text'      => $s['text']  ?? 'Click Here',
                    '_builder_version' => $v,
                    'button_alignment' => $s['align'] ?? 'center',
                ];
                if ( ! empty( $s['new_tab'] ) )    $a['url_new_window']   = 'on';
                if ( ! empty( $s['bg_color'] ) ) {
                    $a['custom_button']  = 'on';
                    $a['button_bg_color']= $s['bg_color'];
                }
                if ( ! empty( $s['text_color'] ) ) $a['button_text_color'] = $s['text_color'];
                if ( ! empty( $s['font_size'] ) )  $a['button_font_size']  = $s['font_size'];
                if ( ! empty( $s['css_class'] ) )  $a['module_class']      = $s['css_class'];
                return '[et_pb_button' . self::attrs( $a ) . ' /]';

            case 'et_pb_blurb':
                $a = [
                    'title'            => $s['title'] ?? '',
                    '_builder_version' => $v,
                ];
                if ( ! empty( $s['icon'] ) ) {
                    $a['use_icon']   = 'on';
                    $a['font_icon']  = $s['icon'];
                    $a['icon_color'] = $s['icon_color'] ?? '#7EBEC5';
                }
                if ( ! empty( $s['image_url'] ) ) {
                    $a['use_icon'] = 'off';
                    $a['image']    = $s['image_url'];
                }
                if ( ! empty( $s['icon_placement'] ) ) $a['icon_placement']    = $s['icon_placement'];
                if ( ! empty( $s['url'] ) )             $a['url']               = $s['url'];
                if ( ! empty( $s['title_color'] ) )     $a['header_text_color'] = $s['title_color'];
                if ( ! empty( $s['body_color'] ) )      $a['body_text_color']   = $s['body_color'];
                if ( ! empty( $s['text_align'] ) )      $a['text_orientation']  = $s['text_align'];
                if ( ! empty( $s['css_class'] ) )       $a['module_class']      = $s['css_class'];
                return '[et_pb_blurb' . self::attrs( $a ) . ']' . wp_kses_post( $s['content'] ?? $s['description'] ?? '' ) . '[/et_pb_blurb]';

            case 'et_pb_cta':
                $a = [
                    'title'            => $s['title']       ?? '',
                    'button_url'       => $s['button_url']  ?? '#',
                    'button_text'      => $s['button_text'] ?? 'Click Here',
                    '_builder_version' => $v,
                    'text_orientation' => $s['text_align']  ?? 'center',
                ];
                if ( ! empty( $s['background_color'] ) ) $a['background_color']= $s['background_color'];
                if ( ! empty( $s['title_color'] ) )      $a['title_font_color'] = $s['title_color'];
                if ( ! empty( $s['body_color'] ) )       $a['body_font_color']  = $s['body_color'];
                if ( ! empty( $s['css_class'] ) )        $a['module_class']     = $s['css_class'];
                return '[et_pb_cta' . self::attrs( $a ) . ']' . wp_kses_post( $s['content'] ?? $s['description'] ?? '' ) . '[/et_pb_cta]';

            case 'et_pb_divider':
                $a = [
                    '_builder_version' => $v,
                    'color'            => $s['color']  ?? '#cccccc',
                    'divider_height'   => $s['height'] ?? '2px',
                    'divider_style'    => $s['style']  ?? 'solid',
                ];
                return '[et_pb_divider' . self::attrs( $a ) . ' /]';

            case 'et_pb_space':
            case 'et_pb_spacer':
                $a = [
                    '_builder_version' => $v,
                    'height'           => $s['height'] ?? '50px',
                    'enable_mobile'    => 'on',
                    'visibility'       => 'on',
                ];
                return '[et_pb_space' . self::attrs( $a ) . ' /]';

            case 'et_pb_number_counter':
                $a = [
                    'title'            => $s['title']  ?? '',
                    'number'           => $s['number'] ?? '100',
                    '_builder_version' => $v,
                    'percent_sign'     => ! empty( $s['percent'] ) ? 'on' : 'off',
                ];
                if ( ! empty( $s['color'] ) )       $a['counter_color']  = $s['color'];
                if ( ! empty( $s['suffix'] ) )       $a['number_suffix']  = $s['suffix'];
                if ( ! empty( $s['title_color'] ) )  $a['title_text_color']= $s['title_color'];
                return '[et_pb_number_counter' . self::attrs( $a ) . ' /]';

            case 'et_pb_testimonial':
                $a = [
                    'author'           => $s['name']    ?? '',
                    'job_title'        => $s['title']   ?? '',
                    'company_name'     => $s['company'] ?? '',
                    '_builder_version' => $v,
                    'text_orientation' => $s['align']   ?? 'left',
                ];
                if ( ! empty( $s['image_url'] ) ) $a['portrait_url'] = $s['image_url'];
                if ( ! empty( $s['url'] ) )        $a['url']          = $s['url'];
                return '[et_pb_testimonial' . self::attrs( $a ) . ']' . wp_kses_post( $s['content'] ?? $s['quote'] ?? '' ) . '[/et_pb_testimonial]';

            case 'et_pb_accordion':
                $inner = '';
                foreach ( $s['items'] ?? [] as $item ) {
                    $ia = [ 'title' => sanitize_text_field( $item['title'] ?? '' ), '_builder_version' => $v ];
                    $inner .= '[et_pb_accordion_item' . self::attrs( $ia ) . ']' . wp_kses_post( $item['content'] ?? '' ) . '[/et_pb_accordion_item]';
                }
                return '[et_pb_accordion' . self::attrs( [ '_builder_version' => $v ] ) . ']' . $inner . '[/et_pb_accordion]';

            case 'et_pb_tabs':
                $inner = '';
                foreach ( $s['items'] ?? [] as $item ) {
                    $ta = [ 'title' => sanitize_text_field( $item['title'] ?? '' ), '_builder_version' => $v ];
                    $inner .= '[et_pb_tab' . self::attrs( $ta ) . ']' . wp_kses_post( $item['content'] ?? '' ) . '[/et_pb_tab]';
                }
                return '[et_pb_tabs' . self::attrs( [ '_builder_version' => $v ] ) . ']' . $inner . '[/et_pb_tabs]';

            case 'et_pb_toggle':
                $a = [
                    'title'            => $s['title']  ?? '',
                    '_builder_version' => $v,
                    'open'             => ! empty( $s['open'] ) ? 'on' : 'off',
                ];
                return '[et_pb_toggle' . self::attrs( $a ) . ']' . wp_kses_post( $s['content'] ?? '' ) . '[/et_pb_toggle]';

            case 'et_pb_video':
                $a = [
                    'src'              => $s['url']  ?? '',
                    '_builder_version' => $v,
                ];
                if ( ! empty( $s['image_src'] ) ) $a['image_src'] = $s['image_src'];
                return '[et_pb_video' . self::attrs( $a ) . ' /]';

            case 'et_pb_gallery':
                $a = [
                    '_builder_version'       => $v,
                    'gallery_ids'            => implode( ',', array_map( 'intval', $s['ids'] ?? [] ) ),
                    'posts_number'           => intval( $s['count']   ?? 4 ),
                    'columns_number'         => intval( $s['columns'] ?? 4 ),
                    'show_title_and_caption' => ! empty( $s['captions'] ) ? 'on' : 'off',
                ];
                return '[et_pb_gallery' . self::attrs( $a ) . ' /]';

            case 'et_pb_countdown_timer':
                $a = [
                    'title'            => $s['title'] ?? '',
                    'date_time'        => $s['date']  ?? '2099-01-01 00:00:00',
                    '_builder_version' => $v,
                ];
                return '[et_pb_countdown_timer' . self::attrs( $a ) . ' /]';

            case 'et_pb_blog':
                $a = [
                    '_builder_version' => $v,
                    'posts_number'     => intval( $s['count']   ?? 3 ),
                    'fullwidth'        => ! empty( $s['fullwidth'] ) ? 'on' : 'off',
                    'show_author'      => $s['show_author']  ?? 'on',
                    'show_date'        => $s['show_date']    ?? 'on',
                    'show_excerpt'     => $s['show_excerpt'] ?? 'on',
                    'columns_number'   => intval( $s['columns'] ?? 3 ),
                ];
                if ( ! empty( $s['category'] ) ) $a['include_categories'] = $s['category'];
                return '[et_pb_blog' . self::attrs( $a ) . ' /]';

            case 'et_pb_contact_form':
                $fields_sc = '';
                foreach ( $s['fields'] ?? [] as $field ) {
                    $fa = [
                        'field_title'      => $field['label'] ?? 'Field',
                        'field_type'       => $field['type']  ?? 'input',
                        'required_mark'    => ! empty( $field['required'] ) ? 'on' : 'off',
                        '_builder_version' => $v,
                    ];
                    $fields_sc .= '[et_pb_contact_field' . self::attrs( $fa ) . ' /]';
                }
                $a = [
                    'title'              => $s['title']   ?? '',
                    '_builder_version'   => $v,
                    'captcha'            => ! empty( $s['captcha'] ) ? 'on' : 'off',
                    'submit_button_text' => $s['submit']   ?? 'Send',
                    'email'              => $s['email_to'] ?? get_option( 'admin_email' ),
                ];
                return '[et_pb_contact_form' . self::attrs( $a ) . ']' . $fields_sc . '[/et_pb_contact_form]';

            case 'et_pb_pricing_tables':
                $tables_sc = '';
                foreach ( $s['tables'] ?? [] as $tbl ) {
                    $bullet = '';
                    foreach ( $tbl['features'] ?? [] as $feat ) {
                        $text    = is_array( $feat ) ? ( $feat['text'] ?? '' ) : $feat;
                        $bullet .= '<li>' . esc_html( $text ) . '</li>';
                    }
                    $ta = [
                        'title'            => $tbl['title']       ?? '',
                        'subtitle'         => $tbl['subtitle']    ?? '',
                        'currency'         => $tbl['currency']    ?? '$',
                        'per'              => $tbl['period']      ?? '',
                        'price'            => $tbl['price']       ?? '',
                        'sum'              => $tbl['price']       ?? '',
                        'button_url'       => $tbl['button_url']  ?? '#',
                        'button_text'      => $tbl['button_text'] ?? 'Get Started',
                        'featured'         => ! empty( $tbl['featured'] ) ? 'on' : 'off',
                        '_builder_version' => $v,
                    ];
                    $tables_sc .= '[et_pb_pricing_table' . self::attrs( $ta ) . ']<ul>' . $bullet . '</ul>[/et_pb_pricing_table]';
                }
                return '[et_pb_pricing_tables' . self::attrs( [ '_builder_version' => $v ] ) . ']' . $tables_sc . '[/et_pb_pricing_tables]';

            case 'et_pb_social_media_follow':
                $nets_sc = '';
                foreach ( $s['networks'] ?? [] as $net ) {
                    $na = [
                        'social_network'   => $net['network'] ?? 'facebook',
                        'url'              => $net['url']     ?? '#',
                        '_builder_version' => $v,
                    ];
                    $nets_sc .= '[et_pb_social_media_follow_network' . self::attrs( $na ) . ']' . ucfirst( $net['network'] ?? 'facebook' ) . '[/et_pb_social_media_follow_network]';
                }
                $a = [
                    '_builder_version' => $v,
                    'link_shape'       => $s['shape']       ?? 'rounded_rectangle',
                    'follow_button'    => $s['show_follow'] ?? 'off',
                ];
                if ( ! empty( $s['icon_color'] ) ) $a['icon_color'] = $s['icon_color'];
                return '[et_pb_social_media_follow' . self::attrs( $a ) . ']' . $nets_sc . '[/et_pb_social_media_follow]';

            case 'et_pb_code':
                $a = [ '_builder_version' => $v ];
                return '[et_pb_code' . self::attrs( $a ) . ']' . wp_kses_post( $s['code'] ?? $s['content'] ?? '' ) . '[/et_pb_code]';

            case 'et_pb_search':
                $a = [
                    '_builder_version'   => $v,
                    'placeholder'        => $s['placeholder'] ?? 'Search…',
                    'button_color'       => $s['button_color'] ?? '',
                    'hide_button'        => ! empty( $s['hide_button'] ) ? 'on' : 'off',
                ];
                return '[et_pb_search' . self::attrs( $a ) . ' /]';

            case 'et_pb_menu':
                $a = [
                    '_builder_version' => $v,
                    'menu_id'          => intval( $s['menu_id'] ?? 0 ),
                ];
                return '[et_pb_menu' . self::attrs( $a ) . ' /]';

            default:
                /* Pass-through for third-party Divi modules — type must follow et_pb_* convention. */
                if ( ! preg_match( '/^et_pb_[a-z0-9_]+$/', $type ) ) {
                    throw new \InvalidArgumentException( "Invalid or unsupported module type: {$type}" );
                }
                $a       = array_merge( [ '_builder_version' => $v ], $s );
                $content = '';
                if ( isset( $a['content'] ) ) { $content = wp_kses_post( $a['content'] ); unset( $a['content'] ); }
                return '[' . $type . self::attrs( $a ) . ']' . $content . '[/' . $type . ']';
        }
    }

    /* ════════════════════════════════════════════════════════
     *  Private helpers
     * ════════════════════════════════════════════════════════ */

    /**
     * Render an attribute list suitable for Divi shortcodes.
     * Skips null / empty-string values. Boolean true → "on", false → "off".
     */
    private static function attrs( array $a ): string {
        $out = '';
        foreach ( $a as $k => $v ) {
            if ( $v === null || $v === '' ) continue;
            if ( is_bool( $v ) ) {
                $v = $v ? 'on' : 'off';
            } else {
                $v = (string) $v;
            }
            $out .= ' ' . $k . '="' . str_replace( '"', '&quot;', $v ) . '"';
        }
        return $out;
    }

    private static function guess_layout( int $num ): string {
        switch ( $num ) {
            case 2:  return '1_2 1_2';
            case 3:  return '1_3 1_3 1_3';
            case 4:  return '1_4 1_4 1_4 1_4';
            default: return '4_4';
        }
    }

    private static function parse_column_types( string $layout, int $num ): array {
        $parts = explode( ' ', trim( $layout ) );
        while ( count( $parts ) < $num ) {
            $parts[] = end( $parts ) ?: '4_4';
        }
        return array_slice( $parts, 0, $num );
    }

    private static function is_divi_5(): bool {
        return defined( 'ET_BUILDER_PRODUCT_VERSION' )
               && version_compare( ET_BUILDER_PRODUCT_VERSION, '5.0', '>=' );
    }

    private static function clear_divi_cache( ?int $post_id = null ): void {
        wp_cache_flush();

        if ( class_exists( 'ET_Core_PageResource' ) ) {
            ET_Core_PageResource::remove_static_resources( 'all', 'all' );
        } else {
            /* Bump version so Divi regenerates static CSS */
            update_option( 'et_dynamic_assets_version', intval( get_option( 'et_dynamic_assets_version', 0 ) ) + 1 );
            delete_transient( 'et_dynamic_assets_version' );
        }

        delete_transient( 'et_builder_module_cache' );
        delete_transient( 'et_pb_extra_modules' );

        if ( $post_id ) {
            clean_post_cache( $post_id );
        }
    }

    /* ════════════════════════════════════════════════════════
     *  Module catalog
     * ════════════════════════════════════════════════════════ */

    private static function module_catalog(): array {
        return [
            /* Basic */
            [ 'name' => 'et_pb_text',               'title' => 'Text',                  'group' => 'basic',     'has_content' => true  ],
            [ 'name' => 'et_pb_image',              'title' => 'Image',                 'group' => 'basic',     'has_content' => false ],
            [ 'name' => 'et_pb_button',             'title' => 'Button',                'group' => 'basic',     'has_content' => false ],
            [ 'name' => 'et_pb_divider',            'title' => 'Divider',               'group' => 'basic',     'has_content' => false ],
            [ 'name' => 'et_pb_space',              'title' => 'Spacer',                'group' => 'basic',     'has_content' => false ],
            [ 'name' => 'et_pb_code',               'title' => 'Code',                  'group' => 'basic',     'has_content' => true  ],
            /* Content */
            [ 'name' => 'et_pb_blurb',              'title' => 'Blurb (icon+text)',     'group' => 'content',   'has_content' => true  ],
            [ 'name' => 'et_pb_cta',                'title' => 'Call To Action',        'group' => 'content',   'has_content' => true  ],
            [ 'name' => 'et_pb_testimonial',        'title' => 'Testimonial',           'group' => 'content',   'has_content' => true  ],
            [ 'name' => 'et_pb_pricing_tables',     'title' => 'Pricing Tables',        'group' => 'content',   'has_content' => true  ],
            [ 'name' => 'et_pb_number_counter',     'title' => 'Number Counter',        'group' => 'content',   'has_content' => false ],
            [ 'name' => 'et_pb_bar_counters',       'title' => 'Bar Counters',          'group' => 'content',   'has_content' => true  ],
            [ 'name' => 'et_pb_countdown_timer',    'title' => 'Countdown Timer',       'group' => 'content',   'has_content' => false ],
            [ 'name' => 'et_pb_accordion',          'title' => 'Accordion',             'group' => 'content',   'has_content' => true  ],
            [ 'name' => 'et_pb_tabs',               'title' => 'Tabs',                  'group' => 'content',   'has_content' => true  ],
            [ 'name' => 'et_pb_toggle',             'title' => 'Toggle',                'group' => 'content',   'has_content' => true  ],
            /* Media */
            [ 'name' => 'et_pb_video',              'title' => 'Video',                 'group' => 'media',     'has_content' => false ],
            [ 'name' => 'et_pb_gallery',            'title' => 'Gallery',               'group' => 'media',     'has_content' => false ],
            [ 'name' => 'et_pb_slider',             'title' => 'Slider',                'group' => 'media',     'has_content' => true  ],
            [ 'name' => 'et_pb_video_slider',       'title' => 'Video Slider',          'group' => 'media',     'has_content' => true  ],
            /* Social */
            [ 'name' => 'et_pb_social_media_follow','title' => 'Social Media Follow',   'group' => 'social',    'has_content' => true  ],
            [ 'name' => 'et_pb_login',              'title' => 'Login',                 'group' => 'social',    'has_content' => false ],
            /* WordPress */
            [ 'name' => 'et_pb_blog',               'title' => 'Blog',                  'group' => 'wordpress', 'has_content' => false ],
            [ 'name' => 'et_pb_posts_slider',       'title' => 'Posts Slider',          'group' => 'wordpress', 'has_content' => false ],
            [ 'name' => 'et_pb_contact_form',       'title' => 'Contact Form',          'group' => 'wordpress', 'has_content' => true  ],
            [ 'name' => 'et_pb_search',             'title' => 'Search',                'group' => 'wordpress', 'has_content' => false ],
            [ 'name' => 'et_pb_menu',               'title' => 'Menu',                  'group' => 'wordpress', 'has_content' => false ],
            [ 'name' => 'et_pb_sidebar',            'title' => 'Sidebar',               'group' => 'wordpress', 'has_content' => false ],
            /* Structure (for reference) */
            [ 'name' => 'et_pb_section',            'title' => 'Section',               'group' => 'structure', 'has_content' => true  ],
            [ 'name' => 'et_pb_row',                'title' => 'Row',                   'group' => 'structure', 'has_content' => true  ],
            [ 'name' => 'et_pb_column',             'title' => 'Column',                'group' => 'structure', 'has_content' => true  ],
        ];
    }
}
