<?php
class CWPM_Plugins {

    /* ── List all plugins ────────────────────────────────── */
    public static function list_plugins( array $p ): array {
        if ( ! function_exists( 'get_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $all    = get_plugins();
        $active = get_option( 'active_plugins', [] );
        $result = [];

        foreach ( $all as $path => $data ) {
            $result[] = [
                'file'        => $path,
                'slug'        => dirname( $path ),
                'name'        => $data['Name'],
                'version'     => $data['Version'],
                'author'      => $data['Author'],
                'description' => $data['Description'],
                'active'      => in_array( $path, $active ),
            ];
        }

        if ( ! empty( $p['active_only'] ) ) {
            $result = array_filter( $result, fn($r) => $r['active'] );
        }

        return [ 'plugins' => array_values( $result ) ];
    }

    /* ── Activate ────────────────────────────────────────── */
    public static function activate_plugin( array $p ): array {
        if ( ! function_exists( 'activate_plugin' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $slug   = sanitize_key( $p['slug'] ?? '' );
        $plugin = $p['plugin_file'] ?? ( $slug ? "{$slug}/{$slug}.php" : '' );
        if ( ! $plugin ) throw new Exception( 'plugin_file or slug required.' );

        // Prevent path traversal: plugin_file must resolve inside WP_PLUGIN_DIR.
        $plugin = self::validate_plugin_path( $plugin );

        $result = activate_plugin( $plugin );
        if ( is_wp_error( $result ) ) throw new Exception( $result->get_error_message() );
        CWPM_Logger::log( 'info', "Activated plugin: {$plugin}" );
        return [ 'activated' => $plugin ];
    }

    /* ── Deactivate ──────────────────────────────────────── */
    public static function deactivate_plugin( array $p ): array {
        if ( ! function_exists( 'deactivate_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $slug   = sanitize_key( $p['slug'] ?? '' );
        $plugin = $p['plugin_file'] ?? ( $slug ? "{$slug}/{$slug}.php" : '' );
        if ( ! $plugin ) throw new Exception( 'plugin_file or slug required.' );

        $plugin = self::validate_plugin_path( $plugin );

        deactivate_plugins( $plugin );
        CWPM_Logger::log( 'warn', "Deactivated plugin: {$plugin}" );
        return [ 'deactivated' => $plugin ];
    }

    /* ── Install from wordpress.org ──────────────────────── */
    public static function install_plugin( array $p ): array {
        $slug = sanitize_key( $p['slug'] ?? '' );
        if ( ! $slug ) throw new Exception( 'slug required.' );

        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';

        $api = plugins_api( 'plugin_information', [ 'slug' => $slug ] );
        if ( is_wp_error( $api ) ) throw new Exception( "Plugin '{$slug}' not found on WordPress.org." );

        $skin     = new WP_Ajax_Upgrader_Skin();
        $upgrader = new Plugin_Upgrader( $skin );
        $result   = $upgrader->install( $api->download_link );

        if ( is_wp_error( $result ) ) throw new Exception( $result->get_error_message() );

        CWPM_Logger::log( 'info', "Installed plugin: {$slug}" );
        return [ 'installed' => $slug, 'version' => $api->version ];
    }

    /* ── Get plugin settings (from wp_options) ───────────── */
    public static function get_settings( array $p ): array {
        $keys   = $p['option_keys'] ?? [];
        $result = [];
        foreach ( (array) $keys as $key ) {
            $result[ $key ] = get_option( sanitize_key( $key ) );
        }
        return $result;
    }

    /* ── Set plugin settings ─────────────────────────────── */
    public static function set_settings( array $p ): array {
        $settings = $p['settings'] ?? [];
        $updated  = [];
        // Reuse the same blocklist as CWPM_Theme::set_option to prevent privilege escalation.
        $blocked = CWPM_Theme::BLOCKED_OPTIONS;
        foreach ( $settings as $key => $value ) {
            $key = sanitize_key( $key );
            if ( in_array( $key, $blocked, true ) ) {
                CWPM_Logger::log( 'warn', "Blocked attempt to set protected option: {$key}" );
                continue;
            }
            update_option( $key, $value );
            $updated[] = $key;
        }
        CWPM_Logger::log( 'info', 'Updated options: ' . implode( ', ', $updated ) );
        return [ 'updated' => $updated ];
    }

    /* ── Helpers ─────────────────────────────────────────── */

    /**
     * Ensure a plugin file path cannot escape the plugins directory (path traversal guard).
     */
    private static function validate_plugin_path( string $plugin_file ): string {
        // Normalise separators and strip leading slashes.
        $plugin_file = ltrim( str_replace( '\\', '/', $plugin_file ), '/' );

        // Must be relative (no absolute path) and end in .php
        if ( strpos( $plugin_file, '/' ) === false ) {
            throw new Exception( 'plugin_file must be in the format slug/slug.php.' );
        }
        if ( substr( $plugin_file, -4 ) !== '.php' ) { // PHP 7.4-safe (avoids str_ends_with)
            throw new Exception( 'plugin_file must end in .php.' );
        }

        $plugin_dir  = trailingslashit( wp_normalize_path( WP_PLUGIN_DIR ) );
        $resolved    = wp_normalize_path( $plugin_dir . $plugin_file );

        // Prevent path traversal (e.g. ../../wp-config.php).
        if ( strpos( $resolved, $plugin_dir ) !== 0 ) {
            throw new Exception( 'plugin_file path is outside the plugins directory.' );
        }

        return $plugin_file;
    }
}
