<?php
/**
 * Elementor Handler
 * Build pages using real Elementor widgets — NO HTML widget fallback.
 */
class CWPM_Elementor {

    /* ── Get Elementor data ──────────────────────────────── */
    public static function get_data( array $p ): array {
        $post_id = intval( $p['post_id'] ?? 0 );
        if ( ! $post_id ) throw new Exception( 'post_id required.' );

        $raw = get_post_meta( $post_id, '_elementor_data', true );
        $ver = get_post_meta( $post_id, '_elementor_version', true );
        $css = get_post_meta( $post_id, '_elementor_css', true );

        return [
            'post_id'         => $post_id,
            'elementor_data'  => $raw ? json_decode( $raw, true ) : [],
            'version'         => $ver,
            'has_css_cache'   => ! empty( $css ),
        ];
    }

    /* ── Set (replace) Elementor data ────────────────────── */
    public static function set_data( array $p ): array {
        $post_id = intval( $p['post_id'] ?? 0 );
        $data    = $p['data'] ?? [];
        if ( ! $post_id ) throw new Exception( 'post_id required.' );

        $json = wp_json_encode( $data );
        update_post_meta( $post_id, '_elementor_data', wp_slash( $json ) );
        update_post_meta( $post_id, '_elementor_edit_mode', 'builder' );

        // Flush Elementor CSS cache
        delete_post_meta( $post_id, '_elementor_css' );

        if ( class_exists( '\Elementor\Plugin' ) ) {
            \Elementor\Plugin::$instance->files_manager->clear_cache();
        }

        CWPM_Logger::log( 'info', "Set Elementor data on post #{$post_id}" );
        return [ 'post_id' => $post_id, 'saved' => true ];
    }

    /* ── Build page from template description ─────────────
     *
     * Accepts a structured array of sections with native Elementor
     * widgets. No HTML widget used — everything maps to real widgets.
     *
     * Example params:
     * {
     *   "post_id": 42,
     *   "sections": [
     *     {
     *       "layout": "full",
     *       "background": {"color": "#1a1a2e"},
     *       "columns": [
     *         {
     *           "width": 100,
     *           "widgets": [
     *             {
     *               "type": "heading",
     *               "settings": {
     *                 "title": "Hello World",
     *                 "header_size": "h1",
     *                 "align": "center",
     *                 "title_color": "#ffffff",
     *                 "typography_font_size": {"size": 72, "unit": "px"}
     *               }
     *             }
     *           ]
     *         }
     *       ]
     *     }
     *   ]
     * }
     */
    public static function build_page_from_template( array $p ): array {
        $post_id  = intval( $p['post_id'] ?? 0 );
        $sections = $p['sections'] ?? [];
        if ( ! $post_id ) throw new Exception( 'post_id required.' );
        if ( empty( $sections ) ) throw new Exception( 'sections array required.' );

        $el_data = [];

        foreach ( $sections as $section_def ) {
            $el_data[] = self::build_section( $section_def );
        }

        $json = wp_json_encode( $el_data );
        update_post_meta( $post_id, '_elementor_data', wp_slash( $json ) );
        update_post_meta( $post_id, '_elementor_edit_mode', 'builder' );
        delete_post_meta( $post_id, '_elementor_css' );

        if ( class_exists( '\Elementor\Plugin' ) ) {
            \Elementor\Plugin::$instance->files_manager->clear_cache();
        }

        CWPM_Logger::log( 'info', "Built Elementor page on post #{$post_id} with " . count( $sections ) . " sections." );
        return [ 'post_id' => $post_id, 'sections' => count( $sections ), 'url' => get_permalink( $post_id ) ];
    }

    /* ── List registered widgets ─────────────────────────── */
    public static function list_widgets( array $p ): array {
        if ( ! class_exists( '\Elementor\Plugin' ) ) {
            // Return known widget catalog even without Elementor loaded
            return [ 'widgets' => self::widget_catalog() ];
        }

        $widgets = \Elementor\Plugin::$instance->widgets_manager->get_widget_types();
        $list    = [];
        foreach ( $widgets as $name => $widget ) {
            $list[] = [
                'name'     => $name,
                'title'    => $widget->get_title(),
                'category' => $widget->get_categories(),
            ];
        }
        return [ 'widgets' => $list ];
    }

    /* ── Global colors / fonts ───────────────────────────── */
    public static function get_globals( array $p ): array {
        $colors = get_option( 'elementor_scheme_color', [] );
        $fonts  = get_option( 'elementor_scheme_typography', [] );
        $kit_id = get_option( 'elementor_active_kit', 0 );
        $kit_settings = $kit_id ? get_post_meta( $kit_id, '_elementor_page_settings', true ) : '';

        return [
            'kit_id'       => $kit_id,
            'kit_settings' => $kit_settings ? json_decode( $kit_settings, true ) : [],
            'colors'       => $colors,
            'fonts'        => $fonts,
        ];
    }

    public static function set_globals( array $p ): array {
        $kit_id = intval( get_option( 'elementor_active_kit', 0 ) );
        if ( ! $kit_id ) throw new Exception( 'No active Elementor kit found.' );

        $settings = get_post_meta( $kit_id, '_elementor_page_settings', true );
        $settings = $settings ? json_decode( $settings, true ) : [];

        if ( ! empty( $p['system_colors'] ) ) {
            $settings['system_colors'] = $p['system_colors'];
        }
        if ( ! empty( $p['system_typography'] ) ) {
            $settings['system_typography'] = $p['system_typography'];
        }
        if ( ! empty( $p['custom_colors'] ) ) {
            $settings['custom_colors'] = $p['custom_colors'];
        }

        update_post_meta( $kit_id, '_elementor_page_settings', wp_slash( wp_json_encode( $settings ) ) );
        delete_post_meta( $kit_id, '_elementor_css' );

        if ( class_exists( '\Elementor\Plugin' ) ) {
            \Elementor\Plugin::$instance->files_manager->clear_cache();
        }

        CWPM_Logger::log( 'info', 'Updated Elementor global kit settings.' );
        return [ 'kit_id' => $kit_id, 'updated' => true ];
    }

    /* ══════════════════════════════════════════════════════
     *  Builder helpers
     * ══════════════════════════════════════════════════════ */

    private static function uid(): string {
        return substr( md5( uniqid( '', true ) ), 0, 8 );
    }

    private static function build_section( array $def ): array {
        $columns = [];
        foreach ( $def['columns'] ?? [] as $col ) {
            $columns[] = self::build_column( $col );
        }

        $section_settings = array_merge( [
            'layout' => $def['layout'] ?? 'full_width',
        ], self::extract_background( $def['background'] ?? [] ),
           self::extract_spacing( $def['padding'] ?? null, 'padding' ),
           self::extract_spacing( $def['margin'] ?? null, 'margin' ) );

        // Responsive settings
        if ( ! empty( $def['min_height'] ) ) {
            $section_settings['stretch_section'] = 'section-stretched';
        }

        return [
            'id'       => self::uid(),
            'elType'   => 'section',
            'settings' => $section_settings,
            'elements' => $columns,
            'isInner'  => false,
        ];
    }

    private static function build_column( array $def ): array {
        $widgets = [];
        foreach ( $def['widgets'] ?? [] as $w ) {
            $widgets[] = self::build_widget( $w );
        }

        $settings = [
            '_column_size' => intval( $def['width'] ?? 100 ),
            '_inline_size' => intval( $def['width'] ?? 100 ),
        ];

        return [
            'id'       => self::uid(),
            'elType'   => 'column',
            'settings' => $settings,
            'elements' => $widgets,
        ];
    }

    private static function build_widget( array $def ): array {
        $type     = sanitize_key( $def['type'] ?? 'text-editor' );
        $settings = self::normalize_widget_settings( $type, $def['settings'] ?? [] );

        return [
            'id'         => self::uid(),
            'elType'     => 'widget',
            'widgetType' => $type,
            'settings'   => $settings,
            'elements'   => [],
        ];
    }

    /**
     * Map human-friendly settings to Elementor control keys.
     * Supports: heading, text-editor, image, button, icon-box,
     *   image-box, counter, progress, testimonial, divider,
     *   spacer, video, google_maps, icon, social-icons,
     *   accordion, toggle, tabs, carousel, image-gallery,
     *   posts, nav-menu, search-form, shortcode, sidebar,
     *   html (last resort only), text, alert, icon-list,
     *   call-to-action, price-table, countdown, login, form
     */
    private static function normalize_widget_settings( string $type, array $s ): array {
        switch ( $type ) {

            case 'heading':
                return array_merge( [
                    'title'       => $s['title'] ?? 'Heading',
                    'header_size' => $s['header_size'] ?? 'h2',
                    'align'       => $s['align'] ?? 'left',
                ], self::maybe_color( 'title_color', $s ),
                   self::maybe_typography( $s ) );

            case 'text-editor':
                return [
                    'editor'   => wp_kses_post( $s['content'] ?? $s['editor'] ?? '' ),
                    'drop_cap' => $s['drop_cap'] ?? '',
                ];

            case 'button':
                return array_merge( [
                    'text'         => $s['text'] ?? 'Click Here',
                    'link'         => [ 'url' => $s['url'] ?? '#', 'is_external' => $s['new_tab'] ?? '' ],
                    'align'        => $s['align'] ?? 'left',
                    'size'         => $s['size'] ?? 'sm',
                    'button_type'  => $s['button_type'] ?? '',
                    'border_radius'=> $s['border_radius'] ?? [ 'unit' => 'px', 'top' => 3, 'right' => 3, 'bottom' => 3, 'left' => 3 ],
                ], self::maybe_color( 'button_text_color', $s ),
                   self::maybe_bg( $s ) );

            case 'image':
                return [
                    'image'     => [ 'url' => $s['url'] ?? '', 'id' => $s['id'] ?? '' ],
                    'image_size'=> $s['size'] ?? 'large',
                    'align'     => $s['align'] ?? '',
                    'caption'   => $s['caption'] ?? '',
                    'link_to'   => $s['link_to'] ?? 'none',
                ];

            case 'icon-box':
                return array_merge( [
                    'icon'           => [ 'value' => $s['icon'] ?? 'fa fa-star', 'library' => $s['icon_library'] ?? 'fa-solid' ],
                    'title_text'     => $s['title'] ?? '',
                    'description_text' => $s['description'] ?? '',
                    'view'           => $s['view'] ?? 'default',
                    'shape'          => $s['shape'] ?? 'circle',
                    'icon_size'      => [ 'unit' => 'px', 'size' => intval( $s['icon_size'] ?? 50 ) ],
                    'icon_color'     => $s['icon_color'] ?? '',
                    'icon_primary_color' => $s['icon_primary_color'] ?? '',
                    'icon_secondary_color' => $s['icon_secondary_color'] ?? '',
                    'position'       => $s['position'] ?? 'top',
                    'title_size'     => $s['title_size'] ?? 'h3',
                    'box_shadow_box_shadow_type' => ! empty( $s['shadow'] ) ? 'yes' : '',
                    'box_shadow_box_shadow' => ! empty( $s['shadow'] ) ? [
                        'horizontal' => $s['shadow']['h'] ?? 0,
                        'vertical'   => $s['shadow']['v'] ?? 5,
                        'blur'       => $s['shadow']['blur'] ?? 20,
                        'spread'     => $s['shadow']['spread'] ?? 0,
                        'color'      => $s['shadow']['color'] ?? 'rgba(0,0,0,0.15)',
                    ] : [],
                ], self::maybe_color( 'title_color', $s ),
                   self::maybe_color( 'description_color', $s ) );

            case 'image-box':
                return [
                    'image'      => [ 'url' => $s['image_url'] ?? '', 'id' => $s['image_id'] ?? '' ],
                    'image_size' => $s['image_size'] ?? 'thumbnail',
                    'title_text' => $s['title'] ?? '',
                    'description_text' => $s['description'] ?? '',
                    'position'   => $s['position'] ?? 'top',
                    'title_size' => $s['title_size'] ?? 'h3',
                ];

            case 'counter':
                return [
                    'starting_number' => intval( $s['from'] ?? 0 ),
                    'ending_number'   => intval( $s['to'] ?? 100 ),
                    'duration'        => intval( $s['duration'] ?? 2000 ),
                    'title'           => $s['title'] ?? '',
                    'prefix'          => $s['prefix'] ?? '',
                    'suffix'          => $s['suffix'] ?? '',
                ];

            case 'progress':
                return [
                    'title'    => $s['title'] ?? '',
                    'percent'  => [ 'unit' => '%', 'size' => intval( $s['percent'] ?? 50 ) ],
                    'bar_color'=> $s['color'] ?? '',
                    'display_percentage' => $s['show_percent'] ?? 'show',
                ];

            case 'testimonial':
                return [
                    'testimonial_content' => $s['content'] ?? '',
                    'testimonial_name'    => $s['name'] ?? '',
                    'testimonial_job'     => $s['title'] ?? '',
                    'testimonial_image'   => [ 'url' => $s['image_url'] ?? '' ],
                    'testimonial_alignment' => $s['align'] ?? 'center',
                ];

            case 'divider':
                return [
                    'style'  => $s['style'] ?? 'solid',
                    'weight' => [ 'unit' => 'px', 'size' => intval( $s['weight'] ?? 1 ) ],
                    'color'  => $s['color'] ?? '',
                    'gap'    => [ 'unit' => 'px', 'size' => intval( $s['gap'] ?? 15 ) ],
                    'look'   => $s['look'] ?? 'line',
                    'icon'   => ! empty( $s['icon'] ) ? [ 'value' => $s['icon'], 'library' => 'fa-solid' ] : [],
                ];

            case 'spacer':
                return [
                    'space' => [ 'unit' => 'px', 'size' => intval( $s['height'] ?? 50 ) ],
                ];

            case 'video':
                return [
                    'video_type'  => $s['type'] ?? 'youtube',
                    'youtube_url' => $s['url'] ?? '',
                    'vimeo_url'   => $s['vimeo_url'] ?? '',
                    'autoplay'    => $s['autoplay'] ?? '',
                    'mute'        => $s['mute'] ?? '',
                    'loop'        => $s['loop'] ?? '',
                    'controls'    => $s['controls'] ?? 'yes',
                ];

            case 'google_maps':
                return [
                    'address' => $s['address'] ?? '',
                    'zoom'    => [ 'unit' => 'px', 'size' => intval( $s['zoom'] ?? 10 ) ],
                    'height'  => [ 'unit' => 'px', 'size' => intval( $s['height'] ?? 300 ) ],
                ];

            case 'icon':
                return [
                    'icon'     => [ 'value' => $s['icon'] ?? 'fa fa-star', 'library' => 'fa-solid' ],
                    'view'     => $s['view'] ?? 'default',
                    'link'     => [ 'url' => $s['url'] ?? '' ],
                    'size'     => [ 'unit' => 'px', 'size' => intval( $s['size'] ?? 50 ) ],
                    'icon_color' => $s['color'] ?? '',
                ];

            case 'icon-list':
                $items = [];
                foreach ( $s['items'] ?? [] as $item ) {
                    $items[] = [
                        'text'     => $item['text'] ?? '',
                        'icon'     => [ 'value' => $item['icon'] ?? 'fa fa-check', 'library' => 'fa-solid' ],
                        'link'     => [ 'url' => $item['url'] ?? '' ],
                        'icon_color' => $item['color'] ?? '',
                    ];
                }
                return [
                    'icon_list' => $items,
                    'layout'    => $s['layout'] ?? 'traditional',
                    'space_between' => [ 'unit' => 'px', 'size' => intval( $s['spacing'] ?? 5 ) ],
                ];

            case 'accordion':
                $items = [];
                foreach ( $s['items'] ?? [] as $item ) {
                    $items[] = [
                        'tab_title'   => sanitize_text_field( $item['title'] ?? '' ),
                        'tab_content' => wp_kses_post( $item['content'] ?? '' ),
                    ];
                }
                return [ 'tabs' => $items, 'active_item' => intval( $s['active'] ?? 1 ) ];

            case 'tabs':
                $items = [];
                foreach ( $s['items'] ?? [] as $item ) {
                    $items[] = [
                        'tab_title'   => sanitize_text_field( $item['title'] ?? '' ),
                        'tab_content' => wp_kses_post( $item['content'] ?? '' ),
                    ];
                }
                return [ 'tabs' => $items, 'type' => $s['type'] ?? 'horizontal' ];

            case 'alert':
                return [
                    'alert_type'     => $s['type'] ?? 'info',
                    'alert_title'    => $s['title'] ?? 'Heads up!',
                    'alert_description' => $s['description'] ?? '',
                    'show_dismiss_button' => $s['dismissible'] ?? 'yes',
                ];

            case 'shortcode':
                // Only allow shortcode tags already registered in WordPress.
                $tag     = sanitize_key( strtok( trim( $s['shortcode'] ?? '' ), ' ' ) );
                $allowed = array_keys( $GLOBALS['shortcode_tags'] ?? [] );
                if ( $tag && ! in_array( $tag, $allowed, true ) ) {
                    throw new Exception( "Shortcode '[{$tag}]' is not registered on this site." );
                }
                return [ 'shortcode' => sanitize_text_field( $s['shortcode'] ?? '' ) ];

            case 'posts':
                return [
                    'posts_per_page'  => intval( $s['count'] ?? 3 ),
                    'post_type'       => $s['post_type'] ?? 'post',
                    'columns'         => intval( $s['columns'] ?? 3 ),
                    'show_thumbnail'  => $s['thumbnail'] ?? 'yes',
                    'show_excerpt'    => $s['excerpt'] ?? 'yes',
                    'meta_data'       => $s['meta'] ?? [ 'date', 'comments' ],
                    'orderby'         => $s['orderby'] ?? 'date',
                    'order'           => $s['order'] ?? 'DESC',
                ];

            case 'nav-menu':
                return [
                    'menu'   => intval( $s['menu_id'] ?? 0 ),
                    'layout' => $s['layout'] ?? 'horizontal',
                ];

            case 'search-form':
                return [
                    'skin'        => $s['skin'] ?? 'classic',
                    'placeholder' => $s['placeholder'] ?? 'Search...',
                    'button_type' => $s['button_type'] ?? 'icon',
                ];

            case 'call-to-action':
                return [
                    'title'          => $s['title'] ?? '',
                    'description'    => $s['description'] ?? '',
                    'button'         => $s['button_text'] ?? 'Click Here',
                    'link'           => [ 'url' => $s['url'] ?? '#' ],
                    'skin'           => $s['skin'] ?? 'classic',
                    'ribbon_title'   => $s['ribbon'] ?? '',
                ];

            case 'countdown':
                return [
                    'due_date'       => $s['date'] ?? '2099-01-01 00:00',
                    'show_days'      => $s['show_days'] ?? 'yes',
                    'show_hours'     => $s['show_hours'] ?? 'yes',
                    'show_minutes'   => $s['show_minutes'] ?? 'yes',
                    'show_seconds'   => $s['show_seconds'] ?? 'yes',
                    'expire_actions' => $s['on_expire'] ?? '',
                ];

            case 'price-table':
                $features = [];
                foreach ( $s['features'] ?? [] as $f ) {
                    $features[] = [ 'item_text' => $f['text'] ?? $f, 'item_icon' => [ 'value' => $f['icon'] ?? 'fa fa-check', 'library' => 'fa-solid' ] ];
                }
                return [
                    'heading'          => $s['title'] ?? '',
                    'sub_heading'      => $s['subtitle'] ?? '',
                    'price'            => $s['price'] ?? '',
                    'period'           => $s['period'] ?? '',
                    'features_list'    => $features,
                    'button_text'      => $s['button'] ?? 'Get Started',
                    'button_url'       => [ 'url' => $s['url'] ?? '#' ],
                    'highlighted'      => $s['featured'] ?? '',
                    'ribbon_title'     => $s['ribbon'] ?? '',
                ];

            case 'form':
                $fields = [];
                foreach ( $s['fields'] ?? [] as $field ) {
                    $fields[] = [
                        'field_type'     => $field['type'] ?? 'text',
                        'field_label'    => $field['label'] ?? '',
                        'placeholder'    => $field['placeholder'] ?? '',
                        'required'       => $field['required'] ?? '',
                        'width'          => $field['width'] ?? '100',
                    ];
                }
                return [
                    'form_name'      => $s['name'] ?? 'Contact Form',
                    'form_fields'    => $fields,
                    'button_text'    => $s['submit'] ?? 'Send',
                    'email_to'       => $s['email_to'] ?? get_option( 'admin_email' ),
                    'email_subject'  => $s['email_subject'] ?? 'New Form Submission',
                ];

            default:
                // Pass through raw settings for any other/third-party widget
                return $s;
        }
    }

    /* ── Shared style helpers ────────────────────────────── */

    private static function maybe_color( string $key, array $s ): array {
        $color_key = str_replace( '_color', '', $key ) . '_color';
        if ( isset( $s[ $color_key ] ) ) return [ $key => $s[ $color_key ] ];
        if ( isset( $s['color'] ) )      return [ $key => $s['color'] ];
        return [];
    }

    private static function maybe_bg( array $s ): array {
        $out = [];
        if ( ! empty( $s['background_color'] ) ) {
            $out['background_color']      = $s['background_color'];
            $out['button_background_color'] = $s['background_color'];
        }
        if ( ! empty( $s['hover_color'] ) ) {
            $out['button_hover_color']    = $s['hover_color'];
            $out['button_hover_background_color'] = $s['hover_color'];
        }
        return $out;
    }

    private static function maybe_typography( array $s ): array {
        $out = [];
        if ( ! empty( $s['font_size'] ) ) {
            $out['typography_font_size'] = [ 'unit' => 'px', 'size' => intval( $s['font_size'] ) ];
        }
        if ( ! empty( $s['font_weight'] ) ) {
            $out['typography_font_weight'] = $s['font_weight'];
        }
        if ( ! empty( $s['font_family'] ) ) {
            $out['typography_font_family'] = $s['font_family'];
        }
        if ( ! empty( $s['line_height'] ) ) {
            $out['typography_line_height'] = [ 'unit' => 'em', 'size' => floatval( $s['line_height'] ) ];
        }
        return $out;
    }

    private static function extract_background( array $bg ): array {
        $out = [];
        if ( ! empty( $bg['color'] ) )           $out['background_color'] = $bg['color'];
        if ( ! empty( $bg['image'] ) )            $out['background_image'] = [ 'url' => $bg['image'] ];
        if ( ! empty( $bg['image_position'] ) )   $out['background_position'] = $bg['image_position'];
        if ( ! empty( $bg['image_size'] ) )       $out['background_size'] = $bg['image_size'];
        if ( ! empty( $bg['gradient'] ) ) {
            $out['background_background'] = 'gradient';
            $out['background_color']      = $bg['gradient']['from'] ?? '';
            $out['background_color_b']    = $bg['gradient']['to']   ?? '';
            $out['background_gradient_angle'] = [ 'unit' => 'deg', 'size' => intval( $bg['gradient']['angle'] ?? 135 ) ];
        }
        if ( ! empty( $bg['overlay_color'] ) ) {
            $out['background_overlay_color'] = $bg['overlay_color'];
        }
        return $out;
    }

    private static function extract_spacing( $val, string $prop ): array {
        if ( ! $val ) return [];
        if ( is_numeric( $val ) ) {
            return [ $prop => [ 'unit' => 'px', 'top' => $val, 'right' => $val, 'bottom' => $val, 'left' => $val, 'isLinked' => true ] ];
        }
        if ( is_array( $val ) ) {
            return [ $prop => array_merge( [ 'unit' => 'px', 'isLinked' => false ], $val ) ];
        }
        return [];
    }

    /* ── List saved templates ────────────────────────────── */
    public static function list_templates( array $p ): array {
        $type_filter = sanitize_key( $p['type'] ?? '' );

        $query_args = [
            'post_type'      => 'elementor_library',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'orderby'        => 'title',
            'order'          => 'ASC',
        ];

        if ( $type_filter ) {
            $query_args['tax_query'] = [ [
                'taxonomy' => 'elementor_library_type',
                'field'    => 'slug',
                'terms'    => $type_filter,
            ] ];
        }

        $posts     = get_posts( $query_args );
        $templates = [];

        foreach ( $posts as $post ) {
            $terms     = wp_get_post_terms( $post->ID, 'elementor_library_type' );
            $type_slug = ! is_wp_error( $terms ) && ! empty( $terms ) ? $terms[0]->slug : 'unknown';

            $templates[] = [
                'id'       => $post->ID,
                'title'    => $post->post_title,
                'type'     => $type_slug,
                'modified' => $post->post_modified,
                'url'      => get_permalink( $post->ID ),
            ];
        }

        return [ 'templates' => $templates, 'count' => count( $templates ) ];
    }

    /* ── Import (apply) a template to a post/page ────────── */
    public static function import_template( array $p ): array {
        $post_id     = intval( $p['post_id']     ?? 0 );
        $template_id = intval( $p['template_id'] ?? 0 );

        if ( ! $post_id )     throw new Exception( 'post_id required.' );
        if ( ! $template_id ) throw new Exception( 'template_id required.' );

        $template_post = get_post( $template_id );
        if ( ! $template_post || $template_post->post_type !== 'elementor_library' ) {
            throw new Exception( "Template #{$template_id} not found in elementor_library." );
        }

        $raw = get_post_meta( $template_id, '_elementor_data', true );
        if ( ! $raw ) {
            throw new Exception( "Template #{$template_id} has no Elementor data." );
        }

        // Copy Elementor data from template to target post
        update_post_meta( $post_id, '_elementor_data', $raw );
        update_post_meta( $post_id, '_elementor_edit_mode', 'builder' );
        delete_post_meta( $post_id, '_elementor_css' );

        if ( class_exists( '\Elementor\Plugin' ) ) {
            \Elementor\Plugin::$instance->files_manager->clear_cache();
        }

        CWPM_Logger::log( 'info', "Applied Elementor template #{$template_id} to post #{$post_id}" );

        return [
            'post_id'      => $post_id,
            'template_id'  => $template_id,
            'template_name'=> $template_post->post_title,
            'applied'      => true,
            'url'          => get_permalink( $post_id ),
        ];
    }

    /* ── Widget catalog (returned when Elementor not loaded) */
    private static function widget_catalog(): array {
        return [
            ['name'=>'heading','title'=>'Heading','group'=>'basic'],
            ['name'=>'text-editor','title'=>'Text Editor','group'=>'basic'],
            ['name'=>'image','title'=>'Image','group'=>'basic'],
            ['name'=>'button','title'=>'Button','group'=>'basic'],
            ['name'=>'divider','title'=>'Divider','group'=>'basic'],
            ['name'=>'spacer','title'=>'Spacer','group'=>'basic'],
            ['name'=>'icon-box','title'=>'Icon Box','group'=>'general'],
            ['name'=>'image-box','title'=>'Image Box','group'=>'general'],
            ['name'=>'icon','title'=>'Icon','group'=>'general'],
            ['name'=>'icon-list','title'=>'Icon List','group'=>'general'],
            ['name'=>'counter','title'=>'Counter','group'=>'general'],
            ['name'=>'progress','title'=>'Progress Bar','group'=>'general'],
            ['name'=>'testimonial','title'=>'Testimonial','group'=>'general'],
            ['name'=>'tabs','title'=>'Tabs','group'=>'general'],
            ['name'=>'accordion','title'=>'Accordion','group'=>'general'],
            ['name'=>'alert','title'=>'Alert','group'=>'general'],
            ['name'=>'call-to-action','title'=>'Call To Action','group'=>'pro'],
            ['name'=>'price-table','title'=>'Price Table','group'=>'pro'],
            ['name'=>'countdown','title'=>'Countdown','group'=>'pro'],
            ['name'=>'form','title'=>'Form','group'=>'pro'],
            ['name'=>'video','title'=>'Video','group'=>'general'],
            ['name'=>'google_maps','title'=>'Google Maps','group'=>'general'],
            ['name'=>'posts','title'=>'Posts','group'=>'wordpress'],
            ['name'=>'nav-menu','title'=>'Nav Menu','group'=>'wordpress'],
            ['name'=>'search-form','title'=>'Search Form','group'=>'wordpress'],
            ['name'=>'shortcode','title'=>'Shortcode','group'=>'wordpress'],
            ['name'=>'sidebar','title'=>'Sidebar','group'=>'wordpress'],
            ['name'=>'social-icons','title'=>'Social Icons','group'=>'general'],
            ['name'=>'carousel','title'=>'Carousel','group'=>'general'],
            ['name'=>'image-gallery','title'=>'Image Gallery','group'=>'general'],
        ];
    }
}
