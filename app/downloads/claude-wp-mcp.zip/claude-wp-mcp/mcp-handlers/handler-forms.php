<?php
/**
 * Forms Handler — MetForm + WPForms
 *
 * Reads form definitions and submission entries.
 * Does not write / delete entries.
 */
class CWPM_Forms {

    /* ── List all forms ──────────────────────────────────── */
    public static function list_forms( array $p ): array {
        $forms = [];

        /* MetForm ─ forms are stored as 'metform-form' CPT */
        if ( post_type_exists( 'metform-form' ) ) {
            $mf_forms = get_posts( [
                'post_type'      => 'metform-form',
                'post_status'    => 'publish',
                'posts_per_page' => -1,
                'orderby'        => 'title',
                'order'          => 'ASC',
            ] );
            foreach ( $mf_forms as $form ) {
                $entry_count = (int) ( new WP_Query( [
                    'post_type'      => 'metform-entry',
                    'post_status'    => 'publish',
                    'posts_per_page' => 1,
                    'meta_key'       => 'mf_form_id',
                    'meta_value'     => $form->ID,
                    'no_found_rows'  => false,
                    'fields'         => 'ids',
                ] ) )->found_posts;

                $forms[] = [
                    'plugin'       => 'metform',
                    'id'           => (string) $form->ID,
                    'title'        => $form->post_title,
                    'entry_count'  => $entry_count,
                ];
            }
        }

        /* WPForms ─ forms are stored in the wpforms_forms option table */
        if ( class_exists( 'WPForms' ) && function_exists( 'wpforms' ) ) {
            $wpf_forms = wpforms()->form->get( '', [ 'orderby' => 'title', 'order' => 'ASC' ] );
            if ( is_array( $wpf_forms ) ) {
                foreach ( $wpf_forms as $form ) {
                    $entry_count = 0;
                    if ( method_exists( wpforms()->entry, 'get_count' ) ) {
                        $entry_count = (int) wpforms()->entry->get_count( [ 'form_id' => $form->ID ] );
                    }
                    $forms[] = [
                        'plugin'      => 'wpforms',
                        'id'          => (string) $form->ID,
                        'title'       => $form->post_title,
                        'entry_count' => $entry_count,
                    ];
                }
            }
        }

        return [ 'forms' => $forms, 'count' => count( $forms ) ];
    }

    /* ── List form entries ───────────────────────────────── */
    public static function list_form_entries( array $p ): array {
        $form_id  = $p['form_id']  ?? '';
        $per_page = max( 1, intval( $p['per_page'] ?? 20 ) );
        $page     = max( 1, intval( $p['page']     ?? 1  ) );
        $status   = sanitize_key( $p['status']     ?? 'active' );

        $entries = [];
        $total   = 0;

        /* ── MetForm entries ── */
        $mf_status_map = [ 'active' => 'publish', 'spam' => 'spam', 'trash' => 'trash' ];
        $mf_post_status = $mf_status_map[ $status ] ?? 'publish';

        $query_args = [
            'post_type'      => 'metform-entry',
            'post_status'    => $mf_post_status,
            'posts_per_page' => $per_page,
            'paged'          => $page,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'no_found_rows'  => false,
        ];

        if ( $form_id ) {
            $query_args['meta_query'] = [ [
                'key'   => 'mf_form_id',
                'value' => $form_id,
            ] ];
        }

        $q = new WP_Query( $query_args );
        $total += $q->found_posts;

        foreach ( $q->posts as $entry_post ) {
            $meta = get_post_meta( $entry_post->ID );
            // Remove internal WP/MetForm meta
            $fields = [];
            foreach ( $meta as $key => $val ) {
                if ( strpos( $key, '_' ) !== 0 ) {
                    $fields[ $key ] = count( $val ) === 1 ? $val[0] : $val;
                }
            }
            $entries[] = [
                'plugin'   => 'metform',
                'id'       => (string) $entry_post->ID,
                'form_id'  => get_post_meta( $entry_post->ID, 'mf_form_id', true ),
                'date'     => $entry_post->post_date,
                'status'   => $entry_post->post_status,
                'fields'   => $fields,
            ];
        }

        /* ── WPForms entries ── */
        if ( class_exists( 'WPForms' ) && function_exists( 'wpforms' ) && method_exists( wpforms()->entry, 'get_entries' ) ) {
            $wpf_args = [
                'number' => $per_page,
                'offset' => ( $page - 1 ) * $per_page,
                'order'  => 'DESC',
            ];
            if ( $form_id ) $wpf_args['form_id'] = $form_id;
            if ( $status !== 'active' ) $wpf_args['status'] = $status;

            $wpf_entries = wpforms()->entry->get_entries( $wpf_args );
            $total      += (int) wpforms()->entry->get_count( $wpf_args );

            foreach ( (array) $wpf_entries as $e ) {
                $fields = [];
                $data   = maybe_unserialize( $e->fields ?? '' );
                if ( is_array( $data ) ) {
                    foreach ( $data as $field ) {
                        $label = $field['name'] ?? $field['id'] ?? 'field';
                        $fields[ $label ] = $field['value'] ?? '';
                    }
                }
                $entries[] = [
                    'plugin'  => 'wpforms',
                    'id'      => (string) $e->entry_id,
                    'form_id' => (string) $e->form_id,
                    'date'    => $e->date,
                    'status'  => $e->status ?? 'active',
                    'fields'  => $fields,
                ];
            }
        }

        return [
            'entries'  => $entries,
            'total'    => $total,
            'per_page' => $per_page,
            'page'     => $page,
        ];
    }

    /* ── Get single entry ────────────────────────────────── */
    public static function get_form_entry( array $p ): array {
        $entry_id = $p['entry_id'] ?? '';
        $plugin   = $p['plugin']   ?? '';

        if ( ! $entry_id ) throw new Exception( 'entry_id required.' );

        /* Auto-detect plugin if not specified */
        if ( ! $plugin ) {
            // Try MetForm first (integer post ID)
            if ( is_numeric( $entry_id ) ) {
                $post = get_post( intval( $entry_id ) );
                if ( $post && $post->post_type === 'metform-entry' ) {
                    $plugin = 'metform';
                }
            }
            if ( ! $plugin ) $plugin = 'wpforms';
        }

        /* MetForm */
        if ( $plugin === 'metform' ) {
            $post = get_post( intval( $entry_id ) );
            if ( ! $post || $post->post_type !== 'metform-entry' ) {
                throw new Exception( "MetForm entry #{$entry_id} not found." );
            }
            $meta   = get_post_meta( $post->ID );
            $fields = [];
            foreach ( $meta as $key => $val ) {
                if ( strpos( $key, '_' ) !== 0 ) {
                    $fields[ $key ] = count( $val ) === 1 ? $val[0] : $val;
                }
            }
            return [
                'plugin'  => 'metform',
                'id'      => (string) $post->ID,
                'form_id' => get_post_meta( $post->ID, 'mf_form_id', true ),
                'date'    => $post->post_date,
                'status'  => $post->post_status,
                'fields'  => $fields,
            ];
        }

        /* WPForms */
        if ( class_exists( 'WPForms' ) && function_exists( 'wpforms' ) ) {
            $e = wpforms()->entry->get( intval( $entry_id ) );
            if ( ! $e ) throw new Exception( "WPForms entry #{$entry_id} not found." );

            $fields = [];
            $data   = maybe_unserialize( $e->fields ?? '' );
            if ( is_array( $data ) ) {
                foreach ( $data as $field ) {
                    $label = $field['name'] ?? $field['id'] ?? 'field';
                    $fields[ $label ] = $field['value'] ?? '';
                }
            }
            return [
                'plugin'  => 'wpforms',
                'id'      => (string) $e->entry_id,
                'form_id' => (string) $e->form_id,
                'date'    => $e->date,
                'status'  => $e->status ?? 'active',
                'fields'  => $fields,
                'meta'    => maybe_unserialize( $e->meta ?? '' ),
            ];
        }

        throw new Exception( "Could not find entry #{$entry_id}. Make sure MetForm or WPForms is active." );
    }
}
