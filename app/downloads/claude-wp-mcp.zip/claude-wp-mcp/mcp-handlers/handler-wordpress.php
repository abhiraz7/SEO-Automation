<?php
/**
 * WordPress core utility tools: site info, users, terms, cache, theme, cron, search-replace.
 */
class CWPM_WordPress {

    const MAX_PER_PAGE          = 100;
    const SEARCH_REPLACE_LIMIT  = 500; // max posts processed in one call

    /* ── Site info ───────────────────────────────────────── */
    public static function get_site_info( array $p ): array {
        $theme = wp_get_theme();
        return [
            'name'         => get_bloginfo( 'name' ),
            'tagline'      => get_bloginfo( 'description' ),
            'url'          => get_bloginfo( 'url' ),
            'admin_url'    => admin_url(),
            'wp_version'   => get_bloginfo( 'version' ),
            'language'     => get_bloginfo( 'language' ),
            'charset'      => get_bloginfo( 'charset' ),
            'active_theme' => [
                'name'    => $theme->get( 'Name' ),
                'version' => $theme->get( 'Version' ),
                'author'  => $theme->get( 'Author' ),
                'parent'  => $theme->parent() ? $theme->parent()->get( 'Name' ) : null,
            ],
            'is_multisite' => is_multisite(),
            'posts_count'  => (int) wp_count_posts()->publish,
            'pages_count'  => (int) wp_count_posts( 'page' )->publish,
            'users_count'  => (int) count_users()['total_users'],
            'media_count'  => (int) wp_count_posts( 'attachment' )->inherit,
        ];
    }

    /* ── List users ──────────────────────────────────────── */
    public static function list_users( array $p ): array {
        $args = [
            'number'  => min( intval( $p['per_page'] ?? 20 ), self::MAX_PER_PAGE ),
            'paged'   => max( 1, intval( $p['page'] ?? 1 ) ),
            'orderby' => sanitize_key( $p['orderby'] ?? 'registered' ),
            'order'   => strtoupper( sanitize_key( $p['order'] ?? 'DESC' ) ),
        ];
        if ( ! empty( $p['role'] ) )   $args['role']   = sanitize_key( $p['role'] );
        if ( ! empty( $p['search'] ) ) $args['search'] = '*' . sanitize_text_field( $p['search'] ) . '*';

        $users = get_users( $args );
        $total = count( get_users( array_merge( $args, [ 'number' => -1, 'fields' => 'ID' ] ) ) );

        return [
            'users' => array_map( fn( $u ) => [
                'id'         => $u->ID,
                'login'      => $u->user_login,
                'email'      => self::mask_email( $u->user_email ),
                'name'       => $u->display_name,
                'roles'      => $u->roles,
                'registered' => $u->user_registered,
            ], $users ),
            'total' => $total,
        ];
    }

    /* ── Get single user ─────────────────────────────────── */
    public static function get_user( array $p ): array {
        $user = ! empty( $p['user_id'] )
            ? get_user_by( 'id', intval( $p['user_id'] ) )
            : get_user_by( 'email', sanitize_email( $p['email'] ?? '' ) );

        if ( ! $user ) throw new Exception( 'User not found.' );

        return [
            'id'         => $user->ID,
            'login'      => $user->user_login,
            'email'      => self::mask_email( $user->user_email ),
            'name'       => $user->display_name,
            'first_name' => get_user_meta( $user->ID, 'first_name', true ),
            'last_name'  => get_user_meta( $user->ID, 'last_name', true ),
            'roles'      => $user->roles,
            'registered' => $user->user_registered,
            'url'        => $user->user_url,
        ];
    }

    /* ── Create taxonomy term ────────────────────────────── */
    public static function create_term( array $p ): array {
        $name     = sanitize_text_field( $p['name'] ?? '' );
        $taxonomy = sanitize_key( $p['taxonomy'] ?? 'category' );
        if ( ! $name ) throw new Exception( 'name required.' );

        $args = [
            'slug'        => sanitize_title( $p['slug'] ?? $name ),
            'parent'      => intval( $p['parent'] ?? 0 ),
            'description' => sanitize_textarea_field( $p['description'] ?? '' ),
        ];

        $result = wp_insert_term( $name, $taxonomy, $args );
        if ( is_wp_error( $result ) ) throw new Exception( $result->get_error_message() );

        CWPM_Logger::log( 'info', "Created term '{$name}' in '{$taxonomy}'" );
        return [
            'term_id'  => $result['term_id'],
            'name'     => $name,
            'taxonomy' => $taxonomy,
            'slug'     => $args['slug'],
        ];
    }

    /* ── Delete taxonomy term ────────────────────────────── */
    public static function delete_term( array $p ): array {
        $term_id  = intval( $p['term_id'] ?? 0 );
        $taxonomy = sanitize_key( $p['taxonomy'] ?? 'category' );
        if ( ! $term_id ) throw new Exception( 'term_id required.' );

        $result = wp_delete_term( $term_id, $taxonomy );
        if ( is_wp_error( $result ) ) throw new Exception( $result->get_error_message() );
        if ( ! $result ) throw new Exception( "Could not delete term #{$term_id}." );

        CWPM_Logger::log( 'warn', "Deleted term #{$term_id} from '{$taxonomy}'" );
        return [ 'deleted' => true, 'term_id' => $term_id ];
    }

    /* ── Flush cache ─────────────────────────────────────── */
    public static function flush_cache( array $p ): array {
        wp_cache_flush();

        $flushed = [ 'object_cache' => true, 'rewrite_rules' => false, 'elementor_css' => false ];

        if ( ! empty( $p['rewrite_rules'] ) ) {
            flush_rewrite_rules();
            $flushed['rewrite_rules'] = true;
        }

        if ( class_exists( '\Elementor\Plugin' )
            && isset( \Elementor\Plugin::$instance )
            && isset( \Elementor\Plugin::$instance->files_manager ) ) {
            \Elementor\Plugin::$instance->files_manager->clear_cache();
            $flushed['elementor_css'] = true;
        }

        CWPM_Logger::log( 'info', 'Cache flushed: ' . wp_json_encode( $flushed ) );
        return $flushed;
    }

    /* ── Search and replace in post content ─────────────── */
    public static function search_replace( array $p ): array {
        $find    = $p['find'] ?? '';
        $replace = $p['replace'] ?? '';
        $type    = sanitize_key( $p['post_type'] ?? 'post' );
        $status  = sanitize_key( $p['status'] ?? 'publish' );
        $dry_run = ! empty( $p['dry_run'] );

        if ( $find === '' ) throw new Exception( 'find required.' );

        $query = new WP_Query( [
            'post_type'      => $type,
            'post_status'    => $status,
            'posts_per_page' => self::SEARCH_REPLACE_LIMIT,
            'fields'         => 'all',
        ] );

        $updated = [];
        foreach ( $query->posts as $post ) {
            $new_content = str_replace( $find, $replace, $post->post_content );
            $new_title   = str_replace( $find, $replace, $post->post_title );

            if ( $new_content !== $post->post_content || $new_title !== $post->post_title ) {
                if ( ! $dry_run ) {
                    wp_update_post( [
                        'ID'           => $post->ID,
                        'post_content' => $new_content,
                        'post_title'   => $new_title,
                    ] );
                }
                $updated[] = [ 'id' => $post->ID, 'title' => $post->post_title ];
            }
        }

        $label = $dry_run ? 'DRY RUN' : 'Done';
        CWPM_Logger::log( 'info', "{$label} search-replace \"{$find}\" → \"{$replace}\" on " . count( $updated ) . " {$type}s" );
        return [ 'updated' => $updated, 'count' => count( $updated ), 'dry_run' => $dry_run ];
    }

    /* ── Get active theme info ───────────────────────────── */
    public static function get_active_theme( array $p ): array {
        $active    = wp_get_theme();
        $all       = wp_get_themes();
        $stylesheet = get_option( 'stylesheet' );

        $themes = [];
        foreach ( $all as $slug => $t ) {
            $themes[] = [
                'slug'       => $slug,
                'name'       => $t->get( 'Name' ),
                'version'    => $t->get( 'Version' ),
                'active'     => ( $slug === $stylesheet ),
                'has_parent' => (bool) $t->parent(),
            ];
        }

        return [
            'active' => [
                'slug'        => $stylesheet,
                'name'        => $active->get( 'Name' ),
                'version'     => $active->get( 'Version' ),
                'author'      => $active->get( 'Author' ),
                'description' => $active->get( 'Description' ),
                'template'    => get_template(),
                'parent'      => $active->parent() ? $active->parent()->get( 'Name' ) : null,
                'screenshot'  => $active->get_screenshot(),
            ],
            'all_themes' => $themes,
        ];
    }

    /* ── Activate theme ──────────────────────────────────── */
    public static function activate_theme( array $p ): array {
        $slug = sanitize_key( $p['slug'] ?? '' );
        if ( ! $slug ) throw new Exception( 'slug required.' );

        $theme = wp_get_theme( $slug );
        if ( ! $theme->exists() ) throw new Exception( "Theme '{$slug}' not found." );

        switch_theme( $slug );
        CWPM_Logger::log( 'warn', "Switched active theme to: {$slug}" );
        return [ 'activated' => $slug, 'name' => $theme->get( 'Name' ) ];
    }

    /* ── Trigger WP-Cron and list upcoming events ────────── */
    public static function run_cron( array $p ): array {
        if ( ! defined( 'DOING_CRON' ) ) {
            define( 'DOING_CRON', true );
        }
        wp_cron();

        $crons     = _get_cron_array() ?: [];
        $scheduled = [];
        foreach ( $crons as $timestamp => $hooks ) {
            foreach ( $hooks as $hook => $events ) {
                foreach ( $events as $event ) {
                    $scheduled[] = [
                        'hook'     => $hook,
                        'next_run' => gmdate( 'Y-m-d H:i:s', $timestamp ),
                        'interval' => $event['interval'] ?? null,
                    ];
                }
            }
        }

        usort( $scheduled, fn( $a, $b ) => strcmp( $a['next_run'], $b['next_run'] ) );
        CWPM_Logger::log( 'info', 'WP-Cron executed manually.' );
        return [ 'executed' => true, 'scheduled_events' => array_slice( $scheduled, 0, 20 ) ];
    }

    /* ── Helpers ─────────────────────────────────────────── */

    /** Mask an email address: j***@example.com */
    private static function mask_email( string $email ): string {
        $parts = explode( '@', $email, 2 );
        if ( count( $parts ) !== 2 ) return '***';
        $local  = $parts[0];
        $domain = $parts[1];
        $masked = substr( $local, 0, 1 ) . str_repeat( '*', max( 1, strlen( $local ) - 1 ) );
        return $masked . '@' . $domain;
    }
}
