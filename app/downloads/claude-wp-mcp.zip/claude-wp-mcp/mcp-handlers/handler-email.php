<?php
/**
 * Email Handler — FluentSMTP email log reader.
 *
 * Reads from the fsmtp_email_logs table created by FluentSMTP.
 * Read-only; does not send or delete emails.
 */
class CWPM_Email {

    /* ── List sent-email logs ────────────────────────────── */
    public static function list_email_logs( array $p ): array {
        global $wpdb;

        $table = $wpdb->prefix . 'fsmtp_email_logs';

        /* Check table exists to give a helpful error if FluentSMTP isn't installed */
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) !== $table ) {
            return [
                'error'   => 'FluentSMTP email log table not found. Please install and activate FluentSMTP.',
                'logs'    => [],
                'total'   => 0,
            ];
        }

        $per_page = max( 1, intval( $p['per_page'] ?? 20 ) );
        $page     = max( 1, intval( $p['page']     ?? 1  ) );
        $status   = sanitize_key( $p['status']     ?? '' );
        $search   = sanitize_text_field( $p['search'] ?? '' );
        $offset   = ( $page - 1 ) * $per_page;

        $where  = '1=1';
        $values = [];

        if ( $status ) {
            $where   .= ' AND status = %s';
            $values[] = $status;
        }

        if ( $search ) {
            $like     = '%' . $wpdb->esc_like( $search ) . '%';
            $where   .= ' AND (subject LIKE %s OR to_email LIKE %s OR from_email LIKE %s)';
            $values[] = $like;
            $values[] = $like;
            $values[] = $like;
        }

        /* Total count */
        if ( $values ) {
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
            $total = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE {$where}", // phpcs:ignore
                ...$values
            ) );
        } else {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            $total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ); // phpcs:ignore
        }

        /* Rows */
        $limit_values = array_merge( $values, [ $per_page, $offset ] );
        if ( $limit_values ) {
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
            $rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT id, subject, to_email, from_email, from_name, status, response, created_at
                   FROM {$table}
                  WHERE {$where}
                  ORDER BY created_at DESC
                  LIMIT %d OFFSET %d", // phpcs:ignore
                ...$limit_values
            ), ARRAY_A );
        } else {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared
            $rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT id, subject, to_email, from_email, from_name, status, response, created_at
                   FROM {$table}
                  ORDER BY created_at DESC
                  LIMIT %d OFFSET %d",
                $per_page,
                $offset
            ), ARRAY_A );
        }

        $logs = [];
        foreach ( (array) $rows as $row ) {
            $log_entry = [
                'id'         => $row['id'],
                'subject'    => $row['subject'],
                'to'         => $row['to_email'],
                'from'       => $row['from_name'] ? "{$row['from_name']} <{$row['from_email']}>" : $row['from_email'],
                'status'     => $row['status'],
                'date'       => $row['created_at'],
            ];
            // Only include response detail on failures to keep output manageable
            if ( $row['status'] !== 'sent' && $row['response'] ) {
                $log_entry['response'] = $row['response'];
            }
            $logs[] = $log_entry;
        }

        return [
            'logs'     => $logs,
            'total'    => $total,
            'per_page' => $per_page,
            'page'     => $page,
        ];
    }
}
